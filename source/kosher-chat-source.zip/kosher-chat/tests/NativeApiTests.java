package com.moked.kosherchat;

import java.nio.charset.StandardCharsets;

/** JNI linkage and failure recovery without substituting a synthetic model. */
public final class NativeApiTests {
    public static void main(String[] args) {
        NativeEngine.reset();
        NativeEngine.close();
        if (NativeEngine.modelFamily()!=0) throw new AssertionError("Closed model family");
        boolean noModel=false;
        try { NativeEngine.generate(new byte[0],64,n->{}); }
        catch (IllegalStateException e) { noModel="MODEL_NOT_LOADED".equals(e.getMessage()); }
        if (!noModel) throw new AssertionError("generateBounded JNI linkage / missing model");
        boolean badLimit=false;
        try { NativeEngine.generate(new byte[0],Integer.MAX_VALUE,n->{}); }
        catch (IllegalArgumentException e) { badLimit="INVALID_GENERATION_LIMIT".equals(e.getMessage()); }
        if (!badLimit) throw new AssertionError("Unbounded generation limit");
        boolean missingFile=false;
        try { NativeEngine.load("/nonexistent-kosher-chat-model.gguf".getBytes(StandardCharsets.UTF_8),1024,2); }
        catch (IllegalStateException e) { missingFile="MODEL_LOAD_FAILED".equals(e.getMessage()); }
        if (!missingFile||NativeEngine.modelFamily()!=0) throw new AssertionError("Failed load resets model state");
        NativeEngine.cancel(); NativeEngine.reset(); NativeEngine.close();
        long[] stats=NativeEngine.cacheStats();
        if (stats.length!=2||stats[0]!=0||stats[1]!=0) throw new AssertionError("Cache reset");
        System.out.println("PASS: JNI linkage, bounded arguments and failed-load cleanup; no model inference tested");
    }
}
