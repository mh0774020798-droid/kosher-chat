import hashlib
from pathlib import Path
import sys
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from fetch_dicta import verify_metadata

class DictaMetadataTests(unittest.TestCase):
    def test_verified_git_bytes_can_be_resumed(self):
        content=b'{"model_type":"qwen3"}\n'
        blob=hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()
        item={'rfilename':'config.json','blobId':blob}
        result=verify_metadata(item,content)
        self.assertEqual(result['sha256'],hashlib.sha256(content).hexdigest())
        self.assertEqual(result['bytes'],len(content))

    def test_changed_git_metadata_is_rejected(self):
        with self.assertRaisesRegex(ValueError,'Git blob mismatch'):
            verify_metadata({'rfilename':'config.json','blobId':'0'*40},b'changed metadata')

    def test_verified_lfs_bytes_can_be_resumed(self):
        content=b'tokenizer metadata'
        item={'rfilename':'tokenizer.json','blobId':'1'*40,
              'lfs':{'sha256':hashlib.sha256(content).hexdigest(),'size':len(content)}}
        self.assertEqual(verify_metadata(item,content)['verification'],'LFS SHA-256')

    def test_truncated_lfs_bytes_are_rejected(self):
        content=b'partial tokenizer'
        item={'rfilename':'tokenizer.json','blobId':'1'*40,
              'lfs':{'sha256':hashlib.sha256(content).hexdigest(),'size':len(content)+1}}
        with self.assertRaisesRegex(ValueError,'LFS hash mismatch'):
            verify_metadata(item,content)

if __name__=='__main__':unittest.main()
