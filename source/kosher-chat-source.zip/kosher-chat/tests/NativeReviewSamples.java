package com.moked.kosherchat;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Human review samples: printed responses are evidence, not automatic quality approval. */
public final class NativeReviewSamples {
    public static void main(String[] args)throws Exception {
        String[] prompts={
            "כתוב הודעה קצרה המבקשת לדחות את הפגישה למחר בשעה עשר בבוקר.",
            "הסבר לילד מה ההבדל בין מקלדת לעכבר במחשב.",
            "הצע שלושה שמות ברורים לקובץ שמכיל רשימת קניות.",
            "סכם במשפט אחד: המדפסת לא הדפיסה כי הכבל היה מנותק. אחרי חיבור הכבל היא חזרה לעבוד.",
            "בקופסה היו שלושה עטים והוספתי שניים. כמה עטים יש עכשיו?",
            "כתוב שלוש בדיקות פשוטות למדפסת שלא מדפיסה.",
            "מה ההבדל בין שמירת קובץ לבין מחיקת קובץ?",
            "הפוך לרשימה מסודרת: מחברת, עט, ספר.",
            "האם תיקייה יכולה להכיל יותר מקובץ אחד? הסבר בקצרה.",
            "תקן את המשפט: שמרתי את הקובץ בתוך התיקייה חדשה.",
            "Explain the difference between a file and a folder. Answer in English.",
            "Write a short note asking to reschedule a meeting. Answer in English.",
            "Give three short tips for naming files. Number them 1, 2 and 3. Answer in English.",
            "Summarize in one sentence: The printer did not print because its cable was disconnected. After connecting the cable, it worked again. Answer in English.",
            "The green cup contains water and the yellow cup is empty. Which cup contains water? Answer in English.",
            "What is a computer keyboard used for? Answer in English.",
            "What is a software update? Answer in English.",
            "Why make a backup before editing a document? Answer in English.",
            "מה ההבדל בין קובץ טקסט לבין קובץ תמונה?",
            "כתוב רשימת משימות קצרה ליום עבודה מסודר."
        };
        int context=args.length>1?Integer.parseInt(args[1]):1024;
        NativeEngine.reset();NativeEngine.load(args[0].getBytes(StandardCharsets.UTF_8),context,2);
        int failures=0;
        try{
            int index=0;
            for(String question:prompts){
                String prompt=PromptBuilder.build(Arrays.asList(new PromptBuilder.Message("user",question)),"",0,NativeEngine.modelFamily());
                final String raw;
                try{raw=new String(NativeEngine.generate(prompt.getBytes(StandardCharsets.UTF_8),128,n->{}),StandardCharsets.UTF_8);}
                catch(IllegalStateException e){failures++;System.out.println("SAMPLE "+(++index)+": "+question+"\nGENERATION_ERROR="+e.getMessage()+"\n");continue;}
                if(raw.isEmpty()||raw.contains("\uFFFD"))throw new AssertionError("Empty output or invalid UTF-8");
                System.out.println("SAMPLE "+(++index)+": "+question+"\n"+raw+"\nFILTER_ACCEPTED="+new ContentGuard().cleanAnswer(raw).equals(raw.trim())+"\n");
            }
        }finally{NativeEngine.close();}
        if(failures>0)throw new AssertionError(failures+" bounded review samples failed");
        System.out.println("Twenty samples printed for manual review; no automatic quality approval.");
    }
}
