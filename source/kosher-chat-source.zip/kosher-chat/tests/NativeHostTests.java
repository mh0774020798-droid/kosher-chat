package com.moked.kosherchat;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class NativeHostTests {
    public static void main(String[] args)throws Exception {
        final int context=2048;
        NativeEngine.reset();NativeEngine.load(args[0].getBytes(StandardCharsets.UTF_8),context,2);
        String[] questions={"מהי בירת צרפת?","הסבר בשני משפטים מה עושה המעבד במחשב.","כתוב הודעת תודה קצרה למורה שעזר לי ללמוד."};
        for(String q:questions){String reference=q.contains("המעבד")?"מה עושה המעבד במחשב (2026-10-06): המעבד (CPU) הוא רכיב במחשב שמבצע הוראות של תוכנות. הוא עורך חישובים ומעבד נתונים, ועובד עם הזיכרון ועם רכיבי המחשב האחרים.":q.contains("למורה")?"ניסוח הודעת תודה למורה (2026-10-06): דוגמה להודעת תודה למורה: תודה רבה על הסבלנות והעזרה בלימוד. ההסברים שלך עזרו לי להבין ולהתקדם. אני מעריך את ההשקעה שלך. אפשר להוסיף שם ופנייה מכובדת לפי ההקשר.":"";String prompt=PromptBuilder.build(Arrays.asList(new PromptBuilder.Message("user",q)),reference,0,NativeEngine.modelFamily());int n=NativeEngine.countTokens(prompt.getBytes(StandardCharsets.UTF_8));if(n+GenerationBudget.reservedTokens(NativeEngine.modelFamily(),128)+4>context)throw new AssertionError("prompt capacity");long start=System.nanoTime();byte[] result=NativeEngine.generate(prompt.getBytes(StandardCharsets.UTF_8),128,count->{});String output=new String(result,StandardCharsets.UTF_8);if(output.isEmpty()||output.contains("\uFFFD"))throw new AssertionError("empty generation / UTF-8");System.out.println(q+(reference.isEmpty()?"":" [local reference]")+"\n"+new ContentGuard().cleanAnswer(output)+"\nElapsed seconds: "+((System.nanoTime()-start)/1e9)+"\n");}
        String recoveryPrompt=PromptBuilder.build(Arrays.asList(new PromptBuilder.Message("user","מהי בירת צרפת?")),"",0,NativeEngine.modelFamily());
        NativeEngine.generate(recoveryPrompt.getBytes(StandardCharsets.UTF_8),16,count->{});
        NativeEngine.generate(recoveryPrompt.getBytes(StandardCharsets.UTF_8),16,count->{});
        long[] cached=NativeEngine.cacheStats();
        int promptTokens=NativeEngine.countTokens(recoveryPrompt.getBytes(StandardCharsets.UTF_8));
        if(cached[0]!=promptTokens-1||cached[1]!=1)throw new AssertionError("identical prompt reuses all except final token");
        if(NativeEngine.modelFamily()==31){
            byte[] warm=NativeEngine.generate(recoveryPrompt.getBytes(StandardCharsets.UTF_8),64,count->{});
            NativeEngine.close();NativeEngine.load(args[0].getBytes(StandardCharsets.UTF_8),context,2);
            byte[] cold=NativeEngine.generate(recoveryPrompt.getBytes(StandardCharsets.UTF_8),64,count->{});
            if(!Arrays.equals(warm,cold))throw new AssertionError("cached and cold deterministic answers differ");
            NativeEngine.generate(recoveryPrompt.getBytes(StandardCharsets.UTF_8),1,count->{});
            if(!NativeEngine.generationTruncated())throw new AssertionError("token cap not reported");
            NativeEngine.generate(recoveryPrompt.getBytes(StandardCharsets.UTF_8),64,count->{});
            if(NativeEngine.generationTruncated())throw new AssertionError("normal completion retains stale truncation flag");
        }
        String changedPrompt=PromptBuilder.build(Arrays.asList(new PromptBuilder.Message("user","מה עושה זיכרון העבודה?")),"",0,NativeEngine.modelFamily());
        NativeEngine.generate(changedPrompt.getBytes(StandardCharsets.UTF_8),16,count->{});
        long[] changed=NativeEngine.cacheStats();
        if(changed[0]<=0||changed[0]+changed[1]!=NativeEngine.countTokens(changedPrompt.getBytes(StandardCharsets.UTF_8)))throw new AssertionError("changed question reuses only matching prefix");
        boolean cancelled=false;
        try{NativeEngine.generate(recoveryPrompt.getBytes(StandardCharsets.UTF_8),64,count->NativeEngine.cancel());}
        catch(IllegalStateException e){cancelled="CANCELLED".equals(e.getMessage());}
        if(!cancelled)throw new AssertionError("generation cancellation");
        NativeEngine.reset();
        String recovery=new String(NativeEngine.generate(recoveryPrompt.getBytes(StandardCharsets.UTF_8),64,count->{}),StandardCharsets.UTF_8);
        if(recovery.isEmpty()||recovery.contains("\uFFFD"))throw new AssertionError("UTF-8 / recovery");
        if(NativeEngine.cacheStats()[0]!=0)throw new AssertionError("cancelled decode must invalidate cache");
        System.out.println("Cancellation recovery: "+recovery);
        NativeEngine.close();
        if(args.length>1){try(FileInputStream in=new FileInputStream(args[1])){java.lang.reflect.Field fd=FileDescriptor.class.getDeclaredField("fd");fd.setAccessible(true);NativeEngine.reset();long offset=args.length>2?Long.parseLong(args[2]):64;NativeEngine.loadAsset(fd.getInt(in.getFD()),offset,context,2);String output=new String(NativeEngine.generate(recoveryPrompt.getBytes(StandardCharsets.UTF_8),64,count->{}),StandardCharsets.UTF_8);System.out.println("Embedded model: "+output);if(output.isEmpty()||output.contains("\uFFFD"))throw new AssertionError("embedded generation / UTF-8");NativeEngine.close();}}
        System.out.println("PASS: native load, UTF-8, generation, context reset, cancellation and recovery"+(args.length>1?", embedded model":""));
    }
}
