package com.moked.kosherchat;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Experimental language pivot. Never displayed by the Android application. */
public final class NativePivotProbe {
    static String generate(String question,int limit){
        String prompt=PromptBuilder.build(Arrays.asList(new PromptBuilder.Message("user",question)),"",0,NativeEngine.modelFamily());
        String answer=new String(NativeEngine.generate(prompt.getBytes(StandardCharsets.UTF_8),limit,n->{}),StandardCharsets.UTF_8);
        if(answer.isEmpty()||answer.contains("\uFFFD"))throw new AssertionError("Empty or invalid text");
        if(!new ContentGuard().cleanAnswer(answer).equals(answer.trim()))throw new AssertionError("Intermediate or final output rejected by guard");
        return answer.trim();
    }
    public static void main(String[] args)throws Exception {
        String[] questions={
            "מהי בירת צרפת?",
            "הסבר בקצרה למה משתמשים בתיקייה במחשב.",
            "כתוב הודעה קצרה המבקשת לדחות את הפגישה למחר בשעה עשר בבוקר.",
            "הסבר לילד מה ההבדל בין מקלדת לעכבר במחשב.",
            "בקופסה היו שלושה עטים והוספתי שניים. כמה עטים יש עכשיו?",
            "כתוב שלוש בדיקות פשוטות למדפסת שלא מדפיסה."
        };
        NativeEngine.reset();NativeEngine.load(args[0].getBytes(StandardCharsets.UTF_8),1024,2);
        try{
            for(String question:questions){
                String english=generate(question+"\nAnswer in English.",80);
                String hebrew=generate("Translate the following text into fluent Hebrew. Return only the translation. Preserve every fact, name, number and time.\nText:\n"+english,128);
                System.out.println(question+"\nENGLISH: "+english+"\nHEBREW: "+hebrew+"\n");
            }
        }finally{NativeEngine.close();}
        System.out.println("Six experimental pivot samples; human review required.");
    }
}
