package com.moked.kosherchat;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Small mixed-language screening sample. Output needs human review. */
public final class NativeCandidateProbe {
    public static void main(String[] args)throws Exception {
        String[] questions={
            "מהי בירת צרפת?",
            "הסבר בקצרה למה משתמשים בתיקייה במחשב.",
            "כתוב הודעה קצרה המבקשת לדחות את הפגישה למחר בשעה עשר בבוקר.",
            "תקן את המשפט: שמרתי את הקובץ בתוך התיקייה חדשה.",
            "What does CPU stand for? Answer in English.",
            "Write a short note asking to reschedule a meeting. Answer in English."
        };
        int context=args.length>1?Integer.parseInt(args[1]):1024;
        NativeEngine.reset();NativeEngine.load(args[0].getBytes(StandardCharsets.UTF_8),context,2);
        int failures=0;
        try{
            for(String question:questions){
                String prompt=PromptBuilder.build(Arrays.asList(new PromptBuilder.Message("user",question)),"",0,NativeEngine.modelFamily());
                final String raw;
                try{raw=new String(NativeEngine.generate(prompt.getBytes(StandardCharsets.UTF_8),96,n->{}),StandardCharsets.UTF_8);}
                catch(IllegalStateException e){failures++;System.out.println(question+"\nGENERATION_ERROR="+e.getMessage()+"\n");continue;}
                if(raw.isEmpty()||raw.contains("\uFFFD"))throw new AssertionError("Empty output or invalid UTF-8");
                System.out.println(question+"\n"+raw+"\nFILTER_ACCEPTED="+new ContentGuard().cleanAnswer(raw).equals(raw.trim())+"\n");
            }
        }finally{NativeEngine.close();}
        if(failures>0)throw new AssertionError(failures+" bounded screening samples failed");
        System.out.println("Six screening samples; no automatic quality approval.");
    }
}
