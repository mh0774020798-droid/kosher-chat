import hashlib
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from model_catalog import identify, verify_file, verify_bundled, BUNDLED_MODEL

class ModelCatalogTests(unittest.TestCase):
    def setUp(self):
        self.directory=tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path=Path(self.directory.name)/'model.gguf'
        self.path.write_bytes(b'approved weights')
        self.sha=hashlib.sha256(self.path.read_bytes()).hexdigest()
        self.specs={'TEST':{'family':4,'bytes':self.path.stat().st_size,'sha256':self.sha}}
    def test_valid_exact_pin(self):
        self.assertEqual(verify_file(self.path,specs=self.specs)['family'],4)
    def test_same_size_tamper_rejected(self):
        self.path.write_bytes(b'corrupt! weights')
        with self.assertRaises(ValueError):verify_file(self.path,specs=self.specs)
    def test_legacy_family_cannot_claim_gemma4(self):
        self.specs['TEST']['family']=3
        with self.assertRaises(ValueError):identify(self.path.stat().st_size,self.sha,4,self.specs)
    def test_size_budget_rejected(self):
        with self.assertRaises(ValueError):verify_file(self.path,max_bytes=1,specs=self.specs)
    def test_missing_asset_rejected(self):
        with self.assertRaises(ValueError):verify_file(self.path.with_name('missing'),specs=self.specs)
    def test_bundled_beta_requires_its_exact_registered_pin(self):
        approved={'name':BUNDLED_MODEL,'family':31,'bytes':self.path.stat().st_size,'sha256':self.sha}
        self.assertEqual(verify_bundled(self.path,{BUNDLED_MODEL:approved}),approved)
    def test_registered_legacy_cannot_replace_bundled_beta(self):
        approved={'name':BUNDLED_MODEL,'family':31,'bytes':99,'sha256':'a'*64}
        with self.assertRaises(ValueError):verify_bundled(self.path,{BUNDLED_MODEL:approved,**self.specs})

if __name__=='__main__':unittest.main()
