import pathlib, sys, tempfile, unittest, zipfile
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'tools'))
from make_update import build
from verify_update import verify
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization

class UpdateTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=pathlib.Path(self.tmp.name)
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        self.private=self.root/'private.pem';self.public=self.root/'public.pem'
        self.private.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
        self.public.write_bytes(key.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo))
        self.knowledge=self.root/'knowledge.json';self.knowledge.write_text('{"updated_at":"2026-10-06","entries":[]}')
        self.pack=self.root/'test.kchat';build(self.private,self.pack,1,knowledge=self.knowledge)
    def tearDown(self):self.tmp.cleanup()
    def mutate(self,name,data):
        target=self.root/'bad.kchat'
        with zipfile.ZipFile(self.pack) as z,zipfile.ZipFile(target,'w') as out:
            for entry in z.namelist():out.writestr(entry,data if entry==name else z.read(entry))
        return target
    def test_valid(self):self.assertEqual(verify(self.public,self.pack)['version'],1)
    def test_manifest_tamper(self):
        with self.assertRaises(Exception):verify(self.public,self.mutate('manifest.json',b'{}'))
    def test_content_tamper(self):
        with self.assertRaises(Exception):verify(self.public,self.mutate('knowledge.json',b'changed'))
    def test_old_update(self):
        with self.assertRaises(Exception):verify(self.public,self.pack,current_version=1)
    def test_zip_path(self):
        with zipfile.ZipFile(self.pack,'a') as z:z.writestr('../escape.txt','bad')
        with self.assertRaises(Exception):verify(self.public,self.pack)
    def test_duplicate(self):
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            with zipfile.ZipFile(self.pack,'a') as z:z.writestr('knowledge.json','{}')
        with self.assertRaises(Exception):verify(self.public,self.pack)
if __name__=='__main__':unittest.main()
