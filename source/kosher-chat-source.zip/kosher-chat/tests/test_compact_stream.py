import hashlib
import io
from pathlib import Path
import re
import sys
from types import SimpleNamespace
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from compact_bf16_stream import RangeResponse, VerifiedStream, fetch_range
from strip_unused_kv import unused_kv_names

class Response(io.BytesIO):
    def __init__(self,data,status,content_range):
        super().__init__(data);self.status=status;self.headers={'Content-Range':content_range}

class CompactStreamTests(unittest.TestCase):
    def test_order_and_partial_final_range(self):
        data=bytes(range(31))
        def opener(request,timeout):
            first,last=map(int,re.search(r'bytes=(\d+)-(\d+)',request.headers['Range']).groups())
            return Response(data[first:last+1],206,f'bytes {first}-{last}/{len(data)}')
        with RangeResponse('https://example.invalid/?p=1',len(data),8,3,opener) as r:
            actual=b''.join(r.read(n) for n in (3,11,4,30))
            self.assertEqual(actual,data)
            self.assertEqual(r.read(1),b'')
    def test_full_hash_includes_discarded_data(self):
        data=b'kept-and-discarded-rows'
        s=VerifiedStream(io.BytesIO(data),len(data),4)
        self.assertEqual(s.read(4),b'kept');s.skip_to(10)
        s.finish(hashlib.sha256(data).hexdigest(),hashlib.sha256(data[:4]).hexdigest())
    def test_short_source_rejected(self):
        with self.assertRaises(ValueError):VerifiedStream(io.BytesIO(b'x'),2,1).read(2)
    def test_extra_source_rejected(self):
        with self.assertRaises(ValueError):VerifiedStream(io.BytesIO(b'xy'),1,1).finish(hashlib.sha256(b'x').hexdigest())
    def test_server_ignoring_range_rejected(self):
        with self.assertRaises(ValueError):fetch_range('https://example.invalid/?p=1',0,1,2,lambda *a,**k:Response(b'xy',200,'bytes 0-1/2'))
    def reader(self,blocks=35,missing=None):
        fields={name:SimpleNamespace(contents=lambda value=value:value) for name,value in {
            'general.architecture':'gemma4','gemma4.block_count':blocks,'gemma4.attention.shared_kv_layers':20}.items()}
        names=[f'blk.{i}.attn_{suffix}.weight' for i in range(35) for suffix in ('q','k','v','k_norm')]
        return SimpleNamespace(fields=fields,tensors=[SimpleNamespace(name=n) for n in names if n!=missing])
    def test_only_inactive_kv_removed(self):
        removed=unused_kv_names(self.reader())
        self.assertEqual(len(removed),60)
        self.assertNotIn('blk.14.attn_k.weight',removed)
        self.assertFalse(any('.attn_q.' in name for name in removed))
    def test_wrong_layer_count_rejected(self):
        with self.assertRaises(ValueError):unused_kv_names(self.reader(blocks=34))
    def test_missing_inactive_tensor_rejected(self):
        with self.assertRaises(ValueError):unused_kv_names(self.reader(missing='blk.34.attn_v.weight'))

if __name__=='__main__':unittest.main()
