package com.moked.kosherchat;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public final class NativeQualityTests {
    public static void main(String[] args) throws Exception {
        NativeEngine.reset();
        NativeEngine.load(args[0].getBytes(StandardCharsets.UTF_8),1024,2);
        String[][] cases={
            {"מהי בירת צרפת?","","פריז"},
            {"הסבר בשני משפטים מה עושה המעבד במחשב.","המעבד (CPU) מבצע הוראות של תוכנות, עורך חישובים ומעבד נתונים.","מעבד"},
            {"כתוב הודעת תודה קצרה למורה שעזר לי ללמוד.","תודה רבה על הסבלנות והעזרה בלימוד. ההסברים שלך עזרו לי להבין ולהתקדם.","תודה"},
            {"What is the capital of France? Answer in English.","","Paris"},
            {"מהי בירת יפן?","","טוקיו"},
            {"מה עושה זיכרון RAM במחשב?","זיכרון RAM שומר זמנית נתונים ותוכנות בזמן העבודה במחשב.","RAM"},
            {"הסבר בקצרה מה ההבדל בין קובץ לתיקייה.","","קובץ"},
            {"מהו גיבוי קובץ ולמה הוא שימושי?","","עותק|העתק"},
            {"What does CPU stand for? Answer in English.","","central processing unit"},
            {"Write one short sentence using the words file and folder. Answer in English.","","file"},
            {"The blue box is empty and the red box contains a pencil. Which box contains the pencil? Answer in English.","","red"},
            {"למה חשוב לתת לקובץ שם ברור?","","שם|שמות|זיהוי|תזהה|לזהות|חיפוש"},
            {"כתוב הודעה קצרה המבקשת לדחות את הפגישה למחר בשעה עשר בבוקר.","","עשר|10"},
            {"Write a short note asking to reschedule a meeting. Answer in English.","","meeting|reschedule|postpone"},
            {"Give three short tips for naming files. Number them 1, 2 and 3. Answer in English.","","1.|1)"}
        };
        int failures=0;
        for(String[] c:cases){
            String prompt=PromptBuilder.build(Arrays.asList(new PromptBuilder.Message("user",c[0])),c[1],0,NativeEngine.modelFamily());
            String raw=new String(NativeEngine.generate(prompt.getBytes(StandardCharsets.UTF_8),128,n->{}),StandardCharsets.UTF_8);
            String clean=new ContentGuard().cleanAnswer(raw);
            String lower=raw.toLowerCase(java.util.Locale.ROOT).replaceAll("\\s+"," ");
            boolean expected=Arrays.stream(c[2].toLowerCase(java.util.Locale.ROOT).split("\\|")).anyMatch(lower::contains);
            boolean valid=!raw.isEmpty()&&!raw.contains("\uFFFD")&&clean.equals(raw.trim())&&expected;
            // A keyword alone can occur in an unrelated or incorrect answer.
            if(c[0].contains("המעבד"))valid&=lower.matches("(?s).*(הוראות|חישוב|מחשב נתונים|מעבד נתונים|עיבוד).*" );
            if(c[0].contains("זיכרון RAM"))valid&=lower.contains("זמנ")||lower.contains("בזמן שהמחשב פועל")||lower.contains("כל עוד המחשב פועל");
            if(c[0].contains("בין קובץ לתיקייה"))valid&=lower.contains("תיקיי")&&lower.matches("(?s).*(מכיל|מכילה|קבצים|אחסון|מאחסן).*" );
            if(c[0].endsWith("Answer in English."))valid&=!raw.matches("(?s).*[\\u0590-\\u05ff].*");
            if(c[0].contains("למורה"))valid&=!raw.contains("אני כאן כדי לעזור");
            if(c[0].startsWith("Write a short note"))valid&=lower.matches("(?s).*(please|could|would|request|can we).*" )&&!lower.contains("not possible")&&!lower.contains("cannot");
            if(c[0].startsWith("Give three")){
                String[] parts=raw.trim().split("(?:^|\\s)[1-3][.)]\\s*",-1);
                valid&=parts.length==4;
                if(parts.length==4)for(int i=1;i<4;i++)valid&=parts[i].matches("(?s).*[A-Za-z].*");
            }
            System.out.println((valid?"PASS":"FAIL")+": "+c[0]+"\n"+raw+"\n");
            if(!valid)failures++;
        }
        NativeEngine.close();
        if(failures>0)throw new AssertionError(failures+" semantic smoke tests failed; do not release this candidate");
        System.out.println("PASS: fifteen semantic smoke tests. Manual review is still required.");
    }
}
