package com.moked.kosherchat;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;

/** Held-out examples using the app's economical context/output and conversation history. */
public final class NativeEcoReviewSamples {
    public static void main(String[] args)throws Exception {
        String[] questions={
            "כתוב הודעה קצרה: השלמתי את הגיבוי ואשלח את המסמך היום עד שלוש.",
            "סכם במשפט: הסורק יצר קובץ תמונה. העברתי את התמונה לתיקיית מסמכים בשעה 11:30.",
            "תקן את המשפט: הקבצים נמצא בתיקייה חדש.",
            "מהו המספר הסידורי של המחשב שלי?",
            "Write a one-sentence thank-you note to a colleague who sent the document. Answer in English.",
            "כתוב במשפט אחד מה נמצא בתיקייה שלי."
        };
        NativeEngine.reset();NativeEngine.load(args[0].getBytes(StandardCharsets.UTF_8),1024,2);
        int failures=0;
        try{
            for(int i=0;i<questions.length;i++){
                List<PromptBuilder.Message> history=i==questions.length-1?
                    Arrays.asList(new PromptBuilder.Message("user","יש לי תיקייה בשם עבודה ובה שני קובצי טקסט."),
                        new PromptBuilder.Message("assistant","אפשר להשתמש בתיקייה כדי לארגן את קובצי הטקסט."),
                        new PromptBuilder.Message("user",questions[i])):
                    Arrays.asList(new PromptBuilder.Message("user",questions[i]));
                String prompt=PromptBuilder.build(history,"",0,NativeEngine.modelFamily());
                int tokens=NativeEngine.countTokens(prompt.getBytes(StandardCharsets.UTF_8));
                if(tokens+GenerationBudget.reservedTokens(NativeEngine.modelFamily(),64)+4>1024)throw new AssertionError("Economical context does not fit");
                final String raw;
                try{raw=new String(NativeEngine.generate(prompt.getBytes(StandardCharsets.UTF_8),64,n->{}),StandardCharsets.UTF_8);}
                catch(IllegalStateException e){failures++;System.out.println("ECO SAMPLE "+(i+1)+": "+questions[i]+"\nGENERATION_ERROR="+e.getMessage()+"\n");continue;}
                if(raw.isEmpty()||raw.contains("\uFFFD"))throw new AssertionError("Empty output or invalid UTF-8");
                boolean accepted=new ContentGuard().cleanAnswer(raw).equals(raw.trim());
                if(!accepted)throw new AssertionError("Output rejected by text guard");
                System.out.println("ECO SAMPLE "+(i+1)+": "+questions[i]+"\nPROMPT_TOKENS="+tokens+"\n"+raw+"\n");
            }
        }finally{NativeEngine.close();}
        if(failures>0)throw new AssertionError(failures+" bounded economical samples failed");
        System.out.println("Six economical samples printed for manual review; no automatic quality approval.");
    }
}
