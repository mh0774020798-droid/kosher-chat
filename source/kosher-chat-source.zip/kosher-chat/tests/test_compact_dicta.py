import sys
from pathlib import Path
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from compact_dicta import byte_decoder, select

class DictaVocabularyTests(unittest.TestCase):
    def setUp(self):
        self.encoder={v:k for k,v in byte_decoder().items()}
    def token(self,raw):
        return ''.join(self.encoder[b] for b in raw)
    def test_hebrew_complete_and_partial_byte_tokens_preserved(self):
        tokens=[self.token(b) for b in (b'a',b'\xd7',b'\xa9',b'\xd7\xa9',b'\xe4\xbd\xa0')]+['<|im_end|>']
        selected,merges,info=select(tokens,[1]*5+[3],[tokens[1]+' '+tokens[2]],[5],5)
        self.assertEqual(selected,[0,1,2,3,5])
        self.assertEqual(len(merges),1)
        self.assertEqual(info['protectedHebrewByteTokens'],2)
    def test_special_id_and_all_single_bytes_survive(self):
        tokens=[self.token(bytes([i])) for i in range(256)]+['<|im_end|>','rareother']
        selected,_,_=select(tokens,[1]*256+[3,1],[],[256],257)
        self.assertEqual(selected,list(range(257)))
    def test_merge_parents_are_kept_with_selected_word(self):
        tokens=['com','puter','computer','<|im_end|>']
        selected,merges,_=select(tokens,[1,1,1,3],['com puter'],[3],4)
        self.assertEqual(selected,[0,1,2,3])
        self.assertEqual(merges,['com puter'])
    def test_budget_cannot_remove_mandatory_tokens(self):
        with self.assertRaises(ValueError):
            select(['a','b','<|im_end|>'],[1,1,3],[],[2],2)
    def test_technical_words_keep_uppercase_and_boundary_variants(self):
        tokens=['CPU','cpu',self.token(b' CPU'),'rareother','<|im_end|>']
        selected,_,_=select(tokens,[1,1,1,1,3],[],[4],4)
        self.assertEqual(selected,[0,1,2,4])

if __name__=='__main__':unittest.main()
