package com.moked.kosherchat;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Actual JNI loading from an aligned offset, independent of Android installation. */
public final class NativeAssetTests {
    public static void main(String[] args)throws Exception {
        try(FileInputStream input=new FileInputStream(args[0])){
            java.lang.reflect.Field field=FileDescriptor.class.getDeclaredField("fd");
            field.setAccessible(true);
            NativeEngine.reset();
            NativeEngine.loadAsset(field.getInt(input.getFD()),Long.parseLong(args[1]),1024,2);
            try{
                int expectedFamily=args.length>2?Integer.parseInt(args[2]):4;
                if(NativeEngine.modelFamily()!=expectedFamily)throw new AssertionError("Unexpected embedded model family");
                String prompt=PromptBuilder.build(Arrays.asList(new PromptBuilder.Message("user","הסבר מה ההבדל בין קובץ לתיקייה.")),"",0,expectedFamily);
                byte[] bytes=NativeEngine.generate(prompt.getBytes(StandardCharsets.UTF_8),64,n->{});
                boolean truncated=NativeEngine.generationTruncated();
                String output=AnswerCompletion.decode(bytes,truncated);
                if(output.isEmpty()||output.contains("\uFFFD"))throw new AssertionError("Empty output or invalid UTF-8");
                if(!new ContentGuard().cleanAnswer(output).equals(output.trim()))throw new AssertionError("Output rejected by text guard");
                String completed=AnswerCompletion.completePart(output,truncated);
                if(completed.isEmpty()||!new ContentGuard().cleanAnswer(completed).equals(completed))throw new AssertionError("No valid completed text for the application");
                if(truncated&&completed.length()>=output.length())throw new AssertionError("Unfinished final text was not removed");
                System.out.println(completed+"\nTRUNCATED="+truncated+"\nPASS: actual JNI loading, generation and app completion handling from APK offset; family="+expectedFamily);
            }finally{NativeEngine.close();}
        }
    }
}
