import hashlib
import io
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from fetch_candidate import CANDIDATES, fetch

class Response(io.BytesIO):
    def __init__(self,content,status=200,headers=None):
        super().__init__(content);self.status=status;self.headers=headers or {}

class CandidateResumeTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.directory=Path(self.temp.name)
        self.data=b'original pinned weight bytes'
        candidate=('example/model','a'*40,'weights.bin',len(self.data),hashlib.sha256(self.data).hexdigest())
        p=patch.dict(CANDIDATES,{'test-pin':candidate});p.start();self.addCleanup(p.stop)

    def test_complete_response_is_verified(self):
        with patch('urllib.request.urlopen',return_value=Response(self.data)):
            result=fetch('test-pin',self.directory,single_stream=True)
        self.assertEqual(result.read_bytes(),self.data)

    def test_resume_requires_exact_range(self):
        part=self.directory/'weights.bin.part';part.write_bytes(self.data[:8])
        headers={'Content-Range':f'bytes 8-{len(self.data)-1}/{len(self.data)}'}
        with patch('urllib.request.urlopen',return_value=Response(self.data[8:],206,headers)) as request:
            result=fetch('test-pin',self.directory,single_stream=True)
        self.assertEqual(request.call_args.args[0].get_header('Range'),f'bytes=8-{len(self.data)-1}')
        self.assertEqual(result.read_bytes(),self.data)

    def test_ignored_range_does_not_overwrite_prefix(self):
        part=self.directory/'weights.bin.part';part.write_bytes(self.data[:8])
        with patch('urllib.request.urlopen',return_value=Response(self.data)):
            with self.assertRaisesRegex(ValueError,'exact resume range'):
                fetch('test-pin',self.directory,single_stream=True)
        self.assertEqual(part.read_bytes(),self.data[:8])

    def test_wrong_range_does_not_append(self):
        part=self.directory/'weights.bin.part';part.write_bytes(self.data[:8])
        with patch('urllib.request.urlopen',return_value=Response(self.data[8:],206,{'Content-Range':'bytes 9-20/21'})):
            with self.assertRaisesRegex(ValueError,'exact resume range'):
                fetch('test-pin',self.directory,single_stream=True)
        self.assertEqual(part.read_bytes(),self.data[:8])

    def test_bad_resumed_prefix_fails_full_checksum(self):
        part=self.directory/'weights.bin.part';part.write_bytes(b'changed!')
        headers={'Content-Range':f'bytes 8-{len(self.data)-1}/{len(self.data)}'}
        with patch('urllib.request.urlopen',return_value=Response(self.data[8:],206,headers)):
            with self.assertRaisesRegex(ValueError,'checksum mismatch'):
                fetch('test-pin',self.directory,single_stream=True)
        self.assertFalse((self.directory/'weights.bin').exists())
        self.assertFalse(part.exists())

    def test_short_response_preserves_resumable_prefix(self):
        with patch('urllib.request.urlopen',return_value=Response(self.data[:8])):
            with self.assertRaisesRegex(ValueError,'Download incomplete'):
                fetch('test-pin',self.directory,single_stream=True)
        self.assertEqual((self.directory/'weights.bin.part').read_bytes(),self.data[:8])

    def test_complete_partial_is_hashed_without_network(self):
        (self.directory/'weights.bin.part').write_bytes(self.data)
        with patch('urllib.request.urlopen') as request:
            result=fetch('test-pin',self.directory,single_stream=True)
        request.assert_not_called()
        self.assertEqual(result.read_bytes(),self.data)

if __name__=='__main__':unittest.main()
