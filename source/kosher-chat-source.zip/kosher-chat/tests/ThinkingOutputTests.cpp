#include "../app/src/main/cpp/thinking_output.h"
#include <iostream>
#include <stdexcept>
#include <string>

static int checks = 0;
static void check(bool value, const std::string &name) {
    ++checks;
    if (!value) throw std::runtime_error(name);
}
static void fails(ThinkingOutput &out, const std::string &code) {
    bool rejected = false;
    try { out.finish(); }
    catch (const std::runtime_error &e) { rejected = e.what() == code; }
    check(rejected, code);
}

int main() {
    const std::string private_text = "This is internal text. ";
    const std::string public_text = "\n\nהתיקייה מכילה שני קבצים.";
    const std::string sequence = private_text + "</think>" + public_text;
    // Every possible chunk boundary, including inside UTF-8 and the delimiter.
    for (size_t split = 0; split <= sequence.size(); ++split) {
        ThinkingOutput out(true);
        out.append(sequence.substr(0, split));
        out.append(sequence.substr(split));
        check(out.finish() == public_text, "split-boundary:" + std::to_string(split));
    }
    ThinkingOutput bytes(true);
    for (char ch : sequence) bytes.append(std::string(1, ch));
    check(bytes.finish() == public_text, "one-byte-pieces");
    ThinkingOutput bounded(true);
    for (int n = 0; n < 10000; ++n) bounded.append(private_text);
    bounded.append("</think>Answer");
    check(bounded.finish() == "Answer", "discard-all-private-text");
    ThinkingOutput unfinished(true);
    unfinished.append(private_text);
    fails(unfinished, "THINKING_INCOMPLETE");
    ThinkingOutput partial(true);
    partial.append("private</thin");
    fails(partial, "THINKING_INCOMPLETE");
    ThinkingOutput empty(true);
    empty.append("private</think>\n \t");
    fails(empty, "THINKING_EMPTY_ANSWER");
    ThinkingOutput reopened(true);
    reopened.append("private</think>answer<think>secret");
    fails(reopened, "THINKING_FORMAT_INVALID");
    ThinkingOutput duplicate(true);
    duplicate.append("private</think>answer</think>");
    fails(duplicate, "THINKING_FORMAT_INVALID");
    ThinkingOutput legacy(false);
    legacy.append("Normal "); legacy.append("תשובה");
    check(legacy.finish() == "Normal תשובה", "ordinary-model-preserved");
    std::cout << "PASS: " << checks << " thinking-output checks\n";
}
