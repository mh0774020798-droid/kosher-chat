"""Fetch exact upstream experiment weights. This never approves or bundles them."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import urllib.request

CANDIDATES = {
    'qwen35-q4': ('ggml-org/Qwen3.5-0.8B-GGUF', '8fea620810c4afa23dd6443f999a48574c1611a3',
                  'Qwen3.5-0.8B-Q4_0.gguf', 563036064, '57d1997790d1744fba5b40a7317df71ea5e2acee28c47e78f0cce39c0703f8cf'),
    'qwen35-bf16': ('ggml-org/Qwen3.5-0.8B-GGUF', '8fea620810c4afa23dd6443f999a48574c1611a3',
                    'Qwen3.5-0.8B-BF16.gguf', 1557662496, '9a7bed4041b7975e0f71fa34670d1e9025213bc92905ac0db75d36c4fa3fa623'),
    'qwen3-q8': ('Qwen/Qwen3-0.6B-GGUF', '23749fefcc72300e3a2ad315e1317431b06b590a',
                 'Qwen3-0.6B-Q8_0.gguf', 639446688, '9465e63a22add5354d9bb4b99e90117043c7124007664907259bd16d043bb031'),
    'qwen3-1.7-f16': ('ggml-org/Qwen3-1.7B-GGUF', 'daeb8e2d528a760970442092f6bf1e55c3b659eb',
                      'Qwen3-1.7B-f16.gguf', 4069679200, 'f116fb8bb3237b7ee6acb2ea5058f4459ec6eb83f9bdbc890035935d45086a72'),
    'gemma3-q4ks': ('bartowski/google_gemma-3-1b-it-GGUF', '116f76234503685a98f572982177b11d44ec8ff1',
                    'google_gemma-3-1b-it-Q4_K_S.gguf', 780993280, 'f625ed640ed403aa7657dbd2d2b783ade13974883c1c26688b4c6c2d345c9b9e'),
    'qwen35-2b-iq3': ('unsloth/Qwen3.5-2B-GGUF', 'f6d5376be1edb4d416d56da11e5397a961aca8ae',
                      'Qwen3.5-2B-UD-IQ3_XXS.gguf', 931823872, '36347f47f9eab7d433c7c37be1f87ac2253378c3d530da3cb25fb5f71f8f1a58'),
    'qwen35-2b-bf16': ('unsloth/Qwen3.5-2B-GGUF', 'f6d5376be1edb4d416d56da11e5397a961aca8ae',
                       'Qwen3.5-2B-BF16.gguf', 3775709216, 'dc11be2ca4519954a3e4b013ef59497b5522209987d67891851113eda89619f1'),
    'dicta-instruct-bf16': ('dicta-il/DictaLM-3.0-1.7B-Instruct', '5add44d6941d6ffb9eb6cc6b516f9fb4fd472494',
                           'model.safetensors', 3441185576, 'e5caa19697d69a45380861dd4af6efa043c17da4466f1d92045d7557aa998e21'),
    'dicta-thinking-bf16': ('dicta-il/DictaLM-3.0-1.7B-Thinking', '43e2fac285633ab440577ce5bcd7223e277cb3a2',
                           'model.safetensors', 3441185576, 'cec0cdb331e6c4148b17593527f0a5be3b2562a54aa3afc145aabd580c943fea'),
}

def digest(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

def fetch(name, directory, single_stream=False):
    repo, revision, filename, size, sha = CANDIDATES[name]
    directory.mkdir(parents=True, exist_ok=True)
    output = directory / filename
    if output.exists():
        if output.stat().st_size != size or digest(output) != sha:
            raise ValueError('Existing candidate differs from upstream pin')
        return output
    temporary = output.with_name(output.name+'.part')
    url = f'https://huggingface.co/{repo}/resolve/{revision}/{filename}?download=true'
    if single_stream:
        completed=temporary.stat().st_size if temporary.exists() else 0
        if completed>size:raise ValueError('Existing partial candidate exceeds pinned size')
        if completed<size:
            headers={'Accept-Encoding':'identity'}
            if completed:headers['Range']=f'bytes={completed}-{size-1}'
            request=urllib.request.Request(url,headers=headers)
            with urllib.request.urlopen(request,timeout=60) as response:
                if completed:
                    if response.status!=206 or response.headers.get('Content-Range')!=f'bytes {completed}-{size-1}/{size}':
                        raise ValueError('Upstream did not honor the exact resume range')
                elif response.status!=200:raise ValueError('Expected a complete upstream response')
                with temporary.open('ab') as target:
                    while True:
                        data=response.read(8*1024*1024)
                        if not data:break
                        if completed+len(data)>size:raise ValueError('Upstream response exceeds pinned file size')
                        target.write(data);completed+=len(data)
                        if completed%(128*1024*1024)==0:print(f'{filename}: {completed}/{size}',flush=True)
        if temporary.stat().st_size!=size:raise ValueError('Download incomplete; verified resume is available')
        if digest(temporary)!=sha:
            temporary.unlink()
            raise ValueError('Downloaded candidate checksum mismatch')
        temporary.replace(output)
        output.with_suffix('.provenance.json').write_text(json.dumps({
            'status':'experimental; not approved for release','upstreamRepository':repo,'revision':revision,
            'filename':filename,'bytes':size,'sha256':sha,'license':'Gemma' if name.startswith('gemma3') else 'Apache-2.0',
            'vocabularyPruned':False,'decoderLayersRemoved':0},indent=2)+'\n')
        return output
    with temporary.open('wb') as target:
        target.truncate(size)
    def transfer(bounds):
        start, stop = bounds
        for attempt in range(3):
            try:
                request = urllib.request.Request(url+f'&first={start}&last={stop}', headers={'Range':f'bytes={start}-{stop}', 'Accept-Encoding':'identity'})
                with urllib.request.urlopen(request, timeout=60) as response:
                    if response.status != 206 or response.headers.get('Content-Range') != f'bytes {start}-{stop}/{size}':
                        raise ValueError('Unexpected range response')
                    data = response.read(stop-start+2)
                if len(data) != stop-start+1:
                    raise ValueError('Incomplete range response')
                with temporary.open('r+b') as target:
                    target.seek(start); target.write(data)
                return len(data)
            except Exception:
                if attempt == 2: raise
    chunk = 32*1024*1024
    bounds = [(start, min(start+chunk, size)-1) for start in range(0, size, chunk)]
    try:
        completed = 0
        with ThreadPoolExecutor(max_workers=4) as pool:
            for count in pool.map(transfer, bounds):
                completed += count
                print(f'{filename}: {completed}/{size}', flush=True)
        if temporary.stat().st_size != size or digest(temporary) != sha:
            raise ValueError('Downloaded candidate checksum mismatch')
        os.replace(temporary, output)
        output.with_suffix('.provenance.json').write_text(json.dumps({
            'status':'experimental; not approved for release', 'upstreamRepository':repo,
            'revision':revision,'filename':filename,'bytes':size,'sha256':sha,
            'license':'Gemma' if name.startswith('gemma3') else 'Apache-2.0',
            'vocabularyPruned':False,'decoderLayersRemoved':0,
        }, indent=2)+'\n')
    finally:
        temporary.unlink(missing_ok=True)
    return output

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('candidate', choices=CANDIDATES)
    parser.add_argument('--directory', required=True, type=Path)
    parser.add_argument('--single-stream',action='store_true')
    args = parser.parse_args()
    print('Verified experimental candidate:', fetch(args.candidate,args.directory,args.single_stream))

if __name__ == '__main__':main()
