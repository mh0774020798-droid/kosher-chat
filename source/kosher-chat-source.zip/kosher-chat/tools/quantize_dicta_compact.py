"""Quantize a verified Hebrew-preserving Dicta derivative with bound calibration."""
import argparse
import json
from pathlib import Path
import subprocess
from fetch_candidate import CANDIDATES, digest
from calibrate_compact import validate_imatrix

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--tool',required=True,type=Path);p.add_argument('--imatrix',required=True,type=Path)
    a=p.parse_args()
    recipe=json.loads(a.source.with_suffix('.recipe.json').read_text())
    original=recipe['conversion']
    repo,revision,_,size,sha=CANDIDATES['dicta-instruct-bf16']
    if any(original.get(k)!=v for k,v in {'upstreamRepository':repo,'revision':revision,
        'sourceBytes':size,'sourceSha256':sha,'vocabularyPruned':False,'decoderLayersRemoved':0}.items()):
        raise ValueError('Source was not converted from pinned original DictaLM')
    selected=recipe['retainedOriginalTokenIds']
    if recipe['sha256']!=digest(a.source) or recipe['bytes']!=a.source.stat().st_size or \
        recipe['decoderLayersRemoved']!=0 or recipe['protectedHebrewByteTokens']!=3178 or \
        len(selected)!=recipe['vocabularySize'] or len(set(selected))!=len(selected):
        raise ValueError('Derivative recipe does not match')
    binding=json.loads(a.imatrix.with_suffix('.calibration.json').read_text())
    if binding['sourceModelSha256']!=recipe['sha256'] or binding['imatrixSha256']!=digest(a.imatrix):
        raise ValueError('Calibration is not bound to this derivative')
    validate_imatrix(a.imatrix)
    if a.output.exists() or a.output.with_suffix('.recipe.json').exists():raise ValueError('Output must be new')
    temporary=a.output.with_suffix('.gguf.part')
    command=[str(a.tool.resolve()),'--pure','--token-embedding-type','q5_k','--output-tensor-type','q5_k',
        '--imatrix',str(a.imatrix),'--max-buffer-size','256',str(a.source),str(temporary),'IQ4_XS','4']
    try:
        subprocess.run(command,check=True)
        if temporary.stat().st_size>795_500_000:raise ValueError('Model exceeds bundled APK budget')
        temporary.replace(a.output)
    finally:temporary.unlink(missing_ok=True)
    result={'status':'experimental; manual inference review required before registration',
        'derivation':recipe,'quantization':'IQ4_XS decoder; Q5_K tied embedding',
        'command':command,'quantizerSha256':digest(a.tool),'calibration':binding,
        'decoderLayersRemoved':0,'vocabularyPruned':True,'vocabularySize':recipe['vocabularySize'],
        'bytes':a.output.stat().st_size,'sha256':digest(a.output),'license':'Apache-2.0'}
    a.output.with_suffix('.recipe.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='derivation'},indent=2))

if __name__=='__main__':main()
