"""Validate a signed release APK without installing it. Run on the build computer."""
import argparse, hashlib, json, pathlib, re, struct, subprocess, zipfile
from model_catalog import ROOT, identify, owner_certificate, model_specs, BUNDLED_MODEL, MAX_APK_BYTES

def offset(file,info):
    file.seek(info.header_offset);header=file.read(30)
    name,extra=struct.unpack_from('<HH',header,26)
    return info.header_offset+30+name+extra

def elf_alignment(data):
    if data[:4]!=b'\x7fELF' or data[5]!=1:raise ValueError('Expected little-endian ELF')
    if data[4]==2:
        phoff=struct.unpack_from('<Q',data,32)[0];entry,count=struct.unpack_from('<HH',data,54);align_index=48;align_format='<Q'
    else:
        phoff=struct.unpack_from('<I',data,28)[0];entry,count=struct.unpack_from('<HH',data,42);align_index=28;align_format='<I'
    alignments=[]
    for i in range(count):
        position=phoff+i*entry
        if struct.unpack_from('<I',data,position)[0]==1:
            alignments.append(struct.unpack_from(align_format,data,position+align_index)[0])
    if not alignments or min(alignments)<16384:raise ValueError('Native library is not compatible with 16 KB pages')
    return alignments

def main():
    p=argparse.ArgumentParser();p.add_argument('--apk',required=True);p.add_argument('--sdk',required=True);p.add_argument('--lite',action='store_true');p.add_argument('--legacy-gemma3',action='store_true');a=p.parse_args()
    apk=pathlib.Path(a.apk);tools=pathlib.Path(a.sdk)/'build-tools/35.0.0'
    if apk.stat().st_size>MAX_APK_BYTES:raise ValueError('APK exceeds 800 MB')
    signer=subprocess.run([str(tools/'apksigner'),'verify','--verbose','--print-certs',str(apk)],capture_output=True,text=True,check=True).stdout
    subprocess.run([str(tools/'zipalign'),'-P','16','-c','4',str(apk)],check=True)
    badging=subprocess.run([str(tools/'aapt2'),'dump','badging',str(apk)],capture_output=True,text=True,check=True).stdout
    if 'android.permission.INTERNET' in badging:raise ValueError('Unexpected Internet permission')
    if "package: name='com.moked.kosherchat'" not in badging:raise ValueError('Unexpected application ID')
    version=re.search(r"versionCode='(\d+)' versionName='([^']+)'",badging)
    if not version:raise ValueError('APK version metadata is missing')
    if not a.legacy_gemma3:
        build=(ROOT/'app/build.gradle').read_text()
        expected_code=int(re.search(r'\bversionCode\s+(\d+)',build)[1])
        expected_name=re.search(r"\bversionName\s+'([^']+)'",build)[1]
        if int(version[1])!=expected_code or version[2]!=expected_name:raise ValueError('APK does not match this release version')
    if 'application-debuggable' in badging:raise ValueError('Release is debuggable')
    if "minSdkVersion:'23'" not in badging or "targetSdkVersion:'35'" not in badging:raise ValueError('SDK versions differ')
    manifest=subprocess.run([str(tools/'aapt2'),'dump','xmltree','--file','AndroidManifest.xml',str(apk)],capture_output=True,text=True,check=True).stdout
    extracts_native=bool(re.search(r'android:extractNativeLibs[^\n]*=(?:true|\(type 0x12\)0xffffffff)\b',manifest))
    result={'apk':apk.name,'versionCode':int(version[1]),'versionName':version[2],'bytes':apk.stat().st_size,'internet_permission':False,'native':{}}
    with zipfile.ZipFile(apk) as archive,apk.open('rb') as file:
        expected={'lib/arm64-v8a/libkosherchat.so','lib/armeabi-v7a/libkosherchat.so'}
        libs={name for name in archive.namelist() if name.endswith('.so')}
        if libs!=expected:raise ValueError('Expected both release ARM libraries only')
        for name in sorted(libs):
            info=archive.getinfo(name);position=offset(file,info)
            if info.compress_type==zipfile.ZIP_STORED:
                if position%16384:raise ValueError('Native ZIP alignment mismatch')
            elif info.compress_type!=zipfile.ZIP_DEFLATED or not extracts_native:
                raise ValueError('Compressed native libraries require extraction on install')
            result['native'][name]={'offset':position,'compression':'stored' if info.compress_type==zipfile.ZIP_STORED else 'deflate','extracted_on_install':extracts_native,'segment_alignments':elf_alignment(archive.read(name))}
        has_model='assets/model.gguf' in archive.namelist()
        if has_model==a.lite:raise ValueError('Model flavor mismatch')
        if has_model:
            info=archive.getinfo('assets/model.gguf');position=offset(file,info)
            if info.compress_type!=zipfile.ZIP_STORED or position%32:raise ValueError('Model mmap alignment mismatch')
            with archive.open(info) as source:sha=hashlib.file_digest(source,'sha256').hexdigest()
            expected=model_specs()['GEMMA3' if a.legacy_gemma3 else BUNDLED_MODEL]
            spec=identify(info.file_size,sha,expected['family'])
            if spec!=expected:raise ValueError('APK does not include this release exact model pin')
            result['model']={'bytes':info.file_size,'offset':position,'sha256':sha,'family':spec['family'],'label':spec['label']}
    with apk.open('rb') as source:result['sha256']=hashlib.file_digest(source,'sha256').hexdigest()
    result['certificate_sha256']=next(line.split(':',1)[1].strip() for line in signer.splitlines() if 'certificate SHA-256 digest:' in line)
    if result['certificate_sha256']!=owner_certificate():raise ValueError('APK is not signed by the original owner')
    result['signatures_verified']={name:bool(re.search(r'Verified using '+name+r' scheme[^\n]*: true',signer)) for name in ['v1','v2','v3']}
    if not all(result['signatures_verified'].values()):raise ValueError('Expected all APK signature schemes')
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
