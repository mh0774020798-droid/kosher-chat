"""Create a signed offline update. Keep the private key outside public projects."""
import argparse, datetime, hashlib, json, pathlib, zipfile
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

def build(private_key,output,version,knowledge=None,model=None,additional_filter=None):
    if version<1:raise ValueError('Version must be positive and greater than the installed data version')
    inputs={'knowledge.json':knowledge,'model.gguf':model,'additional-filter.json':additional_filter}
    files={}
    for name,value in inputs.items():
        if not value:continue
        path=pathlib.Path(value);size=path.stat().st_size
        maximum=3400000000 if name=='model.gguf' else 2000000 if name=='knowledge.json' else 128000
        if not path.is_file() or not 1<=size<=maximum:raise ValueError('Unsupported file size: '+name)
        if name!='model.gguf':json.loads(path.read_text(encoding='utf-8'))
        with path.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
        files[name]={'sha256':sha,'size':size}
    if not files:raise ValueError('Provide at least one input file')
    manifest=json.dumps({'format':'kchat-update-v1','version':version,'created_at':datetime.date.today().isoformat(),'files':files},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
    key=serialization.load_pem_private_key(pathlib.Path(private_key).read_bytes(),password=None)
    signature=key.sign(manifest,padding.PKCS1v15(),hashes.SHA256())
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_STORED,allowZip64=True) as z:
        z.writestr('manifest.json',manifest);z.writestr('manifest.sig',signature)
        for name in files:z.write(inputs[name],name)
    return output

def main():
    p=argparse.ArgumentParser();p.add_argument('--key',required=True);p.add_argument('--out',required=True);p.add_argument('--version',type=int,required=True);p.add_argument('--knowledge');p.add_argument('--model');p.add_argument('--filter');a=p.parse_args()
    build(a.key,a.out,a.version,a.knowledge,a.model,a.filter);print('Signed update created:',a.out)
if __name__=='__main__':main()
