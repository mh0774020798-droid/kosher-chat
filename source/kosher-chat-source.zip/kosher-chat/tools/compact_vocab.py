#!/usr/bin/env python3
"""Experimental vocabulary pruning; preserve every Hebrew token and decoder layer."""
import argparse
import json
from pathlib import Path
import re
import sys
import numpy as np
from wordfreq import zipf_frequency
from model_catalog import digest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'vendor/llama.cpp/gguf-py'))
from gguf import GGUFReader, GGUFWriter, GGUFValueType

SOURCE_SHA = '8e30dff3ac4c8434c49a7036fa15564bdbb6044e42bf04550bf1a096ad7e6a52'
SOURCE_REVISION = 'b4243c156154b6dca9324415f8c7ccc098b4aed1'
PROTECTED_WORDS = set('''android java python javascript html css api apk ram cpu usb wifi bluetooth linux windows json file folder computer model offline application memory backup battery screen hardware software internet english hebrew
central processing unit random access operating system interface programming processor data temporary storage copy save document network device security update install version
keyboard mouse printer cable monitor message note meeting question answer reply respond explain write tell describe summarize summary translate list name title tip give time tomorrow schedule reschedule please what where when why how who which
is are the to of in on for and or with my your it can has yes no not only do does should'''.split())

def select_vocabulary(reader, max_tokens):
    tokens = reader.fields['tokenizer.ggml.tokens'].contents()
    types = reader.fields['tokenizer.ggml.token_type'].contents()
    merges = reader.fields['tokenizer.ggml.merges'].contents()
    ids = {t: i for i, t in enumerate(tokens)}
    parents = {}
    for merge in merges:
        left, right = merge.split(' ', 1)
        if left in ids and right in ids and left + right in ids:
            parents.setdefault(ids[left + right], (ids[left], ids[right]))
    def closure(start):
        found = set(start)
        stack = list(start)
        while stack:
            for parent in parents.get(stack.pop(), ()):
                if parent not in found:
                    found.add(parent)
                    stack.append(parent)
        return found
    hebrew = {i for i, t in enumerate(tokens) if re.search('[\u0590-\u05ff]', t)}
    byte_ids = {i for i, t in enumerate(types) if t == 6}
    protected = {i for i,t in enumerate(tokens) if t.replace('▁','').strip().lower() in PROTECTED_WORDS}
    mandatory = hebrew | byte_ids | protected | {i for i,t in enumerate(types) if t in (3,4)}
    mandatory |= {i for i,t in enumerate(tokens) if len(t)==1 and (t.isascii() or t=='▁')}
    for name, f in reader.fields.items():
        if name.startswith('tokenizer.ggml.') and name.endswith('_token_id'):
            mandatory.add(f.contents())
    kept = closure(mandatory)
    if len(kept)>max_tokens:
        raise ValueError(f'Mandatory token and merge closure needs {len(kept)} tokens')
    lexemes = {}
    frequencies = {}
    english = []
    for i,t in enumerate(tokens):
        if types[i] in (5,6) or not all(c.isascii() or c=='▁' for c in t):
            continue
        word = t.replace('▁','').strip().lower()
        freq = zipf_frequency(word,'en') if word.isalpha() and len(word)>=2 else 0
        frequencies[i] = freq
        english.append(i)
        if freq>=2.5:
            lexemes.setdefault(word,[]).append(i)
    primary = [min(variants,key=lambda i:(not tokens[i].startswith('▁'),i)) for variants in lexemes.values()]
    primary_set = set(primary)
    secondary = [i for i in english if i not in primary_set]
    for group in (primary,secondary):
        for i in sorted(group,key=lambda i:(-frequencies[i],i)):
            additions = closure([i])-kept
            if len(kept)+len(additions)<=max_tokens:
                kept.update(additions)
    selected = sorted(kept)
    filtered_merges = [m for m in merges if all(ids.get(t) in kept for t in (*m.split(' ',1),m.replace(' ', '',1)))]
    recipe = {'status':'experimental derivative, not complete original checkpoint',
        'originalVocabularySize':len(tokens),'vocabularySize':len(selected),
        'englishSelection':'wordfreq 3.1.1; distinct English lexemes before spelling variants; protected instruction/hardware terms; merge closure',
        'hebrewTokensPreserved':len(hebrew),'byteFallbackTokensPreserved':len(byte_ids),
        'technicalWordsPreserved':sorted(PROTECTED_WORDS),'decoderLayersRemoved':0,
        'modifiedEmbeddingTensors':['token_embd.weight','per_layer_token_embd.weight'],
        'retainedOriginalTokenIds':selected}
    return selected,filtered_merges,recipe

def copy_metadata(reader, writer, selected, merges):
    remap = {old:new for new,old in enumerate(selected)}
    for name,f in reader.fields.items():
        if name.startswith('GGUF.'):
            continue
        value = f.contents()
        if name in ('tokenizer.ggml.tokens','tokenizer.ggml.scores','tokenizer.ggml.token_type'):
            value = [value[i] for i in selected]
        elif name=='tokenizer.ggml.merges':
            value = merges
        elif name.startswith('tokenizer.ggml.') and name.endswith('_token_id'):
            value = remap[value]
        elif name=='general.name':
            value = f'Gemma 4 E2B IT experimental Hebrew vocabulary {len(selected)}'
        writer.add_key_value(name,value,f.types[0],f.types[-1] if f.types[0]==GGUFValueType.ARRAY else None)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path)
    p.add_argument('output',type=Path)
    p.add_argument('--max-tokens',type=int,default=6800)
    a=p.parse_args()
    if a.output.exists() or a.source.resolve()==a.output.resolve():
        raise ValueError('Output must be a new file')
    if digest(a.source)!=SOURCE_SHA:
        raise ValueError('Source differs from pinned original Q4_0 weights')
    r=GGUFReader(a.source)
    selected,merges,recipe=select_vocabulary(r,a.max_tokens)
    temporary=a.output.with_suffix('.gguf.part')
    w=GGUFWriter(temporary,'gemma4',endianess=r.endianess)
    try:
        copy_metadata(r,w,selected,merges)
        for t in r.tensors:
            data=np.ascontiguousarray(t.data[selected]) if t.name in recipe['modifiedEmbeddingTensors'] else t.data
            w.add_tensor(t.name,data,raw_dtype=t.tensor_type)
        w.write_header_to_file();w.write_kv_data_to_file();w.write_tensors_to_file(progress=False);w.close()
        temporary.replace(a.output)
    finally:
        w.close();temporary.unlink(missing_ok=True)
    recipe.update(sourceRevision=SOURCE_REVISION,sourceSha256=SOURCE_SHA,bytes=a.output.stat().st_size,sha256=digest(a.output))
    a.output.with_suffix('.recipe.json').write_text(json.dumps(recipe,indent=2)+'\n')
    print(json.dumps({k:v for k,v in recipe.items() if k!='retainedOriginalTokenIds'},indent=2))

if __name__=='__main__':
    main()
