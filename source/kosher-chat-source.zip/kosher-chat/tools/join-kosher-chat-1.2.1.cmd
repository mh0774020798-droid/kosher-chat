@echo off
setlocal
cd /d "%~dp0"
set "KOSHER_JOIN_OUTPUT=kosher-chat-1.2.1-full-beta.apk"
set "KOSHER_JOIN_SHA=533c68ba73955ad2a28a0988236dbd07d009440c0ac9023f53aea0c0b98e1d4a"
if exist "%KOSHER_JOIN_OUTPUT%" (
    powershell -NoProfile -Command "if ((Get-FileHash -LiteralPath $env:KOSHER_JOIN_OUTPUT -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant() -ne $env:KOSHER_JOIN_SHA) {exit 1}"
    if errorlevel 1 (
        echo An APK with this name already exists and differs. Rename it before joining.
        pause
        exit /b 1
    )
    echo The verified APK already exists. It is ready to install.
    pause
    exit /b 0
)
if not exist "kosher-chat-1.2.1-full-beta.apk.part1" goto missing
if not exist "kosher-chat-1.2.1-full-beta.apk.part2" goto missing
set "KOSHER_JOIN_OUTPUT=kosher-chat-1.2.1-full-beta.apk.joining"
if exist "%KOSHER_JOIN_OUTPUT%" (
    echo A previous temporary join exists. Rename it before trying again.
    pause
    exit /b 1
)
copy /b "kosher-chat-1.2.1-full-beta.apk.part1"+"kosher-chat-1.2.1-full-beta.apk.part2" "%KOSHER_JOIN_OUTPUT%" >nul
if errorlevel 1 goto failed
powershell -NoProfile -Command "if ((Get-FileHash -LiteralPath $env:KOSHER_JOIN_OUTPUT -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant() -ne $env:KOSHER_JOIN_SHA) {exit 1}"
if errorlevel 1 goto failed
ren "%KOSHER_JOIN_OUTPUT%" "kosher-chat-1.2.1-full-beta.apk"
if errorlevel 1 goto failed
echo SUCCESS: kosher-chat-1.2.1-full-beta.apk is verified and ready to install.
pause
exit /b 0
:missing
echo Download both .part files to this folder before joining.
pause
exit /b 1
:failed
echo The join failed or the files are incomplete. Do not install the temporary file.
pause
exit /b 1
