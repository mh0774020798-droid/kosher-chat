"""Change only the intact Qwen3.5 embedding table; verify all other tensor bytes."""
import argparse
import ctypes as c
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
from fetch_candidate import CANDIDATES, digest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor/llama.cpp/gguf-py'))
from gguf import GGUFReader, GGUFWriter, GGUFValueType, GGUFEndian, GGMLQuantizationType

class TypeTraits(c.Structure):
    _fields_=[('name',c.c_char_p),('block_size',c.c_int64),('interleave',c.c_int64),
              ('type_size',c.c_size_t),('quantized',c.c_bool),('to_float',c.c_void_p),('from_float',c.c_void_p)]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--library',type=Path,required=True)
    p.add_argument('--embedding-type',choices=('IQ4_XS','Q4_K','Q5_K','Q6_K'),default='IQ4_XS')
    p.add_argument('--dry-run',action='store_true');a=p.parse_args()
    repo,revision,filename,size,sha=CANDIDATES['qwen35-2b-iq3']
    if a.source.stat().st_size!=size or digest(a.source)!=sha:raise ValueError('Source differs from pinned upstream model')
    if a.output.exists() or a.output.with_suffix('.recipe.json').exists():raise ValueError('Output must be new')
    r=GGUFReader(a.source)
    if r.endianess!=GGUFEndian.LITTLE or r.fields['general.architecture'].contents()!='qwen35':raise ValueError('Unexpected architecture or byte order')
    if r.fields['qwen35.block_count'].contents()!=24 or r.fields['qwen35.embedding_length'].contents()!=2048:raise ValueError('Not the expected 2B model')
    tensors={t.name:t for t in r.tensors}
    if 'output.weight' in tensors:raise ValueError('Expected tied input/output embeddings')
    t=tensors['token_embd.weight'];rows,width=map(int,t.data.shape[:2])
    width=int(t.shape[0]);rows=int(t.shape[1])
    qtype=GGMLQuantizationType[a.embedding_type]
    lib=c.CDLL(str(a.library.resolve()))
    lib.ggml_get_type_traits.argtypes=[c.c_int];lib.ggml_get_type_traits.restype=c.POINTER(TypeTraits)
    lib.ggml_row_size.argtypes=[c.c_int,c.c_int64];lib.ggml_row_size.restype=c.c_size_t
    lib.ggml_quantize_requires_imatrix.argtypes=[c.c_int];lib.ggml_quantize_requires_imatrix.restype=c.c_bool
    if lib.ggml_quantize_requires_imatrix(int(qtype)):raise ValueError('This table recipe requires a separately bound importance matrix')
    row_bytes=int(lib.ggml_row_size(int(qtype),width))
    projected=size-t.n_bytes+rows*row_bytes
    details={'sourceEmbeddingType':t.tensor_type.name,'targetEmbeddingType':qtype.name,
             'rows':rows,'width':width,'sourceEmbeddingBytes':t.n_bytes,
             'targetEmbeddingBytes':rows*row_bytes,'projectedBytes':projected}
    print(json.dumps(details,indent=2),flush=True)
    if projected>795_490_000:raise ValueError('This precision mix cannot fit the bundled model budget')
    if a.dry_run:return
    traits=lib.ggml_get_type_traits(int(t.tensor_type)).contents
    if not traits.to_float:raise ValueError('Unsupported source table type')
    to_float=c.CFUNCTYPE(None,c.c_void_p,c.c_void_p,c.c_int64)(traits.to_float)
    lib.ggml_quantize_chunk.argtypes=[c.c_int,c.c_void_p,c.c_void_p,c.c_int64,c.c_int64,c.c_int64,c.c_void_p]
    lib.ggml_quantize_chunk.restype=c.c_size_t
    table=np.empty((rows,row_bytes),dtype=np.uint8)
    for first in range(0,rows,512):
        count=min(512,rows-first)
        floats=np.empty((count,width),dtype=np.float32)
        to_float(t.data[first:first+count].ctypes.data,floats.ctypes.data,count*width)
        if not np.all(np.isfinite(floats)):raise ValueError('Nonfinite source embedding')
        written=lib.ggml_quantize_chunk(int(qtype),floats.ctypes.data,table[first:first+count].ctypes.data,0,count,width,None)
        if written!=count*row_bytes:raise ValueError('Embedding conversion byte count mismatch')
        if first%(512*32)==0:print(f'Converted {first+count}/{rows} intact embedding rows',flush=True)
    temporary=a.output.with_suffix('.gguf.part')
    w=GGUFWriter(temporary,'qwen35',endianess=r.endianess)
    try:
        for name,f in r.fields.items():
            if name.startswith('GGUF.'):continue
            value=f.contents()
            if name=='general.name':value='Qwen3.5 2B experimental: original dynamic body, intact '+qtype.name+' embeddings'
            w.add_key_value(name,value,f.types[0],f.types[-1] if f.types[0]==GGUFValueType.ARRAY else None)
        for tensor in r.tensors:
            w.add_tensor(tensor.name,table if tensor.name==t.name else tensor.data,
                         raw_dtype=qtype if tensor.name==t.name else tensor.tensor_type)
        w.write_header_to_file();w.write_kv_data_to_file();w.write_tensors_to_file(progress=False);w.close()
        if temporary.stat().st_size>795_500_000:raise ValueError('Written candidate exceeds bundled model budget')
        output=GGUFReader(temporary);out_tensors={x.name:x for x in output.tensors}
        if set(out_tensors)!=set(tensors):raise ValueError('Tensor set changed')
        unchanged=0
        for name,tensor in tensors.items():
            other=out_tensors[name]
            if not np.array_equal(tensor.shape,other.shape):raise ValueError('Tensor dimensions changed')
            if name==t.name:
                if other.tensor_type!=qtype or hashlib.sha256(table).digest()!=hashlib.sha256(other.data).digest():raise ValueError('Converted table differs from output')
            else:
                if tensor.tensor_type!=other.tensor_type or hashlib.sha256(tensor.data).digest()!=hashlib.sha256(other.data).digest():raise ValueError('A decoder tensor changed')
                unchanged+=1
        for name,f in r.fields.items():
            if name.startswith('GGUF.') or name=='general.name':continue
            if output.fields[name].types!=f.types or output.fields[name].contents()!=f.contents():raise ValueError('Model/tokenizer metadata changed: '+name)
        del output
        temporary.replace(a.output)
    finally:
        w.close();temporary.unlink(missing_ok=True)
    recipe={'status':'experimental; quality review required; not release approval',
        'upstreamRepository':repo,'revision':revision,'sourceSha256':sha,'sourceBytes':size,
        'license':'Apache-2.0','vocabularyPruned':False,'decoderLayersRemoved':0,
        'vocabularySize':len(r.fields['tokenizer.ggml.tokens'].contents()),
        'changedTensors':['token_embd.weight'],'unchangedTensorsVerified':unchanged,
        'quantizerLibrarySha256':digest(a.library),'bytes':a.output.stat().st_size,'sha256':digest(a.output),**details}
    a.output.with_suffix('.recipe.json').write_text(json.dumps(recipe,indent=2)+'\n')
    print(json.dumps(recipe,indent=2),flush=True)

if __name__=='__main__':main()
