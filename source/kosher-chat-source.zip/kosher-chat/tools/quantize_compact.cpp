#include <llama.h>
#include <cstdio>
#include <cstring>

int main(int argc, char **argv) {
    if (argc < 3) { std::fprintf(stderr, "usage: quantize_compact input.gguf output.gguf [dry-run]\n"); return 2; }
    auto p = llama_model_quantize_default_params();
    p.nthread = 4;
    p.ftype = LLAMA_FTYPE_MOSTLY_Q2_K;
    p.pure = true;
    p.allow_requantize = true;
    p.token_embedding_type = GGML_TYPE_Q8_0;
    p.output_tensor_type = GGML_TYPE_Q8_0;
    p.dry_run = argc > 3 && std::strcmp(argv[3], "dry-run") == 0;
    const llama_model_tensor_override overrides[] = {
        {"per_layer_token_embd\\.weight", GGML_TYPE_Q4_0},
        {"blk\\.[0-9]+\\.inp_gate\\.weight", GGML_TYPE_Q8_0},
        {"blk\\.[0-9]+\\.proj\\.weight", GGML_TYPE_Q8_0},
        {"blk\\.[0-9]+\\.attn_[qkvo]\\.weight", GGML_TYPE_Q3_K},
        {"blk\\.([0-9]|1[0-4])\\.ffn_(gate|up|down)\\.weight", GGML_TYPE_Q3_K},
        {nullptr, GGML_TYPE_COUNT}
    };
    p.tt_overrides = overrides;
    return llama_model_quantize(argv[1], argv[2], &p);
}
