"""Remove only inactive last-20-layer K/V tensors in the pinned BF16 checkpoint."""
import argparse
import json
from pathlib import Path
import re
import numpy as np
from compact_vocab import GGUFReader, GGUFWriter, GGUFValueType, digest

BF16_SHA='246c5fb19e64b941b531e86639f070bc67b00f20e9ec8556a6c02653321bc65d'

def unused_kv_names(reader):
    if reader.fields['general.architecture'].contents()!='gemma4' or reader.fields['gemma4.block_count'].contents()!=35:
        raise ValueError('Expected Gemma 4 E2B with all 35 decoder layers')
    if reader.fields['gemma4.attention.shared_kv_layers'].contents()!=20:
        raise ValueError('Expected 20 layers sharing K/V')
    expected={f'blk.{i}.attn_{suffix}.weight' for i in range(15,35) for suffix in ('k','v','k_norm')}
    present={t.name for t in reader.tensors}
    if not expected<=present:
        raise ValueError('Incomplete set of expected inactive K/V tensors')
    return expected

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args()
    recipe=json.loads(a.source.with_suffix('.recipe.json').read_text())
    if recipe['sourceSha256']!=BF16_SHA or recipe['decoderLayersRemoved']!=0 or digest(a.source)!=recipe['sha256']:
        raise ValueError('Expected verified BF16-derived source')
    if a.output.exists() or a.source.resolve()==a.output.resolve():raise ValueError('Output must be new')
    r=GGUFReader(a.source);removed=unused_kv_names(r);temporary=a.output.with_suffix('.gguf.part')
    w=GGUFWriter(temporary,'gemma4',endianess=r.endianess)
    try:
        for name,f in r.fields.items():
            if not name.startswith('GGUF.'):
                w.add_key_value(name,f.contents(),f.types[0],f.types[-1] if f.types[0]==GGUFValueType.ARRAY else None)
        for t in r.tensors:
            if t.name not in removed:w.add_tensor(t.name,np.ascontiguousarray(t.data),raw_dtype=t.tensor_type)
        w.write_header_to_file();w.write_kv_data_to_file();w.write_tensors_to_file(progress=False);w.close()
        temporary.replace(a.output)
    finally:
        w.close();temporary.unlink(missing_ok=True)
    recipe.update(parentSha256=recipe['sha256'],removedInactiveKvTensors=sorted(removed),bytes=a.output.stat().st_size,sha256=digest(a.output))
    a.output.with_suffix('.recipe.json').write_text(json.dumps(recipe,indent=2)+'\n')

if __name__=='__main__':main()
