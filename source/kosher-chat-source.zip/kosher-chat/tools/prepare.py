"""Fetch pinned source weights on a COMPUTER; stage only an approved compact model."""
import argparse
import os
from pathlib import Path
import shutil
import tarfile
import urllib.request
from model_catalog import ROOT, SOURCES, digest, model_specs, verify_bundled

LLAMA_URL = 'https://codeload.github.com/ggml-org/llama.cpp/tar.gz/refs/tags/v0.6.0'
LLAMA_SHA = '09b36dba235fcac180efff18514da7038e65d8e5b9e4aefa59238468abfdec12'

def download(url, path, sha):
    if path.exists():
        if digest(path) != sha:
            raise ValueError('Existing file checksum mismatch')
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.part')
    try:
        with urllib.request.urlopen(url, timeout=120) as response, temporary.open('wb') as target:
            shutil.copyfileobj(response, target, 8 * 1024 * 1024)
        if digest(temporary) != sha:
            raise ValueError('Downloaded file checksum mismatch')
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--with-model', action='store_true')
    p.add_argument('--source', choices=SOURCES, default='gemma4-source')
    p.add_argument('--model-file', type=Path)
    a = p.parse_args()
    vendor = ROOT / 'vendor/llama.cpp'
    if not (vendor / 'CMakeLists.txt').exists():
        archive = ROOT / 'vendor/llama-v0.6.0.tar.gz'
        download(LLAMA_URL, archive, LLAMA_SHA)
        with tarfile.open(archive) as source:
            for member in source.getmembers():
                parts = Path(member.name).parts
                if not parts or parts[0] != 'llama.cpp-0.6.0' or '..' in parts or member.issym() or member.islnk():
                    raise ValueError('Unsafe archive path')
            source.extractall(ROOT / 'vendor', filter='data')
        (ROOT / 'vendor/llama.cpp-0.6.0').rename(vendor)
        archive.unlink()
    if a.with_model:
        source = SOURCES[a.source]
        path = ROOT / source['path']
        download(source['url'], path, model_specs()[source['spec']]['sha256'])
        print('Verified reference weights:', path, '(not bundled in the APK)')
    if a.model_file:
        verify_bundled(a.model_file)
        target = ROOT / 'app/src/full/assets/model.gguf'
        target.parent.mkdir(parents=True, exist_ok=True)
        if a.model_file.resolve() != target.resolve():
            temporary = target.with_suffix('.gguf.part')
            try:
                shutil.copyfile(a.model_file, temporary)
                verify_bundled(temporary)
                os.replace(temporary, target)
            finally:
                temporary.unlink(missing_ok=True)
        print('Verified bundled beta model staged:', target)
    print('Ready. Android runtime needs no network permission.')

if __name__ == '__main__':
    main()
