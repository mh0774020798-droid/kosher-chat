"""Convert verified DictaLM Instruct original weights with the pinned llama.cpp converter."""
import argparse
import importlib.metadata
import json
from pathlib import Path
import subprocess
import sys
from fetch_candidate import CANDIDATES, digest

ROOT=Path(__file__).resolve().parents[1]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--variant',choices=('instruct','thinking'),default='instruct');a=p.parse_args()
    repo,revision,filename,size,sha=CANDIDATES['dicta-'+a.variant+'-bf16']
    name='DictaLM 3.0 1.7B '+a.variant.capitalize()
    weights=a.source/filename
    if weights.stat().st_size!=size or digest(weights)!=sha:raise ValueError('Original weights differ from upstream pin')
    metadata=json.loads((a.source/'metadata-provenance.json').read_text())
    if metadata['repository']!=repo or metadata['revision']!=revision:raise ValueError('Metadata belongs to another revision')
    for item in metadata['files']:
        path=a.source/item['filename']
        if path.stat().st_size!=item['bytes'] or digest(path)!=item['sha256']:raise ValueError('Model/tokenizer metadata was changed')
    if a.output.exists() or a.output.with_suffix('.recipe.json').exists():raise ValueError('Output must be new')
    tool=ROOT/'vendor/llama.cpp/convert_hf_to_gguf.py'
    temporary=a.output.with_suffix('.gguf.part')
    command=[sys.executable,str(tool),'--outtype','bf16','--model-name',name,'--outfile',str(temporary),str(a.source)]
    print(json.dumps(command),flush=True)
    try:
        subprocess.run(command,check=True)
        sys.path.insert(0,str(ROOT/'vendor/llama.cpp/gguf-py'))
        from gguf import GGUFReader
        r=GGUFReader(temporary)
        expected={'general.architecture':'qwen3','general.name':name,
                  'qwen3.block_count':28,'qwen3.embedding_length':2048}
        for key,value in expected.items():
            if r.fields[key].contents()!=value:raise ValueError('Conversion metadata differs: '+key)
        if 'output.weight' in {x.name for x in r.tensors}:raise ValueError('Expected original tied embeddings')
        template=r.fields['tokenizer.chat_template'].contents()
        if ('<think>' in template)!=(a.variant=='thinking') or '<|im_start|>assistant' not in template:raise ValueError('Unexpected chat template')
        vocabulary=len(r.fields['tokenizer.ggml.tokens'].contents())
        if vocabulary!=151936:raise ValueError('Vocabulary was changed')
        tensor_count=len(r.tensors)
        del r
        temporary.replace(a.output)
    finally:temporary.unlink(missing_ok=True)
    recipe={'status':'verified original conversion; not release quality approval',
            'upstreamRepository':repo,'revision':revision,'variant':a.variant,'sourceSha256':sha,'sourceBytes':size,
            'bytes':a.output.stat().st_size,'sha256':digest(a.output),'vocabularySize':vocabulary,
            'vocabularyPruned':False,'decoderLayersRemoved':0,'tensors':tensor_count,'license':'Apache-2.0',
            'converterSha256':digest(tool),'command':command,'metadata':metadata['files'],
            'packages':{name:importlib.metadata.version(name) for name in ('torch','transformers','numpy','safetensors','sentencepiece')}}
    a.output.with_suffix('.recipe.json').write_text(json.dumps(recipe,indent=2)+'\n')
    print(json.dumps(recipe,indent=2),flush=True)

if __name__=='__main__':main()
