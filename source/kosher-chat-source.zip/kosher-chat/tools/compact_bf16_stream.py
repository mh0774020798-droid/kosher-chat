#!/usr/bin/env python3
"""Stream and verify the entire pinned BF16 checkpoint while writing selected rows.

Every downloaded byte contributes to SHA-256, including discarded vocabulary rows
and inactive K/V tensors. The result remains experimental and is never approved here.
"""
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
from pathlib import Path
import re
import tempfile
import urllib.request
import numpy as np
from compact_vocab import GGUFReader, GGUFWriter, SOURCE_REVISION, copy_metadata, select_vocabulary, digest
from strip_unused_kv import BF16_SHA, unused_kv_names

SOURCE_BYTES=9_311_305_152
PREFIX_BYTES=16*1024*1024
SOURCE_URL=f'https://huggingface.co/ggml-org/gemma-4-E2B-it-GGUF/resolve/{SOURCE_REVISION}/gemma-4-E2B-it-BF16.gguf?download=true'

def fetch_range(url,first,last,size,opener=urllib.request.urlopen):
    error=None
    for attempt in range(3):
        try:
            request=urllib.request.Request(f'{url}&part={first}&last={last}',headers={'Range':f'bytes={first}-{last}'})
            with opener(request,timeout=120) as response:
                if response.status!=206 or response.headers.get('Content-Range')!=f'bytes {first}-{last}/{size}':
                    raise ValueError('Server ignored or changed the requested range')
                data=response.read(last-first+2)
                if len(data)!=last-first+1:
                    raise ValueError('Incomplete or oversized HTTP range')
                return data
        except (OSError,ValueError) as e:
            error=e
    raise error

class RangeResponse:
    """Bounded parallel fetches returned strictly in original checkpoint order."""
    def __init__(self,url,size,range_bytes=64*1024*1024,workers=4,opener=urllib.request.urlopen):
        self.url=url;self.size=size;self.range_bytes=range_bytes;self.opener=opener
        self.pool=ThreadPoolExecutor(max_workers=workers)
        self.pending={};self.scheduled=0;self.next=0;self.buffer=b'';self.offset=0
        for _ in range(workers):self._schedule()
    def _schedule(self):
        first=self.scheduled*self.range_bytes
        if first<self.size:
            last=min(self.size,first+self.range_bytes)-1
            self.pending[self.scheduled]=self.pool.submit(fetch_range,self.url,first,last,self.size,self.opener)
            self.scheduled+=1
    def read(self,n):
        if n<0:raise ValueError('Bounded reads required')
        parts=[]
        while n:
            if self.offset==len(self.buffer):
                if self.next not in self.pending:break
                self.buffer=self.pending.pop(self.next).result()
                self.offset=0;self.next+=1;self._schedule()
            take=min(n,len(self.buffer)-self.offset)
            parts.append(self.buffer[self.offset:self.offset+take]);self.offset+=take;n-=take
        return b''.join(parts)
    def close(self):
        for future in self.pending.values():future.cancel()
        self.pool.shutdown(wait=True,cancel_futures=True)
    def __enter__(self):return self
    def __exit__(self,*exc):self.close()

class VerifiedStream:
    def __init__(self,response,size=SOURCE_BYTES,prefix_size=PREFIX_BYTES):
        self.response=response;self.size=size;self.prefix_size=prefix_size;self.position=0
        self.sha=hashlib.sha256();self.prefix_sha=hashlib.sha256();self.next_progress=512*1024*1024
    def read(self,n):
        if n<0 or self.position+n>self.size:raise ValueError('Read exceeds pinned checkpoint length')
        blocks=[]
        while n:
            count=min(n,8*1024*1024)
            block=self.response.read(count)
            if len(block)!=count:raise ValueError('Short checkpoint stream')
            self.sha.update(block)
            if self.position<self.prefix_size:self.prefix_sha.update(block[:self.prefix_size-self.position])
            self.position+=count;n-=count;blocks.append(block)
            if self.position>=self.next_progress:
                print(f'Verified stream {100*self.position/self.size:.1f}%',flush=True)
                self.next_progress+=512*1024*1024
        return b''.join(blocks)
    def skip_to(self,position):
        if position<self.position:raise ValueError('Checkpoint tensors must be read in order')
        while self.position<position:self.read(min(position-self.position,8*1024*1024))
    def finish(self,expected_sha,prefix_sha=None):
        self.skip_to(self.size)
        if self.response.read(1):raise ValueError('Extra bytes after pinned checkpoint')
        if self.sha.hexdigest()!=expected_sha:raise ValueError('Full original BF16 checksum mismatch')
        if prefix_sha is not None and self.prefix_sha.hexdigest()!=prefix_sha:raise ValueError('Metadata prefix changed')

def run(output,max_tokens,metadata_file):
    if output.exists() or output.with_suffix('.recipe.json').exists():raise ValueError('Output must be new')
    output.parent.mkdir(parents=True,exist_ok=True)
    prefix=fetch_range(SOURCE_URL,0,PREFIX_BYTES-1,SOURCE_BYTES)
    metadata_file.parent.mkdir(parents=True,exist_ok=True)
    with metadata_file.open('wb') as f:
        f.write(prefix);f.truncate(SOURCE_BYTES)
    r=GGUFReader(metadata_file)
    removed=unused_kv_names(r)
    if r.data_offset>PREFIX_BYTES:raise ValueError('Metadata exceeds prefix')
    selected,merges,recipe=select_vocabulary(r,max_tokens)
    print(f"Selected {len(selected)} tokens; preserved {recipe['hebrewTokensPreserved']} Hebrew and {recipe['byteFallbackTokensPreserved']} byte tokens; removed {len(removed)} inactive K/V tensors",flush=True)
    tensors=[t for t in r.tensors if t.name not in removed]
    modified=set(recipe['modifiedEmbeddingTensors'])
    temporary=output.with_suffix('.gguf.part')
    w=GGUFWriter(temporary,'gemma4',endianess=r.endianess)
    try:
        copy_metadata(r,w,selected,merges)
        for t in tensors:
            shape=list(t.data.shape)
            nbytes=t.n_bytes
            if t.name in modified:
                row_bytes=t.n_bytes//shape[0]
                shape[0]=len(selected);nbytes=row_bytes*len(selected)
            w.add_tensor_info(t.name,shape,t.data.dtype,nbytes,raw_dtype=t.tensor_type)
        w.write_header_to_file();w.write_kv_data_to_file();w.write_ti_data_to_file()
        with RangeResponse(SOURCE_URL,SOURCE_BYTES) as response:
            stream=VerifiedStream(response)
            for t in tensors:
                stream.skip_to(t.data_offset)
                if t.name in modified:
                    rows=t.data.shape[0];row_bytes=t.n_bytes//rows
                    retained=bytearray(len(selected)*row_bytes);target_row=0
                    for first in range(0,rows,1024):
                        count=min(1024,rows-first)
                        block=stream.read(count*row_bytes)
                        while target_row<len(selected) and selected[target_row]<first+count:
                            original=selected[target_row]-first
                            retained[target_row*row_bytes:(target_row+1)*row_bytes]=block[original*row_bytes:(original+1)*row_bytes]
                            target_row+=1
                    if target_row!=len(selected):raise ValueError('Missing selected embedding rows')
                    data=np.frombuffer(retained,dtype=np.uint8)
                else:
                    data=np.frombuffer(stream.read(t.n_bytes),dtype=np.uint8)
                w.write_tensor_data(data)
                del data
            stream.finish(BF16_SHA,hashlib.sha256(prefix).hexdigest())
        w.close();temporary.replace(output)
    finally:
        w.close();temporary.unlink(missing_ok=True)
    recipe.update(sourceRevision=SOURCE_REVISION,sourceSha256=BF16_SHA,sourceBytes=SOURCE_BYTES,
        removedInactiveKvTensors=sorted(removed),bytes=output.stat().st_size,sha256=digest(output))
    output.with_suffix('.recipe.json').write_text(json.dumps(recipe,indent=2)+'\n')
    print(json.dumps({k:v for k,v in recipe.items() if k!='retainedOriginalTokenIds'},indent=2),flush=True)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('output',type=Path)
    p.add_argument('--max-tokens',type=int,default=6800);p.add_argument('--metadata-file',type=Path)
    a=p.parse_args()
    if a.metadata_file:run(a.output,a.max_tokens,a.metadata_file)
    else:
        with tempfile.TemporaryDirectory(prefix='gemma4-metadata-') as d:
            run(a.output,a.max_tokens,Path(d)/'metadata.gguf')

if __name__=='__main__':main()
