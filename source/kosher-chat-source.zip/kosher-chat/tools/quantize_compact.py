"""Quantize an exact calibrated derivative; never register or approve a model."""
import argparse
import json
from pathlib import Path
import subprocess
from compact_vocab import SOURCE_SHA, digest
from strip_unused_kv import BF16_SHA
from calibrate_compact import validate_imatrix

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--tool',required=True,type=Path);p.add_argument('--imatrix',required=True,type=Path)
    p.add_argument('--attention-type',choices=('IQ3_XXS','Q4_0','Q5_K','Q6_K'),default='Q4_0')
    p.add_argument('--dry-run',action='store_true');a=p.parse_args()
    recipe=json.loads(a.source.with_suffix('.recipe.json').read_text())
    if recipe['sourceSha256'] not in (SOURCE_SHA,BF16_SHA) or recipe['decoderLayersRemoved']!=0 or digest(a.source)!=recipe['sha256']:
        raise ValueError('Source does not match pinned derivative recipe')
    binding=json.loads(a.imatrix.with_suffix('.calibration.json').read_text())
    if binding['sourceModelSha256']!=recipe['sha256'] or binding['imatrixSha256']!=digest(a.imatrix):
        raise ValueError('Importance matrix belongs to different weights')
    validate_imatrix(a.imatrix)
    if a.output.exists() or a.output.with_suffix('.recipe.json').exists():raise ValueError('Output must be new')
    temporary=a.output.with_suffix('.gguf.part')
    command=[str(a.tool.resolve()),'--allow-requantize','--imatrix',str(a.imatrix),'--pure',
        '--token-embedding-type','q8_0','--output-tensor-type','q8_0',
        '--tensor-type',r'per_layer_token_embd\.weight=q4_0',
        '--tensor-type',r'blk\.[0-9]+\.(inp_gate|proj)\.weight=q4_0',
        '--tensor-type',r'blk\.[0-9]+\.attn_(k|v)\.weight='+a.attention_type.lower(),
        str(a.source),str(temporary),'IQ3_XXS','4']
    if a.dry_run:
        print(json.dumps(command,indent=2));return
    try:
        subprocess.run(command,check=True)
        temporary.replace(a.output)
    finally:temporary.unlink(missing_ok=True)
    recipe.update(status='experimental calibrated derivative; release quality review required',
        compactSourceSha256=recipe['sha256'],imatrixSha256=binding['imatrixSha256'],datasetSha256=binding['datasetSha256'],
        quantization='IQ3_XXS; embeddings Q8_0/per-layer Q4_0; active K/V '+a.attention_type,
        bytes=a.output.stat().st_size,sha256=digest(a.output),command=command)
    a.output.with_suffix('.recipe.json').write_text(json.dumps(recipe,indent=2)+'\n')
    print(json.dumps({k:v for k,v in recipe.items() if k!='retainedOriginalTokenIds'},indent=2))

if __name__=='__main__':main()
