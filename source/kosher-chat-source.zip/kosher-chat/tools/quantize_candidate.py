"""Quantize an intact, pinned upstream model without trimming tokens or layers."""
import argparse
import json
from pathlib import Path
import subprocess
from fetch_candidate import CANDIDATES, digest
from calibrate_compact import validate_imatrix

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--candidate',choices=('qwen3-1.7-f16','dicta-instruct','dicta-thinking'),required=True)
    p.add_argument('--profile',choices=('balanced','lexicon'),default='balanced',
        help='Dicta: protect attention K/V plus either the body or the tied vocabulary table')
    p.add_argument('--tool',required=True,type=Path)
    p.add_argument('--imatrix',type=Path)
    p.add_argument('--dry-run',action='store_true')
    a=p.parse_args()
    dicta=a.candidate.startswith('dicta-')
    key=a.candidate+'-bf16' if dicta else a.candidate
    repo,revision,filename,size,upstream_sha=CANDIDATES[key]
    source_recipe=None
    sha=digest(a.source)
    if dicta:
        source_recipe=json.loads(a.source.with_suffix('.recipe.json').read_text())
        expected={'upstreamRepository':repo,'revision':revision,'sourceSha256':upstream_sha,
                  'sourceBytes':size,'sha256':sha,'bytes':a.source.stat().st_size,
                  'vocabularySize':151936,'vocabularyPruned':False,'decoderLayersRemoved':0}
        if any(source_recipe.get(k)!=v for k,v in expected.items()):
            raise ValueError('Converted source differs from the verified original recipe')
        body,embedding=('IQ3_S','iq4_xs') if a.profile=='balanced' else ('IQ3_XXS','q5_k')
    else:
        if a.source.stat().st_size!=size or sha!=upstream_sha:raise ValueError('Source differs from upstream pin')
        body,embedding='IQ3_XXS','iq3_xxs'
    if a.output.exists() or a.output.with_suffix('.recipe.json').exists():raise ValueError('Output must be new')
    temporary=a.output.with_suffix('.gguf.part')
    command=[str(a.tool.resolve()),'--pure','--token-embedding-type',embedding,
             '--output-tensor-type',embedding,'--max-buffer-size','256']
    if dicta:
        command+=['--tensor-type',r'blk\.[0-9]+\.attn_(k|v)\.weight=q4_0']
        if a.profile=='lexicon':
            command+=['--tensor-type',r'blk\.[0-9]+\.attn_(q|output)\.weight=iq3_s']
    binding=None
    if a.imatrix:
        binding=json.loads(a.imatrix.with_suffix('.calibration.json').read_text())
        if binding['sourceModelSha256']!=sha or binding['imatrixSha256']!=digest(a.imatrix):raise ValueError('Calibration does not match source')
        validate_imatrix(a.imatrix)
        command+=['--imatrix',str(a.imatrix)]
    elif not a.dry_run:raise ValueError('Real quantization requires bound calibration')
    if a.dry_run:command+=['--dry-run']
    command += [str(a.source),str(temporary),body,'4']
    print(json.dumps(command),flush=True)
    try:
        subprocess.run(command,check=True)
        if a.dry_run:return
        if temporary.stat().st_size>795_500_000:raise ValueError('Candidate exceeds bundled model budget')
        temporary.replace(a.output)
    finally:temporary.unlink(missing_ok=True)
    recipe={'status':'experimental; manual quality review required; not release approval',
        'upstreamRepository':repo,'revision':revision,'sourceSha256':upstream_sha,
        'convertedSourceSha256':sha,'sourceBytes':size,
        'license':'Apache-2.0','quantization':body+'; tied vocabulary '+embedding+
            ('; active K/V Q4_0' if dicta else '')+
            ('; attention Q/output IQ3_S' if dicta and a.profile=='lexicon' else ''),
        'vocabularyPruned':False,'decoderLayersRemoved':0,
        'bytes':a.output.stat().st_size,'sha256':digest(a.output),'command':command,
        'imatrixSha256':binding['imatrixSha256'],'datasetSha256':binding['datasetSha256'],
        'quantizerSha256':digest(a.tool),'profile':a.profile}
    if source_recipe is not None:
        recipe['vocabularySize']=source_recipe['vocabularySize']
        recipe['conversion']=source_recipe
    a.output.with_suffix('.recipe.json').write_text(json.dumps(recipe,indent=2)+'\n')
    print(json.dumps(recipe,indent=2))

if __name__=='__main__':main()
