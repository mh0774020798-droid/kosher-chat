"""Build-time model approval pins shared with Android's ModelSpec."""
import argparse
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
MAX_APK_BYTES = 800_000_000
MAX_BUNDLED_MODEL = 795_500_000
BUNDLED_MODEL = 'DICTA_HE_EN_BETA'
SOURCES = {
    'gemma4-source': {'spec': 'GEMMA4_FULL', 'path': 'models/gemma-4-E2B-it-Q4_0.gguf',
        'url': 'https://huggingface.co/ggml-org/gemma-4-E2B-it-GGUF/resolve/b4243c156154b6dca9324415f8c7ccc098b4aed1/gemma-4-E2B-it-Q4_0.gguf?download=true'},
    'gemma3-legacy': {'spec': 'GEMMA3', 'path': 'models/google_gemma-3-1b-it-IQ4_XS.gguf',
        'url': 'https://huggingface.co/bartowski/google_gemma-3-1b-it-GGUF/resolve/116f76234503685a98f572982177b11d44ec8ff1/google_gemma-3-1b-it-IQ4_XS.gguf?download=true'},
}

def model_specs():
    text = (ROOT / 'app/src/main/java/com/moked/kosherchat/ModelSpec.java').read_text()
    pattern = r'static\s+final\s+ModelSpec\s+(\w+)\s*=\s*new\s+ModelSpec\(\s*(\d+)\s*,\s*(\d+)L\s*,\s*"([a-f0-9]{64})"\s*,\s*"([^"\n]+)"\s*\)'
    return {name: {'name': name, 'family': int(family), 'bytes': int(size), 'sha256': sha, 'label': label}
            for name, family, size, sha, label in re.findall(pattern, text)}

def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

def identify(size, sha256, expected_family=None, specs=None):
    for spec in (model_specs() if specs is None else specs).values():
        if spec['bytes'] == size and spec['sha256'] == sha256:
            if expected_family is not None and spec['family'] != expected_family:
                raise ValueError('Model family differs from this release')
            return spec
    raise ValueError('Model is not approved in ModelSpec')

def verify_file(path, expected_family=4, max_bytes=MAX_BUNDLED_MODEL, specs=None):
    path = Path(path)
    if not path.is_file():
        raise ValueError('No model asset: a full release needs the pinned bundled model')
    size = path.stat().st_size
    if max_bytes is not None and size > max_bytes:
        raise ValueError('Model exceeds the full APK model budget')
    return identify(size, digest(path), expected_family, specs)

def verify_bundled(path, specs=None):
    specs = model_specs() if specs is None else specs
    approved = specs.get(BUNDLED_MODEL)
    if approved is None:
        raise ValueError('Bundled model is not registered')
    result = verify_file(path, expected_family=approved['family'], specs=specs)
    if result != approved:
        raise ValueError('Model differs from the exact bundled release pin')
    return result

def owner_certificate():
    text = (ROOT / 'app/src/main/java/com/moked/kosherchat/AppIntegrity.java').read_text()
    return re.search(r'OWNER_CERT\s*=\s*"([a-f0-9]{64})"', text)[1]

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--check-bundled', action='store_true')
    a = p.parse_args()
    print(json.dumps(verify_bundled(ROOT / 'app/src/full/assets/model.gguf') if a.check_bundled else model_specs(), indent=2))

if __name__ == '__main__':
    main()
