"""Preserve Hebrew byte-BPE tokens and every decoder layer in pinned DictaLM.

The derivative requires real inference review before release registration.
"""
import argparse
import json
from pathlib import Path
import sys
import numpy as np
from wordfreq import zipf_frequency
from fetch_candidate import CANDIDATES, digest
from compact_vocab import PROTECTED_WORDS

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'vendor/llama.cpp/gguf-py'))
from gguf import GGUFReader, GGUFWriter, GGUFValueType

def byte_decoder():
    printable = list(range(33, 127)) + list(range(161, 173)) + list(range(174, 256))
    encoded = printable.copy()
    extra = 256
    for b in range(256):
        if b not in printable:
            printable.append(b); encoded.append(extra); extra += 1
    return {chr(c): b for b, c in zip(printable, encoded)}

def select(tokens, types, merges, special, maximum):
    decoder = byte_decoder()
    ids = {t: i for i, t in enumerate(tokens)}
    parents = {}
    for merge in merges:
        left, right = merge.split(' ', 1)
        if left in ids and right in ids and left + right in ids:
            parents.setdefault(ids[left + right], (ids[left], ids[right]))
    def closure(start):
        found = set(start); pending = list(start)
        while pending:
            for parent in parents.get(pending.pop(), ()):
                if parent not in found:
                    found.add(parent); pending.append(parent)
        return found
    raw = [bytes(decoder[c] for c in t) if all(c in decoder for c in t) else b'' for t in tokens]
    # Preserve complete and partial Hebrew UTF-8 sequences, including marks.
    hebrew = {i for i, b in enumerate(raw) if 0xd6 in b or 0xd7 in b}
    mandatory = hebrew | set(special) | {i for i, t in enumerate(types) if t in (3, 4, 6)}
    mandatory |= {i for i, b in enumerate(raw) if len(b) == 1}
    mandatory |= {i for i, b in enumerate(raw) if b and b.isascii()
        and b.decode('ascii').strip().lower() in PROTECTED_WORDS}
    kept = closure(mandatory)
    if len(kept) > maximum:
        raise ValueError(f'Protected vocabulary needs {len(kept)} tokens')
    lexemes = {}; frequencies = {}; english = []
    for i, b in enumerate(raw):
        if not b or any(c >= 128 for c in b) or types[i] in (3, 4, 5, 6):
            continue
        word = b.decode('ascii').strip().lower()
        frequencies[i] = zipf_frequency(word, 'en') if word.isalpha() else 0
        english.append(i)
        if frequencies[i] >= 2.5:
            lexemes.setdefault(word, []).append(i)
    primary = [min(v, key=lambda i: (not raw[i].startswith(b' '), i)) for v in lexemes.values()]
    primary_set = set(primary)
    for group in (primary, [i for i in english if i not in primary_set]):
        for i in sorted(group, key=lambda i: (-frequencies[i], i)):
            additions = closure([i]) - kept
            if len(kept) + len(additions) <= maximum:
                kept.update(additions)
    selected = sorted(kept)
    filtered = [m for m in merges if all(ids.get(t) in kept for t in (*m.split(' ', 1), m.replace(' ', '', 1)))]
    return selected, filtered, {'protectedHebrewByteTokens': len(hebrew),
        'protectedVocabularyWithMergeClosure': len(closure(mandatory)),
        'selection': 'all Hebrew UTF-8 byte tokens, specials and bytes; English wordfreq 3.1.1 with merge closure'}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('source', type=Path); p.add_argument('output', type=Path)
    p.add_argument('--max-tokens', type=int, default=32000)
    a = p.parse_args()
    if a.output.exists() or a.output.with_suffix('.recipe.json').exists():
        raise ValueError('Output must be new')
    source = json.loads(a.source.with_suffix('.recipe.json').read_text())
    repo, revision, _, size, sha = CANDIDATES['dicta-instruct-bf16']
    expected = {'upstreamRepository': repo, 'revision': revision, 'sourceBytes': size,
        'sourceSha256': sha, 'vocabularySize': 151936, 'vocabularyPruned': False,
        'decoderLayersRemoved': 0, 'bytes': a.source.stat().st_size, 'sha256': digest(a.source)}
    if any(source.get(k) != v for k, v in expected.items()):
        raise ValueError('Converted source does not match original pin')
    r = GGUFReader(a.source)
    tokens = r.fields['tokenizer.ggml.tokens'].contents()
    types = r.fields['tokenizer.ggml.token_type'].contents()
    merges = r.fields['tokenizer.ggml.merges'].contents()
    special = [f.contents() for name, f in r.fields.items()
        if name.startswith('tokenizer.ggml.') and name.endswith('_token_id')]
    selected, filtered, selection = select(tokens, types, merges, special, a.max_tokens)
    remap = {old: new for new, old in enumerate(selected)}
    temporary = a.output.with_suffix('.gguf.part')
    w = GGUFWriter(temporary, 'qwen3', endianess=r.endianess)
    try:
        for name, f in r.fields.items():
            if name.startswith('GGUF.'):
                continue
            value = f.contents()
            if name in ('tokenizer.ggml.tokens', 'tokenizer.ggml.token_type', 'tokenizer.ggml.scores'):
                value = [value[i] for i in selected]
            elif name == 'tokenizer.ggml.merges':
                value = filtered
            elif name.startswith('tokenizer.ggml.') and name.endswith('_token_id'):
                value = remap[value]
            elif name == 'qwen3.vocab_size':
                value = len(selected)
            w.add_key_value(name, value, f.types[0], f.types[-1] if f.types[0] == GGUFValueType.ARRAY else None)
        for t in r.tensors:
            data = np.ascontiguousarray(t.data[selected]) if t.name == 'token_embd.weight' else t.data
            w.add_tensor(t.name, data, raw_dtype=t.tensor_type)
        w.write_header_to_file(); w.write_kv_data_to_file(); w.write_tensors_to_file(progress=False); w.close()
        temporary.replace(a.output)
    finally:
        w.close(); temporary.unlink(missing_ok=True)
    recipe = {'status': 'experimental; real inference review required',
        'conversion': source, 'convertedSourceSha256': source['sha256'],
        'vocabularySize': len(selected), 'originalVocabularySize': len(tokens),
        'vocabularyPruned': True, 'decoderLayersRemoved': 0,
        'retainedOriginalTokenIds': selected, **selection,
        'bytes': a.output.stat().st_size, 'sha256': digest(a.output),
        'toolSha256': digest(Path(__file__))}
    a.output.with_suffix('.recipe.json').write_text(json.dumps(recipe, indent=2) + '\n')
    print(json.dumps({k: v for k, v in recipe.items() if k not in ('retainedOriginalTokenIds', 'conversion')}, indent=2))

if __name__ == '__main__':
    main()
