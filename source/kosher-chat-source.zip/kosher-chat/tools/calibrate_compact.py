"""Compute a real llama.cpp importance matrix bound to the exact derivative."""
import argparse
import json
from pathlib import Path
import subprocess
import numpy as np
from compact_vocab import GGUFReader, digest

def validate_imatrix(path):
    reader=GGUFReader(path)
    def integer(key):
        value=reader.fields[key].contents()
        if value<=0:raise ValueError('Empty importance matrix calibration')
        return int(value)
    chunks=integer('imatrix.chunk_count');size=integer('imatrix.chunk_size')
    tensors={t.name:t for t in reader.tensors}
    entries=[t for t in reader.tensors if t.name.endswith('.in_sum2')]
    if not entries:raise ValueError('No importance tensors')
    for t in entries:
        values=t.data
        count=tensors.get(t.name[:-len('.in_sum2')]+'.counts')
        if not np.all(np.isfinite(values)) or np.any(values<0) or not np.any(values>0):
            raise ValueError('Invalid importance values')
        if count is None or not np.all(np.isfinite(count.data)) or not np.all(count.data>0):
            raise ValueError('Invalid importance counts')
    return {'chunks':chunks,'chunkSize':size,'importanceTensors':len(entries)}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--tool',required=True,type=Path)
    p.add_argument('--dataset',type=Path,default=Path(__file__).with_name('calibration-he-en.txt'))
    a=p.parse_args()
    metadata=a.source.with_suffix('.recipe.json')
    if not metadata.is_file():metadata=a.source.with_suffix('.provenance.json')
    recipe=json.loads(metadata.read_text())
    if digest(a.source)!=recipe['sha256'] or recipe['decoderLayersRemoved']!=0:raise ValueError('Derivative recipe does not match')
    if a.output.exists() or a.output.with_suffix('.calibration.json').exists():raise ValueError('Output must be new')
    temporary=a.output.with_suffix('.gguf.part')
    command=[str(a.tool.resolve()),'-m',str(a.source),'-f',str(a.dataset),'-o',str(temporary),'--output-format','gguf','--no-ppl','-c','256','-b','128','-ub','32','-t','4']
    try:
        subprocess.run(command,check=True)
        validation=validate_imatrix(temporary)
        temporary.replace(a.output)
    finally:temporary.unlink(missing_ok=True)
    validation.update(sourceModelSha256=recipe['sha256'],datasetSha256=digest(a.dataset),toolSha256=digest(a.tool),imatrixSha256=digest(a.output),command=command)
    a.output.with_suffix('.calibration.json').write_text(json.dumps(validation,indent=2)+'\n')
    print(json.dumps(validation,indent=2))

if __name__=='__main__':main()
