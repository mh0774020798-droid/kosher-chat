"""Fetch a pinned original DictaLM checkpoint and verify Git/LFS hashes."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import urllib.request
from fetch_candidate import CANDIDATES, fetch

def verify_metadata(item, content):
    """Verify fresh or resumed bytes against the pinned Git/LFS entry."""
    name=item['rfilename']
    sha256=hashlib.sha256(content).hexdigest()
    if 'lfs' in item:
        if sha256!=item['lfs']['sha256'] or len(content)!=item['lfs']['size']:
            raise ValueError('Metadata LFS hash mismatch: '+name)
    elif hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()!=item['blobId']:
        raise ValueError('Metadata Git blob mismatch: '+name)
    return {'filename':name,'gitBlobSha1':item['blobId'],'sha256':sha256,'bytes':len(content),
            'verification':'LFS SHA-256' if 'lfs' in item else 'Git blob SHA-1'}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('directory',type=Path)
    p.add_argument('--variant',choices=('instruct','thinking'),default='instruct')
    p.add_argument('--metadata-only',action='store_true')
    p.add_argument('--upstream-metadata',type=Path,help='Reuse the complete API response already resolved for this exact revision')
    a=p.parse_args()
    candidate='dicta-'+a.variant+'-bf16'
    repo,revision,filename,size,sha=CANDIDATES[candidate]
    a.directory.mkdir(parents=True,exist_ok=True)
    if a.upstream_metadata:data=json.loads(a.upstream_metadata.read_text())
    else:
        with urllib.request.urlopen(f'https://huggingface.co/api/models/{repo}/revision/{revision}?blobs=true',timeout=45) as response:data=json.load(response)
    if data['sha']!=revision or data['id']!=repo:raise ValueError('Repository revision mismatch')
    allowed={'config.json','tokenizer.json','tokenizer_config.json','chat_template.jinja','generation_config.json','vocab.json','merges.txt','special_tokens_map.json','added_tokens.json','README.md'}
    files=[x for x in data['siblings'] if x['rfilename'] in allowed]
    if not {'config.json','tokenizer_config.json','tokenizer.json'}.issubset({x['rfilename'] for x in files}):raise ValueError('Missing model/tokenizer metadata')
    def download(item):
        name=item['rfilename']
        path=a.directory/name
        if path.is_file():
            return verify_metadata(item,path.read_bytes())
        with urllib.request.urlopen(f'https://huggingface.co/{repo}/resolve/{revision}/{name}?download=true',timeout=45) as response:content=response.read()
        verified=verify_metadata(item,content)
        temporary=path.with_suffix(path.suffix+'.download.part')
        try:
            temporary.write_bytes(content)
            temporary.replace(path)
        finally:temporary.unlink(missing_ok=True)
        return verified
    metadata=[download(item) for item in files]
    (a.directory/'metadata-provenance.json').write_text(json.dumps({'repository':repo,'revision':revision,'files':metadata},indent=2)+'\n')
    print('Verified original metadata:',[x['filename'] for x in metadata],flush=True)
    if not a.metadata_only:print('Verified original weights:',fetch(candidate,a.directory,single_stream=True),flush=True)

if __name__=='__main__':main()
