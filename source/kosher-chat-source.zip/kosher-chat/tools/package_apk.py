"""Align and sign an Android APK. Private signing material stays outside source control."""
import argparse, os, pathlib, subprocess, tempfile, zipfile, struct

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--input',required=True)
    p.add_argument('--out',required=True)
    p.add_argument('--sdk',default=os.environ.get('ANDROID_SDK_ROOT',''))
    p.add_argument('--keystore',required=True)
    p.add_argument('--password-file',required=True)
    a=p.parse_args()
    tools=pathlib.Path(a.sdk)/'build-tools/35.0.0'
    if not (tools/'zipalign').is_file():raise SystemExit('Specify --sdk with Android build-tools 35.0.0 installed')
    target=pathlib.Path(a.out).resolve();target.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=target.parent) as temporary:
        aligned=pathlib.Path(temporary)/'aligned.apk'
        subprocess.run([str(tools/'zipalign'),'-P','16','-f','32',a.input,str(aligned)],check=True)
        subprocess.run([str(tools/'apksigner'),'sign','--ks',a.keystore,'--ks-key-alias','kosher-chat',
                        '--ks-pass','file:'+a.password_file,
                        '--v4-signing-enabled','false',
                        '--alignment-preserved','true',
                        '--out',str(target),str(aligned)],check=True)
    subprocess.run([str(tools/'zipalign'),'-P','16','-c','4',str(target)],check=True)
    with zipfile.ZipFile(target) as archive,target.open('rb') as file:
        if 'assets/model.gguf' in archive.namelist():
            info=archive.getinfo('assets/model.gguf');file.seek(info.header_offset)
            name,extra=struct.unpack_from('<HH',file.read(30),26)
            if info.compress_type!=zipfile.ZIP_STORED or (info.header_offset+30+name+extra)%32:
                raise RuntimeError('Embedded model is not aligned for mmap')
    subprocess.run([str(tools/'apksigner'),'verify','--verbose',str(target)],check=True)
    print('Ready:',target,'bytes:',target.stat().st_size)
if __name__=='__main__':main()
