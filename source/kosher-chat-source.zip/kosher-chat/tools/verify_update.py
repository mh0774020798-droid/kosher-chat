import argparse, hashlib, json, pathlib, zipfile
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import padding

def verify(public_key,archive,current_version=0):
    allowed={'manifest.json','manifest.sig','model.gguf','knowledge.json','additional-filter.json'}
    with zipfile.ZipFile(archive) as z:
        names=z.namelist()
        if len(names)!=len(set(names)) or not set(names)<=allowed:raise ValueError('Unexpected or duplicate entry')
        manifest=z.read('manifest.json');signature=z.read('manifest.sig')
        key=serialization.load_pem_public_key(pathlib.Path(public_key).read_bytes());key.verify(signature,manifest,padding.PKCS1v15(),hashes.SHA256())
        data=json.loads(manifest)
        if data['format']!='kchat-update-v1' or data['version']<=current_version:raise ValueError('Invalid or old update')
        if set(names)!={'manifest.json','manifest.sig'}|set(data['files']):raise ValueError('Undeclared files')
        for name,info in data['files'].items():
            h=hashlib.sha256();size=0
            with z.open(name) as f:
                for chunk in iter(lambda:f.read(65536),b''):h.update(chunk);size+=len(chunk)
            if size!=info['size'] or h.hexdigest()!=info['sha256']:raise ValueError('Content checksum mismatch')
        return data

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--public-key',required=True);p.add_argument('--file',required=True);a=p.parse_args();print(json.dumps(verify(a.public_key,a.file),ensure_ascii=False,indent=2))
