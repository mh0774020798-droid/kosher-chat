"""Create a source-only checkpoint; exclude models, binaries and private signing files."""
import argparse
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[1]
DIRECTORIES={'app','tools','tests','third-party','examples','docs','gradle','vendor'}
ROOT_FILES={'README.md','DEVELOPMENT.md','LICENSE','build.gradle','settings.gradle','gradle.properties','gradlew','gradlew.bat','.gitignore'}
EXCLUDED={'build','build-host','build-core','.gradle','.cxx','.git','__pycache__','node_modules'}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('output',type=Path);a=p.parse_args()
    a.output.parent.mkdir(parents=True,exist_ok=True)
    files=[]
    for source in sorted(ROOT.rglob('*')):
        if not source.is_file() or source.is_symlink():continue
        rel=source.relative_to(ROOT)
        if rel.parts[0] not in DIRECTORIES and str(rel) not in ROOT_FILES:continue
        if any(part in EXCLUDED for part in rel.parts):continue
        if source.suffix.lower() in ('.gguf','.apk','.jks','.keystore','.so','.a','.o','.class','.pyc'):continue
        if source.name in ('signing.properties','local.properties','keystore-password.txt') or 'private' in source.name.lower():continue
        if source.suffix=='.pem' and source.name!='update-public.pem':continue
        files.append(source)
    with zipfile.ZipFile(a.output,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for source in files:z.write(source,Path('kosher-chat')/source.relative_to(ROOT))
    print('Source checkpoint:',a.output,'bytes:',a.output.stat().st_size,'files:',len(files))

if __name__=='__main__':main()
