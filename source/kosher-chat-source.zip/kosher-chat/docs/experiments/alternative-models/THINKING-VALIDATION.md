# DictaLM Thinking continuation — 2026-10-09

The original Thinking checkpoint was downloaded, completely hashed and converted. This candidate was rejected after reviewing its original BF16 output, before real quantization. No new model was registered in ModelSpec and no new APK was built.

## Source identity

| Field | Verified value |
| --- | --- |
| Repository | dicta-il/DictaLM-3.0-1.7B-Thinking |
| Revision | 43e2fac285633ab440577ce5bcd7223e277cb3a2 |
| Original safetensors bytes | 3,441,185,576 |
| Original SHA-256 | cec0cdb331e6c4148b17593527f0a5be3b2562a54aa3afc145aabd580c943fea |
| Converted BF16 GGUF bytes | 3,447,349,216 |
| Converted SHA-256 | 5bb2d46ad81c65a814de6e9ce0de93457051afe877f8ec8c3eafd424a1a84bcf |
| Preserved structure | all 28 decoder layers; all 151,936 tokens; tied embeddings; 310 tensors |

All ten original configuration/tokenizer files matched the pinned Git/LFS metadata. Conversion used the bundled llama.cpp converter; exact packages and metadata hashes are in dicta-thinking-bf16.recipe.json.

## Implementation and checks

- Family 32 uses the original ChatML generation prefix ending in `<think>`.
- Economical mode reserves 256 internal tokens plus 64 answer tokens in a 1,024-token context. Normal mode reserves 512 plus 128 in a 2,048-token context.
- Internal bytes are discarded as they arrive. Only text following the complete closing delimiter is returned. Unfinished reasoning, empty final answers and repeated delimiters fail without displaying internal text. Input and final-answer filtering remain active.
- The initial 192/256 internal-token budget stopped during a drafting request. Shorter instructions and the revised bounded budget were then tested. This changed the experimental prompt, not the tokenizer or model weights.
- Metadata downloads reuse only bytes verified against their pinned hashes. Interrupted weight downloads keep a partial file, require an exact HTTP resume range and verify the entire completed file against its original SHA-256 before reuse.
- The large download initially stopped due to insufficient space. Its 2,969,567,232-byte prefix was resumed; the final full checksum matched. Large scratch experiments were moved outside the synchronized source tree to prevent accumulating staging copies.

| Check | Result |
| --- | --- |
| Core Java | 130 checks passed |
| C++ output separation | 86 checks passed under AddressSanitizer and UndefinedBehaviorSanitizer |
| Python | 30 tests passed |
| Host native compilation | JNI engine, llama-imatrix and llama-quantize compiled |
| JNI API without a model | signatures, bounded arguments and failed-load cleanup passed |
| Actual BF16 model JNI | load, UTF-8, prefix cache reuse, cancellation, cleared-cache recovery passed |
| Manual final-output review | 20 normal + 6 economical responses generated; quality rejected |
| Real Thinking quantization | not performed; only a dry-run size calculation |
| Android APK / physical phone | no new APK built; no phone tested |

LeakSanitizer was disabled because the container cannot inspect process tasks. Native inference ran on the host with two threads. Those times do not establish phone performance. The existing published 1.2.0 Lite APK predates these changes.

## Review findings

The normal review returned English to a Hebrew drafting request, described the mouse as a keyboard, repeated the same name three times instead of giving distinct names, and changed a disconnected cable into a tied cable. Printer troubleshooting contained unhelpful checks. The economical review changed the person who completed a backup, made the scanner transfer a file the user had moved, changed the description of files in the conversation, and cut an answer off mid-sentence.

Some questions were answered correctly. Every reviewed final response passed the text guard. These facts do not erase the meaning and instruction errors: text filtering and keyword smoke checks are not factual-quality approval.

The raw responses, initial screening, conversion record, pinned metadata, dry-run and final prompt/generation recipe are beside this report. Private generation text was not logged. Source originals and converted weights remain scratch intermediates, excluded from the source archive.

## Next requirement

A stronger model or an actual trained adaptation must pass review while satisfying the existing 800,000,000-byte signed APK budget. Simply changing a hash, adding canned benchmark replies or relaxing the review does not complete the AI upgrade. A successful compact model must still be registered explicitly, assembled and signed with the owner's certificate, checked as a finished APK and tested on Android before claiming device performance.
