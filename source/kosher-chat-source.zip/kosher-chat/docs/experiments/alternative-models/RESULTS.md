# Alternative models — 2026-10-09

All samples use the actual JNI engine. A guard accepting text does not establish factual correctness. None of the candidates below has release approval or is registered in ModelSpec.

| Candidate | Bytes | Result |
| --- | ---: | --- |
| Qwen3.5 0.8B Q4_0 | 563036064 | 11/15 smoke checks; failed Hebrew meaning and instructions in review |
| Gemma3 1B Q4_K_S | 780993280 | 12/15 smoke checks; incorrect meanings and details in review |
| Qwen3 1.7B original F16 | 4069679200 | Failed Hebrew screening before quantization |
| Qwen3.5 2B UD-IQ3_XXS | 931823872 | Failed Hebrew screening; embedding-only re-quantization still exceeds budget |
| DictaLM 1.7B Instruct: IQ3_S / embedding IQ4_XS / K,V Q4_0 | 792903328 | 15/15 smoke checks, but rejected after repetitions, reversed facts and altered tense in review |
| DictaLM 1.7B Instruct: IQ3_XXS / embedding Q5_K / Q,O IQ3_S / K,V Q4_0 | 791977632 | 14/15 smoke checks; rejected after incorrect drafting, altered facts and conversation-history errors |

Dicta originals: all 28 decoder layers and all 151936 vocabulary entries preserved. Original safetensors and every tokenizer/configuration file were verified against the pinned upstream revision. Conversion and quantization recipes, bound calibration hashes and review outputs are adjacent. Calibration: 5 real chunks of 256 tokens, 196 importance tensors; no benchmark answers were added to the app or corpus.

The first Dicta run used the existing .35/.8 sampler and repetition penalty 1.05, with a general format reminder. The second used Dicta's published .6/.95/top-k20 profile, no repetition penalty, and an experimental short-response suffix. Raw BF16 screening and a separate BF16 review demonstrate that some errors also occur before quantization. Those runs used different prompt revisions; they are diagnostic evidence, not a controlled model leaderboard.

Native load, UTF-8, cache reuse, cancellation and recovery passed for the second Dicta candidate. Core: 113 checks; Python: 19 checks. No Android phone was tested in this retry. The existing 1.2.0 Lite binary predates these new source changes.

Next: investigate DictaLM 1.7B Thinking (upstream revision 43e2fac285633ab440577ce5bcd7223e277cb3a2), with bounded internal generation and only the final answer returned. At this checkpoint, its original weights are not yet downloaded or approved. Full Release remains blocked.

## Thinking continuation result

The complete pinned original was verified and converted without pruning. Family 32, the original thinking prefix, bounded private generation and context reservations were implemented. Initial 192/256 reasoning limits stopped during drafting; compact instructions with 256/512 limits completed all 26 normal/economical review samples. Manual inspection still rejected the original BF16 output for changed actors, wrong language, incorrect keyboard/mouse explanation, repeated names and altered conversation facts. No real quantization or APK release was performed. See THINKING-VALIDATION.md and the adjacent raw outputs and recipes. Core Java: 130; C++ separator: 86; Python: 30. Actual-model host cache/cancellation/recovery passed.
