# צ׳אט כשר — 1.2.1-beta

יישום Android בעברית עם ממשק RTL, שיחות, מחשבון, מידע מקומי ופעולות מכשיר באישור. נבנה APK Full חתום עם מודל DictaLM מקומי כלול, ללא הרשאת INTERNET. הגרסה היא בטא: טעויות במענה עדיין קיימות.

הקובץ kosher-chat-1.2.1-full-beta.apk קטן מ־800,000,000 בתים. נתונים ובדיקות ב־[docs/VALIDATION-1.2.1-beta.md](docs/VALIDATION-1.2.1-beta.md); הוראות התקנה ב־[docs/USER-GUIDE.md](docs/USER-GUIDE.md).

## המודל

נגזרת DictaLM 3.0 1.7B Instruct, עם כל 28 שכבות, 30,000 טוקנים לעברית ואנגלית, IQ4_XS לשכבות ו־Q5_K ל־embedding. כל הטוקנים הכוללים בתים עבריים נשמרו, עם סגירת מיזוגים. מידע מלא ומתכוני מקור, צמצום וכיול ב־docs/experiments/alternative-models. אין לטעון שהנגזרת היא המקור המקורי המלא או שמבחני עשן מוכיחים דיוק בכל שאלה.

Gemma 3 ו־Gemma 4 נשארו נתמכים בייבוא רק על פי זהות מוכרת. מודלי ניסוי אחרים אינם מאושרים לייבוא. שער Full של גרסה זו דורש דווקא את DICTA_HE_EN_BETA המוצמד ב־ModelSpec.java, ולא כל מודל קטן. ההרשאה הזו היא להפצת בטא מפורשת, עם ממצאי הסקירה הידנית, ולא אישור שאין שגיאות במענה.

## בנייה

Android SDK 35, Build Tools 35.0.0, NDK 27.2.12479018, CMake 3.22.1, JDK 17 ו־Gradle 8.9. מפתח הבעלים ו־signing.properties נמצאים מחוץ למקור הציבורי. Full ו־Lite משתמשות באותו applicationId; אין להתקין Lite מעל Full אם רוצים לשמור את המודל הכלול.

```bash
python3 tools/prepare.py --model-file /path/to/verified-beta-model.gguf
./gradlew assembleFullRelease lintFullRelease
python3 tools/package_apk.py --input app/build/outputs/apk/full/release/app-full-release.apk --out kosher-chat-1.2.1-full-beta.apk --sdk /path/to/sdk --keystore /path/to/owner-release.jks --password-file /path/to/keystore-password.txt
python3 tools/check_release.py --apk kosher-chat-1.2.1-full-beta.apk --sdk /path/to/sdk
```

המודל צריך להתאים בדיוק לגודל ול־SHA-256 הרשומים. הוא אינו נכלל בארכיון המקור. ניתן לשחזר את הנגזרת מהמקור המוצמד באמצעות fetch_dicta.py, convert_dicta.py, compact_dicta.py עם 30,000 טוקנים, calibrate_compact.py ו־quantize_dicta_compact.py. מתכון הכימות שומר את חתימות הכלים והחבילות ששימשו בפועל. compact_dicta.py משמר גם גרסאות של מילים טכניות וטוקני בקרה; אין להסיר שכבות כדי לעקוף את מגבלת הגודל.

## בדיקות ועדכונים

תשובה שנחתכה אינה מוצגת כשלמה; טקסט UTF-8 פגום נדחה. פלט עובר סינון לפני ההצגה. פעולות המכשיר נגזרות מבקשת המשתמש ודורשות אישור, ולא מתשובת המודל. חבילות kchat דורשות חתימה, checksum, גדלים, נתיבים ומספר גרסה תקינים. APK חדש נחתם באותו מפתח וב־versionCode גבוה יותר.

בדיקות הליבה, Python, JNI ומודל מתוך APK נעשו במחשב. הגרסה הזו לא נבדקה בטלפון פיזי. הסינון ניסיוני ואינו סינון רשמי של נטפרי או אישור כשרות.

## רישיונות

DictaLM 3.0: Apache 2.0, DICTA והשותפים. llama.cpp v0.6.0: MIT, עם תיקון מקומי קטן לקבוע גודל ב־32 ביט. ייבוא Gemma 3 כפוף לתנאי Gemma. הרישיונות והודעות שינוי נגישים ב־third-party וביישום. קרדיט: מוקד המערכות — מתמחים טופ; MH0774020798@GMAIL.COM.

תיעוד ניסויי Gemma 4 ו־Thinking נשמר כתיעוד היסטורי ב־DEVELOPMENT.md וב־docs/experiments. אותם מועמדים שנפסלו אינם המודל שנכלל ב־APK זה.
