# JNI looks up these names directly.
-keep class com.moked.kosherchat.NativeEngine { *; }
-keep interface com.moked.kosherchat.NativeEngine$Progress { *; }
-keepclassmembers class * implements com.moked.kosherchat.NativeEngine$Progress {
    public void onProgress(int);
}
