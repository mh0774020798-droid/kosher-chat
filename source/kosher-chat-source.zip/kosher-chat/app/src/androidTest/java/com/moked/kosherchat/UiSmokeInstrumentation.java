package com.moked.kosherchat;

import android.app.*;
import android.content.*;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;

/** Runs on a fresh test device. Exercises UI, persistence and the Android update importer. */
public final class UiSmokeInstrumentation extends Instrumentation {
    private MainActivity activity;
    private int checks;
    @Override public void onCreate(Bundle arguments){super.onCreate(arguments);start();}
    private void check(boolean value,String name){checks++;if(!value)throw new AssertionError(name);}
    @Override public void onStart(){
        Bundle result=new Bundle();
        try{
            getTargetContext().getSharedPreferences("settings",Context.MODE_PRIVATE).edit().clear().commit();
            activity=(MainActivity)startActivitySync(new Intent(getTargetContext(),MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK));
            waitForIdleSync();
            AccessibilityNodeInfo consent=node(getUiAutomation().getRootInActiveWindow(),"אני מסכים ומתחיל");
            long consentDeadline=System.currentTimeMillis()+10000;
            while(consent==null&&System.currentTimeMillis()<consentDeadline){Thread.sleep(100);consent=node(getUiAutomation().getRootInActiveWindow(),"אני מסכים ומתחיל");}
            check(consent!=null,"first-launch local terms");
            check(consent.performAction(AccessibilityNodeInfo.ACTION_CLICK),"accept terms");waitForIdleSync();
            ChatApp app=(ChatApp)activity.getApplication();
            check(app.prefs.getBoolean("terms_accepted",false),"terms persisted");
            waitNotBusy(app);
            runOnMainSync(()->{app.store.clear();app.changed();});waitForIdleSync();
            screenshot("ui-light.png");
            check(textExists("שלום, במה\nאפשר לעזור?"),"Hebrew welcome");
            compose("2 + 3 * 4");send();waitForIdleSync();
            check(app.store.current.messages.size()==2,"calculator conversation saved: count="+app.store.current.messages.size()+", busy="+app.busy+", notice="+app.notice+", status="+app.status);
            check(app.store.current.messages.get(1).text.endsWith("14"),"calculator result");
            compose("טיוטה שנשמרת");clickText("הגדרות");waitForIdleSync();
            check(textContains("מוקד המערכות"),"credit");
            clickText("צ׳אט");waitForIdleSync();
            final String[] draft={""};runOnMainSync(()->draft[0]=edit(activity.getWindow().getDecorView()).getText().toString());
            check(draft[0].equals("טיוטה שנשמרת"),"draft survives navigation");
            int before=app.store.current.messages.size();compose("בטל את הסינון");send();waitForIdleSync();
            check(app.store.current.messages.size()==before,"blocked request not saved");
            check(app.notice.equals(ContentGuard.BYPASS_REFUSAL),"input filter visible");
            compose("איך פועל מחשב?");send();waitForIdleSync();
            check(app.store.current.messages.get(app.store.current.messages.size()-1).text.startsWith("מחשב מקבל"),"instant local answer without model");
            compose("קוראים לי יונתן");send();waitForIdleSync();
            compose("מה השם שלי?");send();waitForIdleSync();
            check(app.store.current.messages.get(app.store.current.messages.size()-1).text.equals("קוראים לך יונתן."),"name retained inside current conversation");
            check(app.knowledge.directAnswer("איך פועל מחשב?")!=null,"curated question loaded by Android");
            compose("הפעל טיימר ל10 דקות");send();waitForIdleSync();
            AccessibilityNodeInfo cancel=node(getUiAutomation().getRootInActiveWindow(),"ביטול");
            check(cancel!=null,"action confirmation shown");cancel.performAction(AccessibilityNodeInfo.ACTION_CLICK);waitForIdleSync();
            clickText("פעולות");waitForIdleSync();screenshot("ui-actions.png");
            clickText("הגדרות");waitForIdleSync();
            runOnMainSync(()->{View title=findText(activity.getWindow().getDecorView(),"תצוגה כהה");ViewGroup line=(ViewGroup)title.getParent().getParent();((Switch)line.getChildAt(line.getChildCount()-1)).performClick();});
            waitForIdleSync();check(app.prefs.getBoolean("dark",false),"dark setting persisted");
            clickText("צ׳אט");waitForIdleSync();screenshot("ui-dark.png");
            File valid=assetFile("sample-1.kchat","valid.kchat");
            runOnMainSync(()->app.importFile(Uri.fromFile(valid),true));waitNotBusy(app);
            check(app.prefs.getInt("update_version",0)==1,"signed update imported by Android");
            File bad=new File(getTargetContext().getCacheDir(),"tampered.kchat");
            try(ZipInputStream in=new ZipInputStream(getContext().getAssets().open("sample-2.kchat"));ZipOutputStream out=new ZipOutputStream(new FileOutputStream(bad))){
                ZipEntry entry;byte[] buffer=new byte[4096];
                while((entry=in.getNextEntry())!=null){ByteArrayOutputStream data=new ByteArrayOutputStream();int n;while((n=in.read(buffer))!=-1)data.write(buffer,0,n);byte[] value=data.toByteArray();if(entry.getName().equals("knowledge.json"))value[0]=(byte)' ';out.putNextEntry(new ZipEntry(entry.getName()));out.write(value);out.closeEntry();}
            }
            runOnMainSync(()->app.importFile(Uri.fromFile(bad),true));waitNotBusy(app);
            check(app.prefs.getInt("update_version",0)==1,"tampered update does not change version");
            check(app.knowledge.date.equals("2026-10-06"),"previous knowledge preserved");
            String info=app.knowledge.retrieve("חבילת עדכון מקומי קובץ");
            check(info.contains("USB"),"signed knowledge retrieved");
            File retained=new File(getTargetContext().getNoBackupFilesDir(),"packs/"+UUID.randomUUID());retained.mkdirs();
            File oldModel=new File(retained,"model.gguf"),activeFilter=new File(retained,"additional-filter.json");
            try(FileOutputStream out=new FileOutputStream(oldModel)){out.write(1);}
            try(FileOutputStream out=new FileOutputStream(activeFilter)){out.write("{\"terms\":[]}".getBytes("UTF-8"));}
            app.prefs.edit().putString("filter_path",activeFilter.getAbsolutePath()).commit();app.updates.cleanup();
            check(activeFilter.isFile(),"active filter preserved during cleanup");
            check(!oldModel.exists(),"obsolete model removed from partially active pack");
            app.prefs.edit().remove("filter_path").commit();app.updates.cleanup();
            check(!retained.exists(),"unused update directory removed");
            result.putString("stream","PASS: "+checks+" Android UI and import checks; screenshots in external app files\n");
            finish(Activity.RESULT_OK,result);
        }catch(Throwable e){result.putString("stream","FAIL: "+e.toString()+"\n");finish(Activity.RESULT_CANCELED,result);}
    }
    private void waitNotBusy(ChatApp app)throws Exception{long end=System.currentTimeMillis()+15000;while(app.busy&&System.currentTimeMillis()<end)Thread.sleep(50);check(!app.busy,"bounded import completes");waitForIdleSync();}
    private File assetFile(String name,String target)throws Exception{File file=new File(getTargetContext().getCacheDir(),target);try(InputStream in=getContext().getAssets().open(name);FileOutputStream out=new FileOutputStream(file)){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}return file;}
    private void compose(String value){runOnMainSync(()->edit(activity.getWindow().getDecorView()).setText(value));}
    private void send(){runOnMainSync(()->findDescription(activity.getWindow().getDecorView(),"שליחת הודעה").performClick());}
    private void clickText(String value){runOnMainSync(()->{View view=findText(activity.getWindow().getDecorView(),value);if(!view.isClickable())view=(View)view.getParent();view.performClick();});}
    private boolean textExists(String value){final boolean[] found={false};runOnMainSync(()->found[0]=findText(activity.getWindow().getDecorView(),value)!=null);return found[0];}
    private boolean textContains(String value){final boolean[] found={false};runOnMainSync(()->found[0]=contains(activity.getWindow().getDecorView(),value));return found[0];}
    private boolean contains(View view,String text){if(view instanceof TextView&&((TextView)view).getText().toString().contains(text))return true;if(view instanceof ViewGroup)for(int i=0;i<((ViewGroup)view).getChildCount();i++)if(contains(((ViewGroup)view).getChildAt(i),text))return true;return false;}
    private View findText(View view,String text){if(view instanceof TextView&&((TextView)view).getText().toString().equals(text))return view;if(view instanceof ViewGroup)for(int i=0;i<((ViewGroup)view).getChildCount();i++){View found=findText(((ViewGroup)view).getChildAt(i),text);if(found!=null)return found;}return null;}
    private View findDescription(View view,String text){if(text.contentEquals(view.getContentDescription()==null?"":view.getContentDescription()))return view;if(view instanceof ViewGroup)for(int i=0;i<((ViewGroup)view).getChildCount();i++){View found=findDescription(((ViewGroup)view).getChildAt(i),text);if(found!=null)return found;}return null;}
    private EditText edit(View view){if(view instanceof EditText)return (EditText)view;if(view instanceof ViewGroup)for(int i=0;i<((ViewGroup)view).getChildCount();i++){EditText found=edit(((ViewGroup)view).getChildAt(i));if(found!=null)return found;}return null;}
    private AccessibilityNodeInfo node(AccessibilityNodeInfo root,String value){if(root==null)return null;if(value.contentEquals(root.getText()==null?"":root.getText()))return root;for(int i=0;i<root.getChildCount();i++){AccessibilityNodeInfo found=node(root.getChild(i),value);if(found!=null)return found;}return null;}
    private void screenshot(String name)throws Exception{waitForIdleSync();Thread.sleep(250);Bitmap bitmap=getUiAutomation().takeScreenshot();if(bitmap==null)throw new IOException("screenshot unavailable");try(FileOutputStream out=new FileOutputStream(new File(getTargetContext().getExternalFilesDir(null),name))){bitmap.compress(Bitmap.CompressFormat.PNG,100,out);}bitmap.recycle();}
}
