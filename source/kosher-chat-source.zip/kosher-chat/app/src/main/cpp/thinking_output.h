#pragma once
#include <algorithm>
#include <stdexcept>
#include <string>

// A thinking model's prompt already ends in <think>. No private text is returned
// or sent to a listener. Keep only enough bytes to recognize a split delimiter.
class ThinkingOutput {
    bool private_phase;
    bool reasoning_model;
    std::string delimiter_tail;
    std::string visible;

public:
    explicit ThinkingOutput(bool thinking) : private_phase(thinking), reasoning_model(thinking) {}

    bool thinking() const { return private_phase; }

    void append(const std::string &piece) {
        if (!private_phase) {
            visible += piece;
            return;
        }
        static const std::string delimiter = "</think>";
        std::string pending = delimiter_tail + piece;
        const auto end = pending.find(delimiter);
        if (end != std::string::npos) {
            private_phase = false;
            delimiter_tail.clear();
            visible = pending.substr(end + delimiter.size());
            return;
        }
        delimiter_tail = pending.substr(pending.size() - std::min(pending.size(), delimiter.size() - 1));
    }

    std::string finish() const {
        if (private_phase) throw std::runtime_error("THINKING_INCOMPLETE");
        if (reasoning_model) {
            if (visible.find("<think") != std::string::npos || visible.find("</think") != std::string::npos)
                throw std::runtime_error("THINKING_FORMAT_INVALID");
            if (visible.find_first_not_of(" \t\r\n") == std::string::npos)
                throw std::runtime_error("THINKING_EMPTY_ANSWER");
        }
        return visible;
    }
};
