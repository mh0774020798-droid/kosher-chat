#include <jni.h>
#include <llama.h>
#include <atomic>
#include <algorithm>
#include <cstring>
#include <memory>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>
#include <cstdio>
#include <unistd.h>
#include "thinking_output.h"

// All calls except cancel/reset run on the application's single worker.
static llama_model *model = nullptr;
static llama_context *ctx = nullptr;
static std::atomic<bool> stopped{false};
static bool initialized = false;
static FILE *asset_file = nullptr;
static std::vector<llama_token> cached_tokens;
static int last_reused = 0, last_decoded = 0;
static int model_family = 0;
static bool generation_truncated = false;
static bool abort_decode(void *) { return stopped.load(); }
static void quiet_log(enum ggml_log_level, const char *, void *) {}
static void fail(JNIEnv *env, const char *message) {
    env->ThrowNew(env->FindClass("java/lang/IllegalStateException"), message);
}
static void close_model() {
    model_family = 0;
    generation_truncated = false;
    cached_tokens.clear(); last_reused = last_decoded = 0;
    if (ctx) { llama_free(ctx); ctx = nullptr; }
    if (model) { llama_model_free(model); model = nullptr; }
    if (asset_file) { fclose(asset_file); asset_file = nullptr; }
}
static void check_architecture() {
    char architecture[64] = {};
    if (llama_model_meta_val_str(model, "general.architecture", architecture, sizeof(architecture)) < 0)
        throw std::runtime_error("UNSUPPORTED_MODEL_ARCHITECTURE");
    if (std::strcmp(architecture, "gemma3") == 0) { model_family = 3; return; }
    if (std::strcmp(architecture, "qwen3") == 0 || std::strcmp(architecture, "qwen35") == 0) {
        const bool hybrid = std::strcmp(architecture, "qwen35") == 0;
        char blocks[32] = {}, embedding[32] = {};
        std::string prefix = std::string(architecture) + ".";
        llama_model_meta_val_str(model, (prefix + "block_count").c_str(), blocks, sizeof(blocks));
        llama_model_meta_val_str(model, (prefix + "embedding_length").c_str(), embedding, sizeof(embedding));
        const bool supported_width = std::strcmp(embedding, "1024") == 0 || std::strcmp(embedding, "2048") == 0;
        if (std::strcmp(blocks, hybrid ? "24" : "28") == 0 && supported_width) {
            char name[256] = {};
            llama_model_meta_val_str(model, "general.name", name, sizeof(name));
            model_family = !hybrid && std::strcmp(name, "DictaLM 3.0 1.7B Thinking") == 0 ? 32 :
                !hybrid && std::strcmp(name, "DictaLM 3.0 1.7B Instruct") == 0 ? 31 : hybrid ? 35 : 30;
            return;
        }
    }
    if (std::strcmp(architecture, "gemma4") == 0) {
        char blocks[32] = {}, embedding[32] = {};
        llama_model_meta_val_str(model, "gemma4.block_count", blocks, sizeof(blocks));
        llama_model_meta_val_str(model, "gemma4.embedding_length", embedding, sizeof(embedding));
        if (std::strcmp(blocks, "35") == 0 && std::strcmp(embedding, "1536") == 0) { model_family = 4; return; }
    }
    throw std::runtime_error("UNSUPPORTED_MODEL_ARCHITECTURE");
}
static std::string bytes(JNIEnv *env, jbyteArray array) {
    if (!array) return {};
    auto n = env->GetArrayLength(array);
    std::string out(n, '\0');
    env->GetByteArrayRegion(array, 0, n, reinterpret_cast<jbyte *>(out.data()));
    return out;
}
static std::vector<llama_token> tokenize(const std::string &text) {
    if (!model) throw std::runtime_error("MODEL_NOT_LOADED");
    const auto *vocab = llama_model_get_vocab(model);
    int n = llama_tokenize(vocab, text.data(), int(text.size()), nullptr, 0, false, true);
    if (n >= 0) return {};
    std::vector<llama_token> out(-n);
    n = llama_tokenize(vocab, text.data(), int(text.size()), out.data(), int(out.size()), false, true);
    if (n < 0) throw std::runtime_error("TOKENIZATION_FAILED");
    out.resize(n); return out;
}
extern "C" JNIEXPORT void JNICALL
Java_com_moked_kosherchat_NativeEngine_load(JNIEnv *env, jclass, jbyteArray path, jint context, jint threads) {
    try {
        close_model();
        if (!initialized) { llama_log_set(quiet_log, nullptr); llama_backend_init(); initialized = true; }
        auto mp = llama_model_default_params();
        mp.n_gpu_layers = 0; mp.load_mode = LLAMA_LOAD_MODE_MMAP; mp.use_extra_bufts = false;
        model = llama_model_load_from_file(bytes(env, path).c_str(), mp);
        if (!model) throw std::runtime_error("MODEL_LOAD_FAILED");
        check_architecture();
        auto cp = llama_context_default_params();
        cp.n_ctx = std::clamp(int(context), 512, 2048);
        cp.n_batch = 128; cp.n_ubatch = 32; cp.n_outputs_max = 1; cp.n_outputs_max_per_seq = 1;
        cp.n_threads = cp.n_threads_batch = std::clamp(int(threads), 1, 4);
        cp.offload_kqv = false;
        cp.abort_callback = abort_decode;
        ctx = llama_init_from_model(model, cp);
        if (!ctx) throw std::runtime_error("CONTEXT_LOAD_FAILED");
    } catch (const std::exception &e) { close_model(); fail(env, e.what()); }
}
extern "C" JNIEXPORT void JNICALL
Java_com_moked_kosherchat_NativeEngine_loadAsset(JNIEnv *env, jclass, jint fd, jlong offset, jint context, jint threads) {
    try {
        close_model();
        if (!initialized) { llama_log_set(quiet_log, nullptr); llama_backend_init(); initialized = true; }
        int owned_fd = dup(fd);
        if (owned_fd < 0) throw std::runtime_error("ASSET_OPEN_FAILED");
        asset_file = fdopen(owned_fd, "rb");
        if (!asset_file) { ::close(owned_fd); throw std::runtime_error("ASSET_OPEN_FAILED"); }
        if (fseeko(asset_file, static_cast<off_t>(offset), SEEK_SET) != 0) throw std::runtime_error("ASSET_SEEK_FAILED");
        auto mp = llama_model_default_params();
        mp.n_gpu_layers = 0; mp.load_mode = offset % 32 == 0 ? LLAMA_LOAD_MODE_MMAP : LLAMA_LOAD_MODE_NONE; mp.use_extra_bufts = false;
        model = llama_model_load_from_file_ptr(asset_file, mp);
        if (!model) throw std::runtime_error("MODEL_ASSET_LOAD_FAILED");
        check_architecture();
        auto cp = llama_context_default_params();
        cp.n_ctx = std::clamp(int(context), 512, 2048);
        cp.n_batch = 128; cp.n_ubatch = 32; cp.n_outputs_max = 1; cp.n_outputs_max_per_seq = 1;
        cp.n_threads = cp.n_threads_batch = std::clamp(int(threads), 1, 4);
        cp.offload_kqv = false; cp.abort_callback = abort_decode;
        ctx = llama_init_from_model(model, cp);
        if (!ctx) throw std::runtime_error("CONTEXT_LOAD_FAILED");
    } catch (const std::exception &e) { close_model(); fail(env, e.what()); }
}
extern "C" JNIEXPORT void JNICALL
Java_com_moked_kosherchat_NativeEngine_close(JNIEnv *, jclass) { close_model(); }
extern "C" JNIEXPORT void JNICALL
Java_com_moked_kosherchat_NativeEngine_cancel(JNIEnv *, jclass) { stopped.store(true); }
extern "C" JNIEXPORT void JNICALL
Java_com_moked_kosherchat_NativeEngine_reset(JNIEnv *, jclass) { stopped.store(false); }
extern "C" JNIEXPORT jint JNICALL
Java_com_moked_kosherchat_NativeEngine_countTokens(JNIEnv *env, jclass, jbyteArray text) {
    try { return int(tokenize(bytes(env, text)).size()); }
    catch (const std::exception &e) { fail(env, e.what()); return 0; }
}
extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_moked_kosherchat_NativeEngine_generateBounded(JNIEnv *env, jclass, jbyteArray prompt, jint limit, jint reasoning_limit, jobject listener) {
    try {
        generation_truncated = false;
        if (!ctx || !model) throw std::runtime_error("MODEL_NOT_LOADED");
        const bool thinking_model = model_family == 32;
        if (limit < 1 || limit > 512 || (thinking_model ? reasoning_limit < 1 || reasoning_limit > 512 : reasoning_limit != 0))
            throw std::runtime_error("INVALID_GENERATION_LIMIT");
        const int total_limit = limit + reasoning_limit;
        auto tokens = tokenize(bytes(env, prompt));
        if (tokens.empty() || tokens.size() + size_t(total_limit) + 4 > llama_n_ctx(ctx))
            throw std::runtime_error("PROMPT_TOO_LONG");
        auto memory = llama_get_memory(ctx);
        size_t reused = 0;
        while (reused < tokens.size() && reused < cached_tokens.size() && tokens[reused] == cached_tokens[reused]) ++reused;
        // Decode the final prompt token again so current logits always belong to it.
        reused = std::min(reused, tokens.size() - 1);
        if (llama_memory_seq_pos_min(memory, 0) > 0 || !llama_memory_seq_rm(memory, 0, llama_pos(reused), -1)) {
            llama_memory_clear(memory, true); reused = 0;
        }
        cached_tokens.resize(reused);
        last_reused = int(reused); last_decoded = 0;
        auto batch = llama_batch_init(128, 0, 1);
        struct BatchGuard { llama_batch &b; ~BatchGuard() { llama_batch_free(b); } } bg{batch};
        auto decode = [&](const llama_token *data, int n, int position) {
            batch.n_tokens = n;
            for (int i = 0; i < n; ++i) {
                batch.token[i] = data[i]; batch.pos[i] = position + i;
                batch.n_seq_id[i] = 1; batch.seq_id[i][0] = 0;
                batch.logits[i] = (i == n-1);
            }
            int result = llama_decode(ctx, batch);
            if (stopped.load()) throw std::runtime_error("CANCELLED");
            if (result != 0) throw std::runtime_error("DECODE_FAILED");
            cached_tokens.insert(cached_tokens.end(), data, data+n);
        };
        for (int position = int(reused); position < int(tokens.size()); position += 128) {
            if (stopped.load()) throw std::runtime_error("CANCELLED");
            int n = std::min(128, int(tokens.size()) - position);
            decode(tokens.data() + position, n, position);
            last_decoded += n;
        }
        auto sampler = std::unique_ptr<llama_sampler, decltype(&llama_sampler_free)>(
            llama_sampler_chain_init(llama_sampler_chain_default_params()), &llama_sampler_free);
        const auto *vocab = llama_model_get_vocab(model);
        const auto closing_tokens = thinking_model ? tokenize("</think>") : std::vector<llama_token>{};
        if (thinking_model && closing_tokens.size() != 1) throw std::runtime_error("THINKING_TOKEN_MISSING");
        std::vector<llama_logit_bias> control_biases;
        for (llama_token token = 0; token < llama_vocab_n_tokens(vocab); ++token) {
            // This app exposes plain text, not tool calls or channel/role transitions.
            // Keep end-of-generation tokens so the model can terminate normally.
            if (llama_vocab_is_control(vocab, token) && !llama_vocab_is_eog(vocab, token) &&
                !(thinking_model && token == closing_tokens[0]))
                control_biases.push_back({token, -std::numeric_limits<float>::infinity()});
        }
        if (!control_biases.empty()) llama_sampler_chain_add(sampler.get(),
            llama_sampler_init_logit_bias(llama_vocab_n_tokens(vocab), int32_t(control_biases.size()), control_biases.data()));
        const bool qwen = model_family == 30 || model_family == 35;
        const bool dicta = model_family == 31 || thinking_model;
        llama_sampler_chain_add(sampler.get(), llama_sampler_init_penalties(llama_vocab_n_tokens(vocab), qwen ? 128 : 64, qwen || dicta ? 1.0f : 1.05f, 0.0f, model_family == 35 ? 1.5f : 0.0f));
        llama_sampler_chain_add(sampler.get(), llama_sampler_init_top_k(20));
        // Dicta's published generation_config: temperature .6, top-p .95,
        // top-k 20, without a repetition or presence penalty.
        llama_sampler_chain_add(sampler.get(), llama_sampler_init_top_p(dicta ? 0.95f : 0.8f, 1));
        // Non-reasoning Dicta uses deterministic decoding for short factual tasks.
        // Thinking retains the upstream temperature.
        llama_sampler_chain_add(sampler.get(), llama_sampler_init_temp(model_family == 31 ? 0.0f : dicta ? 0.6f : qwen ? 0.7f : 0.35f));
        llama_sampler_chain_add(sampler.get(), llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
        jmethodID progress = listener ? env->GetMethodID(env->GetObjectClass(listener), "onProgress", "(I)V") : nullptr;
        ThinkingOutput output(thinking_model);
        int reasoning_tokens = 0, answer_tokens = 0;
        for (int i = 0; i < total_limit; ++i) {
            if (stopped.load()) throw std::runtime_error("CANCELLED");
            auto token = llama_sampler_sample(sampler.get(), ctx, -1);
            if (llama_vocab_is_eog(vocab, token)) break;
            std::string piece;
            char small[256];
            int n = llama_token_to_piece(vocab, token, small, sizeof(small), 0, true);
            if (n < 0) {
                std::vector<char> large(-n);
                n = llama_token_to_piece(vocab, token, large.data(), int(large.size()), 0, true);
                if (n > 0) piece.assign(large.data(), n);
            } else piece.assign(small, n);
            const bool private_token = output.thinking();
            output.append(piece);
            if (private_token) ++reasoning_tokens; else ++answer_tokens;
            if (output.thinking() && reasoning_tokens >= reasoning_limit)
                throw std::runtime_error("THINKING_LIMIT");
            if (progress && (i % 8 == 0)) {
                env->CallVoidMethod(listener, progress, i+1);
                if (env->ExceptionCheck()) { cached_tokens.clear(); llama_memory_clear(memory, true); return nullptr; }
            }
            decode(&token, 1, int(tokens.size())+i);
            if (!output.thinking() && answer_tokens >= limit) { generation_truncated = true; break; }
        }
        const auto answer = output.finish();
        auto result = env->NewByteArray(jsize(answer.size()));
        if (result) env->SetByteArrayRegion(result, 0, jsize(answer.size()), reinterpret_cast<const jbyte *>(answer.data()));
        return result;
    } catch (const std::exception &e) {
        cached_tokens.clear();
        if (ctx) llama_memory_clear(llama_get_memory(ctx), true);
        fail(env, e.what()); return nullptr;
    }
}
extern "C" JNIEXPORT jlongArray JNICALL
Java_com_moked_kosherchat_NativeEngine_cacheStats(JNIEnv *env, jclass) {
    jlong stats[2] = {last_reused, last_decoded};
    jlongArray result = env->NewLongArray(2);
    if (result) env->SetLongArrayRegion(result, 0, 2, stats);
    return result;
}
extern "C" JNIEXPORT jint JNICALL
Java_com_moked_kosherchat_NativeEngine_modelFamily(JNIEnv *, jclass) { return model_family; }
extern "C" JNIEXPORT jboolean JNICALL
Java_com_moked_kosherchat_NativeEngine_generationTruncated(JNIEnv *, jclass) { return generation_truncated; }
