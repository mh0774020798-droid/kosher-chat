package com.moked.kosherchat;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Small deterministic responses; questions outside these forms use the model. */
public final class QuickReplies {
    private static final Pattern NAME=Pattern.compile("^(?:קוראים לי|שמי|השם שלי הוא|my name is)\\s+([\\p{L}]+(?:[ -][\\p{L}]+){0,2})[.!]?$",Pattern.CASE_INSENSITIVE);
    public static String key(String input){return ContentGuard.normalizeText(input).replaceAll("[?!.,؟？]", "").trim();}
    public static String answer(String input,List<PromptBuilder.Message> history){
        String n=key(input);
        if(n.equals("שלום")||n.equals("היי")||n.equals("hello")||n.equals("hi"))return "שלום! במה אפשר לעזור?";
        if(n.equals("תודה")||n.equals("תודה רבה")||n.equals("thank you")||n.equals("thanks"))return "בשמחה!";
        Matcher named=NAME.matcher(input.trim());
        if(named.matches())return "נעים להכיר, "+named.group(1)+".";
        if(n.equals("איך קוראים לי")||n.equals("מה השם שלי")||n.equals("אתה זוכר איך קוראים לי")||n.equals("what is my name")){
            for(int i=history.size()-1;i>=0;i--){
                PromptBuilder.Message m=history.get(i);
                if(!"user".equals(m.role))continue;
                Matcher previous=NAME.matcher(m.text.trim());
                if(previous.matches())return "קוראים לך "+previous.group(1)+".";
            }
            return "עדיין לא מסרת לי שם בשיחה הזו.";
        }
        return null;
    }
}
