package com.moked.kosherchat;

final class ModelSpec {
    final int family;
    final long bytes;
    final String sha256,label;
    private ModelSpec(int family,long bytes,String sha256,String label){this.family=family;this.bytes=bytes;this.sha256=sha256;this.label=label;}
    static final ModelSpec GEMMA3=new ModelSpec(3,714435328L,"d250245a32db7e3421707cef3356a2a5f9ed7394c7759ec32fcee3d1b9fc427e","Gemma 3 1B IT · IQ4_XS");
    static final ModelSpec GEMMA4_FULL=new ModelSpec(4,2841481184L,"8e30dff3ac4c8434c49a7036fa15564bdbb6044e42bf04550bf1a096ad7e6a52","Gemma 4 E2B IT · Q4_0");
    // Reviewed beta: keep its identity distinct from the original checkpoint.
    static final ModelSpec DICTA_HE_EN_BETA=new ModelSpec(31,792574528L,"4a0ea24ea8d9d4bdcf0eee2ee3e848584a6c6d2b194d116ca84d0520e25af1e8","DictaLM 3 1.7B · HE/EN 30K · IQ4_XS · beta");
    static ModelSpec forSize(long n){for(ModelSpec s:new ModelSpec[]{GEMMA3,GEMMA4_FULL,DICTA_HE_EN_BETA})if(s.bytes==n)return s;return null;}
    static boolean matches(long n,String hash){ModelSpec s=forSize(n);return s!=null&&s.sha256.equals(hash);}
}
