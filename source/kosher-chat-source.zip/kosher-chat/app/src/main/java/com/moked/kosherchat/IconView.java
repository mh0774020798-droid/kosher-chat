package com.moked.kosherchat;

import android.content.Context;
import android.graphics.*;
import android.view.View;

public final class IconView extends View {
    private static final float[] SHIELD={12,2,21,6,21,12,19,17,12,22,5,17,3,12,3,6};
    private static final float[] CHAT_TAIL={7,18,5,22,12,18},SEND={3,12,21,3,17,21,12,14,3,12};
    private static final float[] SOUND={3,9,7,9,12,5,12,19,7,15,3,15};
    private static final float[] FILE={5,2,14,2,20,8,20,22,5,22},FILE_FOLD={14,2,14,8,20,8};
    private static final float[] UPDATE={16,2,20,6,15,6},COPY={16,4,16,2,3,2,3,17,5,17};
    private final Path drawingPath=new Path();
    String kind;int tint;private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    public IconView(Context c){this(c,"info",Color.GRAY);}
    IconView(Context c,String kind,int tint){super(c);this.kind=kind;this.tint=tint;setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
    @Override protected void onDraw(Canvas c){super.onDraw(c);c.save();float size=Math.min(getWidth()-getPaddingLeft()-getPaddingRight(),getHeight()-getPaddingTop()-getPaddingBottom());c.translate((getWidth()-size)/2,(getHeight()-size)/2);c.scale(size/24,size/24);p.setColor(tint);p.setStrokeWidth(1.7f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setStyle(Paint.Style.STROKE);
        switch(kind){
            case "shield": path(c,SHIELD,true);line(c,8,12,11,15);line(c,11,15,16,9);break;
            case "chat": c.drawRoundRect(3,3,21,18,4,4,p);path(c,CHAT_TAIL,false);line(c,7,9,17,9);line(c,7,13,13,13);break;
            case "send": path(c,SEND,true);line(c,12,14,21,3);break;
            case "plus": line(c,12,4,12,20);line(c,4,12,20,12);break;
            case "stop": c.drawRoundRect(5,5,19,19,3,3,p);break;
            case "history": c.drawCircle(12,12,9,p);line(c,12,6,12,12);line(c,12,12,16,14);break;
            case "sun":c.drawCircle(12,12,4,p);for(int i=0;i<8;i++){double a=i*Math.PI/4;line(c,12+7*(float)Math.cos(a),12+7*(float)Math.sin(a),12+10*(float)Math.cos(a),12+10*(float)Math.sin(a));}break;
            case "sound":path(c,SOUND,true);c.drawArc(11,5,23,19,-60,120,false,p);c.drawArc(10,8,19,16,-60,120,false,p);break;
            case "timer":c.drawCircle(12,14,8,p);line(c,9,2,15,2);line(c,12,2,12,6);line(c,12,9,12,14);line(c,18,7,20,5);break;
            case "file":path(c,FILE,true);path(c,FILE_FOLD,false);line(c,9,13,16,13);line(c,9,17,14,17);break;
            case "settings":case "tools":line(c,4,6,20,6);line(c,4,12,20,12);line(c,4,18,20,18);c.drawCircle(9,6,2,p);c.drawCircle(16,12,2,p);c.drawCircle(8,18,2,p);break;
            case "update":c.drawArc(3,3,21,21,35,285,false,p);path(c,UPDATE,false);line(c,12,8,12,16);line(c,9,13,12,16);line(c,15,13,12,16);break;
            case "moon":c.drawArc(3,3,21,21,15,285,false,p);c.drawArc(10,0,24,15,90,180,false,p);break;
            case "copy":c.drawRoundRect(8,7,21,22,2,2,p);path(c,COPY,false);break;
            case "check":line(c,4,12,10,18);line(c,10,18,20,6);break;
            default:c.drawCircle(12,12,9,p);line(c,12,11,12,17);c.drawCircle(12,7,.5f,p);
        }c.restore();
    }
    private void line(Canvas c,float a,float b,float x,float y){c.drawLine(a,b,x,y,p);}
    private void path(Canvas c,float[] v,boolean close){drawingPath.reset();drawingPath.moveTo(v[0],v[1]);for(int i=2;i<v.length;i+=2)drawingPath.lineTo(v[i],v[i+1]);if(close)drawingPath.close();c.drawPath(drawingPath,p);}
}
