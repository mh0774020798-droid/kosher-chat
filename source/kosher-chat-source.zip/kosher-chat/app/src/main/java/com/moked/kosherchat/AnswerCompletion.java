package com.moked.kosherchat;

import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;

/** Keep complete UTF-8 and disclose answers stopped by the token budget. */
public final class AnswerCompletion {
    public static String decode(byte[] bytes,boolean truncated) {
        int end=bytes.length;
        if(truncated){
            int start=end-1;
            while(start>=0&&(bytes[start]&0xC0)==0x80)start--;
            if(start>=0){
                int lead=bytes[start]&0xff;
                int needed=lead<0x80?1:lead>=0xc2&&lead<=0xdf?2:lead<=0xef&&lead>=0xe0?3:lead>=0xf0&&lead<=0xf4?4:1;
                if(end-start<needed)end=start;
            }
        }
        try{
            return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes,0,end)).toString().trim();
        }catch(CharacterCodingException e){throw new IllegalStateException("INVALID_OUTPUT_UTF8",e);}
    }
    public static String completePart(String text,boolean truncated) {
        if(!truncated)return text.trim();
        int last=-1;
        for(int i=0;i<text.length();i++){
            char c=text.charAt(i);
            if(c=='.'&&text.substring(text.lastIndexOf('\n',i)+1,i).trim().matches("[0-9]+"))continue;
            if((c=='.'||c=='!'||c=='?'||c=='\u2026')&&(i+1==text.length()||Character.isWhitespace(text.charAt(i+1))))last=i+1;
        }
        if(last>=0)return text.substring(0,last).trim();
        // Preserve completed list lines when no sentence terminator exists.
        int newline=text.lastIndexOf('\n');
        return newline>=0?text.substring(0,newline).trim():"";
    }
    private AnswerCompletion(){}
}
