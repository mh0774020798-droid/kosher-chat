package com.moked.kosherchat;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Base64;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;
import java.util.zip.*;

final class UpdateManager {
    static final long MAX_MODEL=3400000000L;
    private static final Set<String> COMPONENTS=new HashSet<>(Arrays.asList("model.gguf","knowledge.json","additional-filter.json"));
    static final class Candidate {File directory,model,knowledge,filter;int version;}
    private final Context c;private final SharedPreferences p;
    UpdateManager(Context c,SharedPreferences p){this.c=c;this.p=p;}
    File model(){
        String path=p.getString("model_path","");
        if(!path.isEmpty()){File imported=new File(path);if(imported.isFile())return imported;}
        // Explicit imports remain selected. An app upgrade uses its new bundled
        // model before the automatic copy left by older app versions.
        try(android.content.res.AssetFileDescriptor a=c.getAssets().openFd("model.gguf")){
            return new File(c.getApplicationInfo().sourceDir);
        }catch(IOException absent){
            File legacy=new File(c.getNoBackupFilesDir(),"model.gguf");
            return legacy.isFile()?legacy:null;
        }
    }
    File knowledge(){String s=p.getString("knowledge_path","");return s.isEmpty()?null:new File(s);}
    File filter(){String s=p.getString("filter_path","");return s.isEmpty()?null:new File(s);}
    File installBundled()throws Exception{return model();}
    private static long limit(String name){return name.equals("model.gguf")?MAX_MODEL:name.equals("knowledge.json")?2000000L:128000L;}
    private File privateFile(File f)throws IOException{
        File root=c.getNoBackupFilesDir().getCanonicalFile(),actual=f.getCanonicalFile();
        if(!actual.getPath().startsWith(root.getPath()+File.separator)||!actual.isFile())throw new IOException("INVALID_PRIVATE_PATH");
        return actual;
    }
    private JSONObject parseManifest(byte[] bytes,byte[] signature)throws Exception{
        String pem=new String(FilesLocal.read(c.getAssets().open("update-public.pem"),8192),StandardCharsets.UTF_8).replace("-----BEGIN PUBLIC KEY-----","").replace("-----END PUBLIC KEY-----","").replaceAll("\\s","");
        PublicKey key=KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Base64.decode(pem,Base64.DEFAULT)));
        Signature verify=Signature.getInstance("SHA256withRSA");verify.initVerify(key);verify.update(bytes);
        if(!verify.verify(signature))throw new IOException("BAD_SIGNATURE");
        JSONObject root=new JSONObject(new String(bytes,StandardCharsets.UTF_8));
        if(!root.getString("format").equals("kchat-update-v1")||root.getInt("version")<1)throw new IOException("INVALID_PACK_FORMAT");
        JSONObject files=root.getJSONObject("files");if(files.length()<1||files.length()>3)throw new IOException("INVALID_MANIFEST");
        Iterator<String> it=files.keys();while(it.hasNext()){
            String name=it.next();if(!COMPONENTS.contains(name))throw new IOException("INVALID_MANIFEST_FILE");
            JSONObject f=files.getJSONObject(name);long size=f.getLong("size");
            if(size<1||size>limit(name)||!f.getString("sha256").matches("[a-f0-9]{64}"))throw new IOException("INVALID_FILE_METADATA");
        }
        return root;
    }
    private void verifyComponent(File file,String name,boolean rawModel)throws Exception{
        File f=privateFile(file);if(!f.getName().equals(name))throw new IOException("INVALID_PRIVATE_PATH");
        File manifest=new File(f.getParentFile(),"manifest.json"),sig=new File(f.getParentFile(),"manifest.sig");
        if(manifest.isFile()&&sig.isFile()){
            JSONObject root=parseManifest(FilesLocal.read(new FileInputStream(privateFile(manifest)),32768),FilesLocal.read(new FileInputStream(privateFile(sig)),512));
            JSONObject spec=root.getJSONObject("files").getJSONObject(name);long size=spec.getLong("size");
            if(f.length()!=size||!FilesLocal.digest(new FileInputStream(f),size).equals(spec.getString("sha256")))throw new IOException("FILE_CHECKSUM_FAILED");
        }else if(rawModel&&name.equals("model.gguf")){
            ModelSpec spec=ModelSpec.forSize(f.length());if(spec==null||!spec.sha256.equals(FilesLocal.digest(new FileInputStream(f),spec.bytes)))throw new IOException("UNKNOWN_MODEL");
        }else throw new IOException("MISSING_SIGNATURE");
    }
    ModelSpec verifyModel(File f)throws Exception{
        if(f.getAbsolutePath().equals(c.getApplicationInfo().sourceDir)){
            try(android.content.res.AssetFileDescriptor asset=c.getAssets().openFd("model.gguf")){
                ModelSpec spec=ModelSpec.forSize(asset.getLength());
                if(spec==null||!spec.sha256.equals(FilesLocal.digest(c.getAssets().open("model.gguf"),spec.bytes)))throw new IOException("MODEL_CHECKSUM_FAILED");
                return spec;
            }
        }
        verifyComponent(f,"model.gguf",true);return ModelSpec.forSize(f.length());
    }
    void verifyInstalled()throws Exception{
        if(p.getInt("integrity_format",0)<1){
            SharedPreferences.Editor e=p.edit();boolean recovery=false;
            for(String key:Arrays.asList("model_path","knowledge_path","filter_path")){
                String path=p.getString(key,"");if(path.isEmpty())continue;
                try{verifyComponent(new File(path),key.equals("model_path")?"model.gguf":key.equals("knowledge_path")?"knowledge.json":"additional-filter.json",key.equals("model_path"));}
                catch(Exception legacy){e.putString("legacy_"+key,path).remove(key);recovery=true;}
            }
            if(recovery)e.putBoolean("legacy_restore_allowed",true);
            if(!e.putInt("integrity_format",1).commit())throw new IOException("UPDATE_COMMIT_FAILED");
        }
        if(knowledge()!=null)verifyComponent(knowledge(),"knowledge.json",false);
        if(filter()!=null)verifyComponent(filter(),"additional-filter.json",false);
    }
    void verifyRetained(Candidate candidate)throws Exception{
        if(candidate.knowledge==null&&knowledge()!=null)verifyComponent(knowledge(),"knowledge.json",false);
        if(candidate.filter==null&&filter()!=null)verifyComponent(filter(),"additional-filter.json",false);
    }
    Candidate importModel(Uri uri)throws Exception{
        Candidate result=create();result.model=new File(result.directory,"model.gguf");
        try{
            String sha=FilesLocal.copy(c.getContentResolver().openInputStream(uri),result.model,MAX_MODEL);
            if(!ModelSpec.matches(result.model.length(),sha))throw new IOException("UNKNOWN_MODEL");return result;
        }catch(Exception e){FilesLocal.remove(result.directory);throw e;}
    }
    Candidate importPack(Uri uri,ContentGuard guard)throws Exception{
        Candidate result=create();File archive=new File(result.directory,"archive.zip");
        try{
            FilesLocal.copy(c.getContentResolver().openInputStream(uri),archive,MAX_MODEL+20000000L);
            try(ZipFile zip=new ZipFile(archive)){
                Set<String> names=new HashSet<>();Enumeration<? extends ZipEntry> entries=zip.entries();
                Set<String> allowed=new HashSet<>(COMPONENTS);allowed.add("manifest.json");allowed.add("manifest.sig");
                while(entries.hasMoreElements()){ZipEntry e=entries.nextElement();if(e.isDirectory()||!allowed.contains(e.getName())||!names.add(e.getName()))throw new IOException("INVALID_PACK_ENTRY");}
                if(!names.contains("manifest.json")||!names.contains("manifest.sig"))throw new IOException("MISSING_SIGNATURE");
                byte[] manifest=FilesLocal.read(zip.getInputStream(zip.getEntry("manifest.json")),32768),sig=FilesLocal.read(zip.getInputStream(zip.getEntry("manifest.sig")),512);
                JSONObject root=parseManifest(manifest,sig);result.version=root.getInt("version");
                int floor=p.getInt("update_version",0);
                if(result.version<floor||(result.version==floor&&!p.getBoolean("legacy_restore_allowed",false)))throw new IOException("OLD_UPDATE");
                JSONObject files=root.getJSONObject("files");Iterator<String> it=files.keys();Set<String> declared=new HashSet<>(Arrays.asList("manifest.json","manifest.sig"));
                while(it.hasNext()){
                    String name=it.next();declared.add(name);JSONObject spec=files.getJSONObject(name);long size=spec.getLong("size");
                    ZipEntry entry=zip.getEntry(name);if(entry==null||entry.getSize()!=size)throw new IOException("FILE_SIZE_MISMATCH");
                    if(result.directory.getUsableSpace()<size+100000000L)throw new IOException("INSUFFICIENT_STORAGE");
                    File target=new File(result.directory,name);String sha=FilesLocal.copy(zip.getInputStream(entry),target,size);
                    if(target.length()!=size||!sha.equals(spec.getString("sha256")))throw new IOException("FILE_CHECKSUM_FAILED");
                    if(name.equals("model.gguf"))result.model=target;
                    if(name.equals("knowledge.json"))result.knowledge=target;
                    if(name.equals("additional-filter.json"))result.filter=target;
                }
                if(!names.equals(declared))throw new IOException("UNDECLARED_FILES");
                write(new File(result.directory,"manifest.json"),manifest);write(new File(result.directory,"manifest.sig"),sig);
            }
            verifyRetained(result);ContentGuard candidate=new ContentGuard();if(result.filter!=null)addFilters(candidate,result.filter);else if(filter()!=null)addFilters(candidate,filter());
            if(result.knowledge!=null)Knowledge.validate(result.knowledge,candidate);
            archive.delete();return result;
        }catch(Exception e){FilesLocal.remove(result.directory);throw e;}
    }
    private static void write(File f,byte[] b)throws IOException{try(FileOutputStream out=new FileOutputStream(f)){out.write(b);out.getFD().sync();}}
    static void addFilters(ContentGuard guard,File filter)throws Exception{
        JSONArray terms=new JSONObject(FilesLocal.text(filter,128000)).getJSONArray("terms");if(terms.length()>850)throw new IOException("TOO_MANY_FILTER_TERMS");for(int i=0;i<terms.length();i++)guard.add(terms.getString(i));
    }
    void commit(Candidate candidate)throws Exception{
        verifyRetained(candidate);
        if(candidate.model!=null)verifyModel(candidate.model);
        if(candidate.knowledge!=null)verifyComponent(candidate.knowledge,"knowledge.json",false);
        if(candidate.filter!=null)verifyComponent(candidate.filter,"additional-filter.json",false);
        SharedPreferences.Editor e=p.edit();if(candidate.model!=null)e.putString("model_path",candidate.model.getAbsolutePath());if(candidate.knowledge!=null)e.putString("knowledge_path",candidate.knowledge.getAbsolutePath());if(candidate.filter!=null)e.putString("filter_path",candidate.filter.getAbsolutePath());
        if(candidate.version>0)e.putInt("update_version",candidate.version).putBoolean("legacy_restore_allowed",false);
        if(!e.commit())throw new IOException("UPDATE_COMMIT_FAILED");cleanup();
    }
    private Candidate create()throws IOException{Candidate r=new Candidate();r.directory=new File(c.getNoBackupFilesDir(),"packs/"+UUID.randomUUID());if(!r.directory.mkdirs())throw new IOException("CREATE_PACK_FAILED");return r;}
    void cleanup(){
        File root=new File(c.getNoBackupFilesDir(),"packs");File[] dirs=root.listFiles();if(dirs==null)return;Set<String> active=new HashSet<>();
        for(String key:Arrays.asList("model_path","knowledge_path","filter_path","legacy_model_path","legacy_knowledge_path","legacy_filter_path"))active.add(p.getString(key,""));
        for(File dir:dirs){boolean used=false;for(String path:active)if(path.startsWith(dir.getAbsolutePath()+File.separator))used=true;if(!used){FilesLocal.remove(dir);continue;}
            File[] files=dir.listFiles();if(files!=null)for(File file:files)if(!active.contains(file.getAbsolutePath())&&!file.getName().equals("manifest.json")&&!file.getName().equals("manifest.sig"))FilesLocal.remove(file);
        }
    }
}
