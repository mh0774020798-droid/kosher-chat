package com.moked.kosherchat;

import java.math.*;

public final class Calculator {
    private final String s; private int at=0,depth=0;
    private Calculator(String s){this.s=s;}
    public static String answer(String input){
        String t=input.trim().replaceFirst("^(?:כמה זה|חשב)\\s+", "").replaceAll("[?？]$", "").trim();
        t=t.replaceAll("\\s+(?:ועוד|פלוס|plus)\\s+", "+")
            .replaceAll("\\s+(?:פחות|מינוס|minus)\\s+", "-")
            .replaceAll("\\s+(?:כפול|times)\\s+", "*")
            .replaceAll("\\s+(?:חלקי|divided by)\\s+", "/");
        if(t.length()>160 || !t.matches("[0-9.()+*/ ×÷−-]+") || !t.matches(".*[+*/×÷−-].*")) return null;
        try { Calculator p=new Calculator(t.replace('×','*').replace('÷','/').replace('−','-')); BigDecimal n=p.expression(); p.skip(); if(p.at!=p.s.length())return null; return "תוצאת החישוב: "+n.stripTrailingZeros().toPlainString(); }
        catch(Exception e){return "לא ניתן לחשב את הביטוי. בדקו מספרים, סוגריים וחלוקה באפס.";}
    }
    private void skip(){while(at<s.length()&&s.charAt(at)==' ')at++;}
    private boolean take(char c){skip();if(at<s.length()&&s.charAt(at)==c){at++;return true;}return false;}
    private BigDecimal expression(){BigDecimal n=term();while(true){if(take('+'))n=n.add(term());else if(take('-'))n=n.subtract(term());else return n;}}
    private BigDecimal term(){BigDecimal n=factor();while(true){if(take('*'))n=n.multiply(factor(),MathContext.DECIMAL64);else if(take('/'))n=n.divide(factor(),MathContext.DECIMAL64);else return n;}}
    private BigDecimal factor(){if(++depth>24)throw new IllegalArgumentException();try{if(take('+'))return factor();if(take('-'))return factor().negate();if(take('(')){BigDecimal n=expression();if(!take(')'))throw new IllegalArgumentException();return n;}skip();int start=at;while(at<s.length()&&"0123456789.".indexOf(s.charAt(at))>=0)at++;return new BigDecimal(s.substring(start,at),MathContext.DECIMAL64);}finally{depth--;}}
}
