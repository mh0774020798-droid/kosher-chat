package com.moked.kosherchat;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

final class Knowledge {
    private final List<JSONObject> entries=new ArrayList<>();
    String date="2026-10-06";
    Knowledge(Context c,File extra,ContentGuard guard)throws Exception{
        parse(new String(FilesLocal.read(c.getAssets().open("knowledge.json"),2*1024*1024),StandardCharsets.UTF_8),guard);
        if(extra!=null)parse(FilesLocal.text(extra,2*1024*1024),guard);
    }
    static void validate(File f,ContentGuard guard)throws Exception{validateJson(new JSONObject(FilesLocal.text(f,2*1024*1024)),guard);}
    private static void validateJson(JSONObject root,ContentGuard guard)throws Exception{
        String date=root.getString("updated_at");if(!date.matches("\\d{4}-\\d{2}-\\d{2}"))throw new IOException("INVALID_KNOWLEDGE_DATE");
        JSONArray a=root.getJSONArray("entries");if(a.length()>1000)throw new IOException("TOO_MANY_ENTRIES");
        for(int i=0;i<a.length();i++){
            JSONObject o=a.getJSONObject(i);String title=o.getString("title"),body=o.getString("body");
            if(title.length()>120||body.length()>2000||title.isEmpty()||body.isEmpty()||guard.blocked(title+" "+body))throw new IOException("INVALID_KNOWLEDGE_CONTENT");
            JSONArray tags=o.optJSONArray("tags");
            if(tags!=null){if(tags.length()>20)throw new IOException("INVALID_TAGS");for(int t=0;t<tags.length();t++)if(tags.getString(t).length()>60||guard.blocked(tags.getString(t)))throw new IOException("INVALID_TAG");}
            JSONArray questions=o.optJSONArray("questions");
            if(questions!=null){
                if(questions.length()>12)throw new IOException("INVALID_QUESTIONS");
                for(int q=0;q<questions.length();q++){String s=questions.getString(q);if(s.isEmpty()||s.length()>200||guard.blocked(s))throw new IOException("INVALID_QUESTION");}
            }
        }
    }
    private void parse(String text,ContentGuard guard)throws Exception{JSONObject root=new JSONObject(text);validateJson(root,guard);date=root.getString("updated_at");JSONArray a=root.getJSONArray("entries");for(int i=0;i<a.length();i++){JSONObject entry=a.getJSONObject(i);entry.put("_source_date",date);for(Iterator<JSONObject> previous=entries.iterator();previous.hasNext();)if(previous.next().optString("title").equals(entry.optString("title")))previous.remove();entries.add(0,entry);}}
    String retrieve(String input){
        Set<String> words=new HashSet<>();for(String word:ContentGuard.normalize(input).split("[^\\p{L}\\p{N}]+"))if(word.length()>=3&&!Arrays.asList("איך","אפשר","שלי","אתה","מהם","תודה","כתוב","למה").contains(word))words.add(word);
        JSONObject best=null;int bestScore=1;
        for(JSONObject entry:entries){String text=ContentGuard.normalize(entry.optString("title")+" "+entry.optString("tags")+" "+entry.optString("body"));int score=0;for(String word:words)if(text.contains(word))score++;if(score>bestScore){bestScore=score;best=entry;}}
        if(best==null)return "";String text=best.optString("title")+" ("+best.optString("_source_date",date)+"): "+best.optString("body");return text.substring(0,Math.min(700,text.length()));
    }
    String directAnswer(String input){
        String n=QuickReplies.key(input);
        for(JSONObject entry:entries){
            JSONArray questions=entry.optJSONArray("questions");
            if(questions==null)continue;
            for(int i=0;i<questions.length();i++)if(n.equals(QuickReplies.key(questions.optString(i))))return entry.optString("body");
        }
        return null;
    }
}
