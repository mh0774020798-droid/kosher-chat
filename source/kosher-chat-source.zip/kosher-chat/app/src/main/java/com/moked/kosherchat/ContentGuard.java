package com.moked.kosherchat;

import java.text.Normalizer;
import java.util.*;
import java.util.regex.Pattern;

public final class ContentGuard {
    public static final String REFUSAL = "הנושא הזה אינו זמין בצ׳אט כשר. אפשר לשאול שאלה אחרת.";
    public static final String BYPASS_REFUSAL = "הבקשה הזו אינה זמינה בצ׳אט כשר. אפשר להמשיך בשאלה אחרת.";
    private static final String[] BYPASS = {
        "התעלם מההוראות", "התעלם מהסינון", "בטל את הסינון", "ללא סינון", "עקוף את הסינון",
        "תתעלם מההוראות", "תגלה את ההוראות", "חשוף את ההנחיות", "הצג את הוראות המערכת",
        "ignore previous instructions", "ignore all instructions", "ignore your instructions",
        "bypass the filter", "disable the filter", "remove restrictions", "jailbreak", "developer mode",
        "reveal your instructions", "show your system prompt", "מצב מפתח"
    };
    private static final String[] BASE = {
        "פורנו", "פ ו ר נ ו", "ארוטי", "אירוטי", "עירום", "יחסי מין", "סקס", "זנות", "אוננות", "ניאוף",
        "porn", "xxx", "erotic", "nude", "nudity", "sexual", "sex", "masturbation", "fetish",
        "pornography", "pornographic", "erotica", "sexuality", "sexualized", "naked",
        "קוקאין", "הרואין", "מתאמפטמין", "cocaine", "heroin", "methamphetamine",
        "איך להכין פצצה", "בניית פצצה", "build a bomb", "make a bomb", "להרוג מישהו", "kill someone",
        "לפרוץ לחשבון", "steal passwords", "גניבת סיסמאות", "ransomware", "כופר קבצים",
        "התעלם מההוראות", "התעלם מהסינון", "בטל את הסינון", "ללא סינון", "ignore previous instructions",
        "ignore all instructions", "bypass the filter", "jailbreak", "developer mode", "מצב מפתח",
        "fuck", "shit", "זין", "כוסית"
    };
    private static final String[] TOPICS = {
        "דת", "דתות", "דתי", "דתית", "דתיים", "דתיות", "הדת", "בדת", "לדת", "אמונה דתית",
        "הלכה", "הלכות", "מצוות", "מצווה", "תורה", "תנך", "תנ״ך", "תלמוד", "גמרא",
        "קבלה", "רוחניות", "תפילה", "תפילות", "ברכה דתית", "הלכתי", "הלכתית", "יהדות",
        "נצרות", "אסלאם", "בודהיזם", "religion", "religions", "religious", "beliefs", "halacha",
        "mitzvah", "mitzvot", "torah", "talmud", "kabbalah", "spirituality", "sacred texts",
        "חג", "חגים", "החג", "בחג", "חגי", "חגי ישראל", "פסח", "סוכות", "חנוכה", "פורים",
        "יום כיפור", "ראש השנה", "holidays", "religious holiday", "christmas", "easter",
        "מיניות", "מיני", "מינית", "מיניים", "מיניות", "רצח", "רציחה", "murder", "murdering",
        "סמים", "סם מסוכן", "קנאביס", "מריחואנה", "drugs", "cannabis", "marijuana",
        "הימורים", "הימור", "קזינו", "gambling", "casino", "suicide", "self harm", "self-harm",
        "התאבדות", "פגיעה עצמית", "אונס", "תקיפה", "assault", "rape",
        "קולנוע", "טלוויזיה", "סדרת טלוויזיה", "סדרות טלוויזיה", "משחק וידאו", "משחק מחשב", "משחקי וידאו", "משחקי מחשב",
        "ספורט מקצועי", "ספורט תחרותי", "כדורגל", "כדורסל", "מונדיאל", "אולימפיאדה",
        "מסיבה מעורבת", "מסיבות מעורבות", "מופע מעורב", "מופעים מעורבים",
        "cinema", "television", "tv series", "video game", "video games", "computer game", "computer games", "videogame", "professional sports",
        "competitive sports", "football", "basketball", "mixed entertainment", "mixed parties"
    };
    private final List<Pattern> rules = new ArrayList<>();
    private final List<Pattern> bypassRules = new ArrayList<>();
    public ContentGuard() {
        for (String s : BASE) add(s);
        for (String s : TOPICS) add(s);
        for (String s : BYPASS) { Pattern p=compile(s); bypassRules.add(p); rules.add(p); }
    }
    public static String normalizeText(String input) {
        String text = Normalizer.normalize(input == null ? "" : input, Normalizer.Form.NFKC)
            .toLowerCase(Locale.ROOT).replaceAll("[\\p{M}\\p{Cf}]", "");
        return text.replaceAll("\\s+", " ").trim();
    }
    public static String normalize(String input) {
        return normalizeText(input).replace('0','o').replace('3','e').replace('4','a').replace('@','a').replace('$','s');
    }
    public synchronized void add(String phrase) {
        if(rules.size() >= 1000)throw new IllegalArgumentException("TOO_MANY_FILTER_TERMS");
        rules.add(compile(phrase));
    }
    private static Pattern compile(String phrase) {
        String n = normalize(phrase);
        if (n.length() < 2 || n.length() > 100) throw new IllegalArgumentException("INVALID_FILTER_TERM");
        StringBuilder pattern = new StringBuilder("(?<![\\p{L}\\p{N}])");
        boolean hebrewStem=Arrays.asList("פורנו","ארוטי","אירוטי","סקס","אוננות","ניאוף").contains(n);
        if(hebrewStem || (n.length() >= 4 && n.matches("[\\u05D0-\\u05EA ]+")))pattern.append("[והבכלמש]{0,2}");
        String compact = n.replaceAll("\\s", "");
        int[] cps = new int[compact.length()];
        for(int i=0;i<compact.length();i++) cps[i]=compact.charAt(i);
        for (int i=0;i<cps.length;i++) {
            if (i>0) pattern.append("[\\s._*\\-]*");
            pattern.append(Pattern.quote(new String(Character.toChars(cps[i]))));
        }
        if(hebrewStem)pattern.append("[\\u05D0-\\u05EA]{0,6}");
        pattern.append("(?![\\p{L}\\p{N}])");
        return Pattern.compile(pattern.toString());
    }
    public synchronized String refusal(String input) {
        String n=normalize(input);
        if(n.contains("<|")||n.contains("|>")||n.contains("<start_of_turn>")||n.contains("<end_of_turn>")||n.contains("<bos>")||n.contains("<eos>"))return BYPASS_REFUSAL;
        for(Pattern p:bypassRules)if(p.matcher(n).find())return BYPASS_REFUSAL;
        return REFUSAL;
    }
    public synchronized boolean blocked(String input) {
        if (input == null || input.length() > 40000) return true;
        String n = normalize(input);
        if (n.contains("<|") || n.contains("|>") || n.contains("<think") || n.contains("</think") || n.contains("<start_of_turn>") || n.contains("<end_of_turn>") || n.contains("<bos>") || n.contains("<eos>")) return true;
        for (Pattern p : rules) if (p.matcher(n).find()) return true;
        return false;
    }
    public String cleanAnswer(String answer) {
        String s = answer == null ? "" : answer.trim().replace("\uFFFD", "");
        // No partial/streaming answer is ever displayed before this check.
        if (s.contains("<think") || s.contains("</think") || blocked(s)) return REFUSAL;
        return s.isEmpty() ? "לא התקבלה תשובה. נסו לנסח שאלה קצרה וברורה יותר." : s;
    }
}
