package com.moked.kosherchat;

/** Context reservation for bounded local generation, including private reasoning. */
public final class GenerationBudget {
    private GenerationBudget() {}

    public static int reasoningTokens(int family, int answerTokens) {
        if (answerTokens < 1 || answerTokens > 512)
            throw new IllegalArgumentException("INVALID_GENERATION_LIMIT");
        return family == 32 ? (answerTokens <= 64 ? 256 : 512) : 0;
    }

    public static int reservedTokens(int family, int answerTokens) {
        return answerTokens + reasoningTokens(family, answerTokens);
    }
}
