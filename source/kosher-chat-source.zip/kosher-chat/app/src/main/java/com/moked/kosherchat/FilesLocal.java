package com.moked.kosherchat;

import java.io.*;
import java.security.*;
import java.nio.charset.StandardCharsets;

final class FilesLocal {
    static byte[] read(InputStream in,long maximum) throws IOException {
        try(InputStream source=in;ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] b=new byte[8192]; long total=0;int n;
            while((n=source.read(b))!=-1) {total+=n;if(total>maximum)throw new IOException("FILE_TOO_LARGE");out.write(b,0,n);}
            return out.toByteArray();
        }
    }
    static String text(File f,int maximum) throws IOException {return new String(read(new FileInputStream(f),maximum),StandardCharsets.UTF_8);}
    static String copy(InputStream in,File target,long maximum) throws Exception {
        MessageDigest md=MessageDigest.getInstance("SHA-256");long total=0;int n;byte[] b=new byte[65536];
        try(InputStream source=in;FileOutputStream out=new FileOutputStream(target)) {
            while((n=source.read(b))!=-1) {total+=n;if(total>maximum)throw new IOException("FILE_TOO_LARGE");md.update(b,0,n);out.write(b,0,n);}
            out.getFD().sync();
        } catch(Exception e) {target.delete();throw e;}
        return hex(md.digest());
    }
    static String hex(byte[] b){StringBuilder out=new StringBuilder();for(byte n:b)out.append(String.format(java.util.Locale.ROOT,"%02x",n&255));return out.toString();}
    static String digest(InputStream in,long expected)throws Exception {
        MessageDigest md=MessageDigest.getInstance("SHA-256");long total=0;int n;byte[] b=new byte[65536];
        try(InputStream source=in){while((n=source.read(b))!=-1){total+=n;if(total>expected)throw new IOException("FILE_SIZE_MISMATCH");md.update(b,0,n);}}
        if(total!=expected)throw new IOException("FILE_SIZE_MISMATCH");return hex(md.digest());
    }
    static void remove(File f){if(f==null)return;if(f.isDirectory()){File[] list=f.listFiles();if(list!=null)for(File c:list)remove(c);}f.delete();}
}
