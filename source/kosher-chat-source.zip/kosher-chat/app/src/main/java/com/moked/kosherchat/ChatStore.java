package com.moked.kosherchat;

import android.content.Context;
import android.util.AtomicFile;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

final class ChatStore {
    static final class Conversation {
        String id=UUID.randomUUID().toString(),title="שיחה חדשה";
        final List<PromptBuilder.Message> messages=new ArrayList<>();
    }
    private final AtomicFile file;
    final List<Conversation> conversations=new ArrayList<>();
    Conversation current;
    ChatStore(Context context) {
        file=new AtomicFile(new File(context.getNoBackupFilesDir(),"chats.json"));
        try {
            JSONArray a=new JSONArray(new String(FilesLocal.read(file.openRead(),2*1024*1024),StandardCharsets.UTF_8));
            for(int i=0;i<Math.min(a.length(),20);i++){
                JSONObject o=a.getJSONObject(i);Conversation c=new Conversation();c.id=o.getString("id");c.title=o.getString("title");
                JSONArray m=o.getJSONArray("messages");
                for(int j=Math.max(0,m.length()-60);j<m.length();j++){JSONObject item=m.getJSONObject(j);String role=item.getString("role"),text=item.getString("text");if((role.equals("user")||role.equals("assistant"))&&text.length()<10000)c.messages.add(new PromptBuilder.Message(role,text));}
                conversations.add(c);
            }
        }catch(Exception ignored){}
        if(conversations.isEmpty())newChat();else current=conversations.get(0);
    }
    void newChat(){current=new Conversation();conversations.add(0,current);while(conversations.size()>20)conversations.remove(conversations.size()-1);save();}
    void add(String role,String text){if(role.equals("user")&&current.messages.isEmpty())current.title=text.substring(0,Math.min(text.length(),35));current.messages.add(new PromptBuilder.Message(role,text));while(current.messages.size()>60)current.messages.remove(0);save();}
    void clear(){conversations.clear();newChat();}
    void save(){
        FileOutputStream output=null;
        try{JSONArray a=new JSONArray();for(Conversation c:conversations){JSONObject o=new JSONObject();o.put("id",c.id);o.put("title",c.title);JSONArray m=new JSONArray();for(PromptBuilder.Message x:c.messages){JSONObject q=new JSONObject();q.put("role",x.role);q.put("text",x.text);m.put(q);}o.put("messages",m);a.put(o);}byte[] data=a.toString().getBytes(StandardCharsets.UTF_8);if(data.length>2*1024*1024)throw new IOException("HISTORY_FULL");output=file.startWrite();output.write(data);file.finishWrite(output);}catch(Exception e){if(output!=null)file.failWrite(output);}
    }
}
