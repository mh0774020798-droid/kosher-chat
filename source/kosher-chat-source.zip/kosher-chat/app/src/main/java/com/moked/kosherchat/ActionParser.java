package com.moked.kosherchat;

import java.util.regex.*;

public final class ActionParser {
    public static final class Action {
        public final String kind, text;
        public final int value, second;
        public Action(String kind, int value, int second, String text) { this.kind=kind; this.value=value; this.second=second; this.text=text; }
        public String title() {
            switch(kind) {
                case "brightness": return "שינוי בהירות המסך ל־"+value+"%";
                case "volume": return "שינוי עוצמת המדיה ל־"+value+"%";
                case "timer": return "פתיחת טיימר ל־"+value+" דקות";
                case "alarm": return String.format(java.util.Locale.ROOT,"שעון מעורר לשעה %02d:%02d",value,second);
                case "note": return "שמירת פתק מקומי";
                default: return "פתיחת הגדרות המכשיר";
            }
        }
    }
    public static Action parse(String input) {
        String s = input.trim(); Matcher m;
        m=Pattern.compile("^(?:שנה|קבע|הגדר) (?:את )?(?:בהירות|בהירות המסך) ל[־-]?\\s*(\\d{1,3})\\s*%?$").matcher(s);
        if(m.matches()) return percent("brightness",m.group(1));
        m=Pattern.compile("^(?:שנה|קבע|הגדר) (?:את )?(?:עוצמת הקול|עוצמת המדיה|ווליום) ל[־-]?\\s*(\\d{1,3})\\s*%?$").matcher(s);
        if(m.matches()) return percent("volume",m.group(1));
        m=Pattern.compile("^(?:הפעל|פתח|הגדר|קבע) טיימר (?:ל[־-]?\\s*)?(\\d{1,3}) דקות$").matcher(s);
        if(m.matches()) { int n=Integer.parseInt(m.group(1)); return n>=1&&n<=180?new Action("timer",n,0,""):null; }
        m=Pattern.compile("^(?:הגדר|קבע|פתח) (?:שעון מעורר|התראה) (?:לשעה |ל[־-]?\\s*)?(\\d{1,2}):(\\d{2})$").matcher(s);
        if(m.matches()) { int h=Integer.parseInt(m.group(1)),n=Integer.parseInt(m.group(2)); return h<24&&n<60?new Action("alarm",h,n,""):null; }
        m=Pattern.compile("^(?:שמור|צור) פתק\\s*:\\s*(.{1,1500})$",Pattern.DOTALL).matcher(s);
        if(m.matches()) return new Action("note",0,0,m.group(1));
        if(s.equals("פתח הגדרות")||s.equals("פתח את הגדרות המכשיר")) return new Action("settings",0,0,"");
        return null;
    }
    private static Action percent(String kind,String s) { int n=Integer.parseInt(s); return n>=1&&n<=100?new Action(kind,n,0,""):null; }
}
