package com.moked.kosherchat;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import java.io.IOException;
import java.security.MessageDigest;

final class AppIntegrity {
    static final String OWNER_CERT="00394d3fcefe0c5e1976b88b9d9370bde518959e4cd0b50f61d68a4849c1582d";
    @SuppressWarnings("deprecation")
    static void verify(Context c)throws Exception{
        if(BuildConfig.DEBUG)return;
        if((c.getApplicationInfo().flags&ApplicationInfo.FLAG_DEBUGGABLE)!=0)throw new IOException("APP_SIGNATURE_FAILED");
        PackageInfo p=c.getPackageManager().getPackageInfo(c.getPackageName(),Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES);
        Signature[] signatures=Build.VERSION.SDK_INT>=28?(p.signingInfo==null?null:p.signingInfo.getApkContentsSigners()):p.signatures;
        if(signatures==null||signatures.length!=1||!OWNER_CERT.equals(FilesLocal.hex(MessageDigest.getInstance("SHA-256").digest(signatures[0].toByteArray()))))throw new IOException("APP_SIGNATURE_FAILED");
    }
}
