package com.moked.kosherchat;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public final class ChatApp extends Application {
    interface Listener {void changed();}
    final ExecutorService worker=Executors.newSingleThreadExecutor();
    final Handler main=new Handler(Looper.getMainLooper());
    SharedPreferences prefs;ChatStore store;UpdateManager updates;ContentGuard guard;Knowledge knowledge;
    volatile boolean busy=false,ready=false,cancelled=false,generating=false,integrityReady=false;
    volatile int modelFamily=3;
    volatile ModelSpec activeModelSpec;
    volatile String status="מכין את הצ׳אט המקומי…",notice="";
    private Listener listener;
    @Override public void onCreate(){super.onCreate();prefs=getSharedPreferences("settings",MODE_PRIVATE);if(!prefs.contains("eco")){ActivityManager.MemoryInfo info=new ActivityManager.MemoryInfo();((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(info);prefs.edit().putBoolean("eco",info.totalMem<3L*1024*1024*1024).apply();}store=new ChatStore(this);updates=new UpdateManager(this,prefs);guard=new ContentGuard();initialize();}
    void attach(Listener l){listener=l;changed();}
    void detach(Listener l){if(listener==l)listener=null;}
    void changed(){main.post(()->{if(listener!=null)listener.changed();});}
    int contextSize(){return prefs.getBoolean("eco",true)?1024:2048;}
    int outputSize(){return prefs.getBoolean("eco",true)?64:128;}
    int threadCount(){int n=prefs.getInt("threads",prefs.getBoolean("eco",true)?2:4);if(n!=1&&n!=2&&n!=4)n=2;return Math.max(1,Math.min(n,Runtime.getRuntime().availableProcessors()));}
    private void load(File f)throws Exception{
        AppIntegrity.verify(this);
        ModelSpec spec=updates.verifyModel(f);
        NativeEngine.close();
        ActivityManager.MemoryInfo info=new ActivityManager.MemoryInfo();((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(info);if(info.totalMem<1536L*1024*1024)throw new IOException("INSUFFICIENT_DEVICE_RAM");if(info.availMem<350L*1024*1024)throw new IOException("INSUFFICIENT_RAM");
        if(spec==ModelSpec.GEMMA4_FULL&&(!android.os.Process.is64Bit()||info.totalMem<3L*1024*1024*1024))throw new IOException("GEMMA4_FULL_RAM");
        NativeEngine.reset();int threads=threadCount();
        if(f.getAbsolutePath().equals(getApplicationInfo().sourceDir)){
            try(android.content.res.AssetFileDescriptor asset=getAssets().openFd("model.gguf")){
                NativeEngine.loadAsset(asset.getParcelFileDescriptor().getFd(),asset.getStartOffset(),contextSize(),threads);
            }
        }else NativeEngine.load(f.getAbsolutePath().getBytes(StandardCharsets.UTF_8),contextSize(),threads);
        modelFamily=NativeEngine.modelFamily();
        if(modelFamily!=spec.family){NativeEngine.close();throw new IOException("MODEL_FAMILY_MISMATCH");}
        activeModelSpec=spec;
    }
    String modelLabel(){return activeModelSpec!=null?activeModelSpec.label:"מודל מקומי";}
    void initialize(){if(busy)return;busy=true;ready=false;integrityReady=false;changed();worker.execute(()->{
        try{AppIntegrity.verify(this);updates.verifyInstalled();guard=new ContentGuard();if(updates.filter()!=null)UpdateManager.addFilters(guard,updates.filter());knowledge=new Knowledge(this,updates.knowledge(),guard);integrityReady=true;updates.cleanup();status="מכין מודל מקומי — ההפעלה הראשונה עשויה לקחת זמן…";changed();File f=updates.installBundled();if(f==null){status="יש לייבא מודל מקובץ כדי להפעיל AI";}else{status="טוען את המודל המקומי…";changed();load(f);ready=true;status="מודל מקומי מוכן · ללא אינטרנט";}}
        catch(Throwable e){notice=friendly(e);status="המודל אינו מוכן";}finally{busy=false;changed();}
    });}
    void send(String text){
        if(busy)return;
        if(!integrityReady){notice="בדיקת שלמות האפליקציה טרם הושלמה. יש לטעון מחדש.";changed();return;}
        if(!prefs.getBoolean("terms_accepted",false)){notice="יש לאשר את תנאי השימוש לפני הפעלת הצ׳אט.";changed();return;}
        if(guard.blocked(text)){notice=guard.refusal(text);changed();return;}
        String calc=Calculator.answer(text);if(calc!=null){store.add("user",text);store.add("assistant",calc);notice="חישוב מקומי";changed();return;}
        String quick=QuickReplies.answer(text,store.current.messages);
        if(quick==null&&knowledge!=null)quick=knowledge.directAnswer(text);
        if(quick!=null){store.add("user",text);store.add("assistant",guard.cleanAnswer(quick));notice="מענה מקומי";changed();return;}
        if(!ready){notice="כדי לקבל תשובת AI יש לייבא את קובץ המודל במסך ההגדרות.";changed();return;}
        store.add("user",text);busy=true;generating=true;cancelled=false;notice="";status="מנסח תשובה במכשיר…";
        List<PromptBuilder.Message> history=new ArrayList<>(store.current.messages);changed();
        worker.execute(()->{
            try{
                NativeEngine.reset();String reference=knowledge.retrieve(text);int skip=Math.max(0,history.size()-8);String prompt;
                while(true){prompt=PromptBuilder.build(history,reference,skip,modelFamily);int count=NativeEngine.countTokens(prompt.getBytes(StandardCharsets.UTF_8));if(count+GenerationBudget.reservedTokens(modelFamily,outputSize())+4<=contextSize())break;if(skip<history.size()-1){skip++;continue;}if(!reference.isEmpty()){reference="";continue;}throw new IOException("PROMPT_TOO_LONG");}
                if(cancelled)throw new IOException("CANCELLED");
                byte[] answer=NativeEngine.generate(prompt.getBytes(StandardCharsets.UTF_8),outputSize(),tokens->{if(!cancelled){status="מנסח תשובה במכשיר · "+tokens+" יחידות טקסט";changed();}});
                boolean truncated=NativeEngine.generationTruncated();
                String decoded=AnswerCompletion.decode(answer,truncated);
                String completed=AnswerCompletion.completePart(decoded,truncated);
                if(completed.isEmpty())throw new IOException("OUTPUT_LIMIT");
                String clean=guard.cleanAnswer(completed);
                if(truncated&&!clean.equals(ContentGuard.REFUSAL)&&!clean.equals(ContentGuard.BYPASS_REFUSAL))
                    clean+="\n\n[התשובה נעצרה במגבלת האורך. אפשר לבקש המשך או לעבור למצב רגיל.]";
                final String displayed=clean;
                main.post(()->{if(!cancelled)store.add("assistant",displayed);});
            }catch(Throwable e){if(!cancelled)notice=friendly(e);}
            finally{main.post(()->{if(cancelled)notice="יצירת התשובה נעצרה.";busy=false;generating=false;status="מודל מקומי מוכן · ללא אינטרנט";changed();});}
        });
    }
    void stop(){if(!generating)return;cancelled=true;NativeEngine.cancel();status="עוצר את יצירת התשובה…";changed();}
    void importFile(Uri uri,boolean pack){
        if(!integrityReady){notice="בדיקת שלמות האפליקציה טרם הושלמה.";changed();return;}
        if(busy)return;busy=true;status=pack?"בודק חתימה ומייבא עדכון מקומי…":"בודק ומייבא מודל מקומי…";notice="";changed();
        final boolean wasReady=ready;
        worker.execute(()->{UpdateManager.Candidate candidate=null;boolean changedModel=false;File previous=updates.model();
            try{AppIntegrity.verify(this);candidate=pack?updates.importPack(uri,guard):updates.importModel(uri);updates.verifyRetained(candidate);ContentGuard next=new ContentGuard();File filter=candidate.filter!=null?candidate.filter:updates.filter();if(filter!=null)UpdateManager.addFilters(next,filter);Knowledge nextKnowledge=new Knowledge(this,candidate.knowledge!=null?candidate.knowledge:updates.knowledge(),next);
                if(candidate.model!=null){ready=false;changedModel=true;load(candidate.model);}
                updates.commit(candidate);guard=next;knowledge=nextKnowledge;ready=changedModel||wasReady;notice="הקובץ נבדק והעדכון הותקן בהצלחה.";
            }catch(Throwable e){if(candidate!=null)FilesLocal.remove(candidate.directory);notice=friendly(e);if(changedModel&&previous!=null){try{load(previous);ready=true;}catch(Throwable ignored){ready=false;}}}
            finally{busy=false;status=ready?"מודל מקומי מוכן · ללא אינטרנט":"יש לייבא מודל מקומי";changed();}
        });
    }
    String friendly(Throwable e){String s=e.getMessage()==null?"":e.getMessage();if(s.contains("CANCELLED"))return "יצירת התשובה נעצרה.";if(s.contains("OUTPUT_LIMIT"))return "המודל לא השלים משפט בתוך מגבלת האורך. נסו בקשה קצרה יותר או עברו למצב רגיל.";if(s.contains("INVALID_OUTPUT_UTF8"))return "המודל החזיר טקסט לא תקין. נסו לנסח שוב את הבקשה.";if(s.contains("THINKING_"))return "המודל לא השלים תשובה בתוך מגבלת החישוב. נסו שאלה קצרה יותר או עברו למצב רגיל.";if(s.contains("PROMPT_TOO_LONG"))return "השאלה ארוכה מדי למצב הנוכחי. קצרו אותה או עברו למצב רגיל.";if(s.contains("INSUFFICIENT_DEVICE_RAM"))return "המכשיר כולל מעט מדי זיכרון להפעלת המודל המלא. ניתן להשתמש במחשבון ובפעולות המקומיות; להפעלת AI מומלץ מכשיר עם לפחות 2 GB RAM.";if(s.contains("INSUFFICIENT_RAM"))return "אין כרגע מספיק זיכרון פנוי. סגרו יישומים אחרים ונסו שוב במצב חסכוני.";if(s.contains("INSUFFICIENT_STORAGE"))return "אין מספיק מקום פנוי לייבוא. פנו מקום ונסו שוב.";if(s.contains("UNKNOWN_MODEL"))return "המודל אינו הקובץ המאומת של הגרסה הזו. יש לבחור את model.gguf שסופק עם האפליקציה; מודל חדש דורש חבילת עדכון חתומה.";if(s.contains("APP_SIGNATURE"))return "האפליקציה אינה חתומה בתעודת הפיתוח המאומתת. יש להתקין את הגרסה המקורית.";if(s.contains("CHECKSUM")||s.contains("PRIVATE_PATH"))return "בדיקת שלמות הקבצים נכשלה. יש להתקין מחדש גרסה חתומה או לייבא שוב את העדכון המקורי.";if(s.contains("GEMMA4_FULL_RAM"))return "המודל המלא של Gemma 4 דורש מכשיר 64 סיביות עם לפחות 3 GB RAM.";if(s.contains("SIGNATURE"))return "חתימת חבילת העדכון אינה תקינה. העדכון לא הותקן.";if(s.contains("OLD_UPDATE"))return "חבילת העדכון הזו כבר מותקנת או ישנה מהגרסה הנוכחית.";if(s.contains("MODEL")||s.contains("CONTEXT")||e instanceof OutOfMemoryError)return "לא ניתן לטעון את המודל במכשיר כרגע. נסו מצב חסכוני, פינוי זיכרון או ייבוא מחדש.";return "הפעולה לא הושלמה. בדקו שהקובץ תקין ותואם לאפליקציה ונסו שוב.";}
}
