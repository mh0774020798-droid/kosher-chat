package com.moked.kosherchat;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.AudioManager;
import android.net.Uri;
import android.os.*;
import android.provider.*;
import android.text.InputFilter;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class MainActivity extends Activity implements ChatApp.Listener {
    private ChatApp app;
    private LinearLayout root,body,nav,chatList;
    private TextView state,notice,thinking;
    private EditText composer;
    private ScrollView chatScroll;
    private View send;
    private int page=0,bg,surface,ink,muted,stroke,accent;
    private boolean dark,lastBusy,lastReady;
    private int lastCount=-1;
    private String lastId="",exportText="",chatDraft="";
    private ActionParser.Action pendingBrightness;
    private static final java.util.regex.Pattern NUMBERS=java.util.regex.Pattern.compile("[-+]?\\d+(?:[.,]\\d+)?(?:\\s*[+*/\\-]\\s*[-+]?\\d+(?:[.,]\\d+)?)*");
    private static final int PICK_MODEL=101,PICK_PACK=102,EXPORT=103;
    @Override public void onCreate(Bundle bundle){super.onCreate(bundle);app=(ChatApp)getApplication();page=bundle==null?0:bundle.getInt("page",0);chatDraft=bundle==null?"":bundle.getString("draft","");build();app.attach(this);if(!app.prefs.getBoolean("terms_accepted",false))terms();}
    @Override public void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putInt("page",page);b.putString("draft",composer==null?chatDraft:composer.getText().toString());}
    @Override protected void onDestroy(){app.detach(this);super.onDestroy();}
    @Override protected void onStop(){if(app.generating)app.stop();super.onStop();}
    @Override protected void onResume(){super.onResume();if(pendingBrightness!=null&&Settings.System.canWrite(this)){ActionParser.Action a=pendingBrightness;pendingBrightness=null;perform(a);}else if(pendingBrightness!=null){pendingBrightness=null;app.notice="ההרשאה לא ניתנה. בהירות המסך לא שונתה.";app.changed();}}
    int d(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private void palette(){dark=app.prefs.getBoolean("dark",false);setTheme(dark?android.R.style.Theme_Material_NoActionBar:R.style.AppTheme);bg=Color.parseColor(dark?"#0B1726":"#F5F7FB");surface=Color.parseColor(dark?"#142438":"#FFFFFF");ink=Color.parseColor(dark?"#EEF4FA":"#142B44");muted=Color.parseColor(dark?"#A2B2C5":"#68788A");stroke=Color.parseColor(dark?"#263C53":"#E1E7EF");accent=Color.parseColor(dark?"#55DEC1":"#008775");}
    private void build(){
        palette();getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(surface);
        getWindow().getDecorView().setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);setContentView(root);
        if(Build.VERSION.SDK_INT>=35)root.setOnApplyWindowInsetsListener((view,insets)->{android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());int bottom=Math.max(bars.bottom,insets.getInsets(WindowInsets.Type.ime()).bottom);view.setPadding(bars.left,bars.top,bars.right,bottom);return insets;});
        LinearLayout header=row();header.setPadding(d(20),d(14),d(20),d(14));header.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout logo=new FrameLayout(this);logo.setBackground(round(dark?Color.parseColor("#163A45"):Color.parseColor("#E5F7F0"),14));IconView shield=new IconView(this,"shield",accent);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(d(26),d(26),Gravity.CENTER);logo.addView(shield,lp);header.addView(logo,new LinearLayout.LayoutParams(d(48),d(48)));
        LinearLayout label=column();label.setPadding(d(12),0,d(6),0);label.addView(text("צ׳אט כשר",23,ink,true));state=text("הכול נשאר במכשיר שלך",11,muted,false);state.setMaxLines(2);label.addView(state);header.addView(label,new LinearLayout.LayoutParams(0,-2,1));
        header.addView(iconButton("history","היסטוריית שיחות",()->history()),new LinearLayout.LayoutParams(d(42),d(42)));
        header.addView(iconButton("plus","שיחה חדשה",()->{if(app.busy){toast("אפשר לפתוח שיחה חדשה אחרי סיום הפעולה.");return;}app.store.newChat();app.notice="";select(0);}),new LinearLayout.LayoutParams(d(42),d(42)));
        root.addView(header);
        body=column();root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();nav.setBackgroundColor(surface);nav.setPadding(d(12),d(8),d(12),d(8));root.addView(nav);
        renderPage();
    }
    private void select(int p){page=p;renderPage();}
    private void renderPage(){if(composer!=null)chatDraft=composer.getText().toString();body.removeAllViews();composer=null;notice=null;thinking=null;lastCount=-1;lastId="";lastBusy=app.busy;lastReady=app.ready;renderNav();if(page==0)renderChat();else if(page==1)renderDevice();else renderSettings();changed();}
    private void renderNav(){nav.removeAllViews();String[] names={"צ׳אט","פעולות","הגדרות"},icons={"chat","tools","settings"};for(int i=0;i<3;i++){final int at=i;LinearLayout item=column();item.setGravity(Gravity.CENTER);item.setPadding(d(4),d(5),d(4),d(5));if(page==i)item.setBackground(round(dark?Color.parseColor("#204139"):Color.parseColor("#E7F5EF"),14));int color=page==i?accent:muted;item.addView(new IconView(this,icons[i],color),new LinearLayout.LayoutParams(d(23),d(23)));TextView name=text(names[i],12,color,page==i);name.setGravity(Gravity.CENTER);item.addView(name);item.setContentDescription(names[i]);item.setOnClickListener(v->select(at));nav.addView(item,new LinearLayout.LayoutParams(0,d(60),1));}}
    private void renderChat(){
        String draft=composer==null?chatDraft:composer.getText().toString();body.removeAllViews();chatScroll=new ScrollView(this);chatScroll.setFillViewport(true);chatScroll.setClipToPadding(false);chatList=column();chatList.setPadding(d(20),d(8),d(20),d(12));chatScroll.addView(chatList);body.addView(chatScroll,new LinearLayout.LayoutParams(-1,0,1));
        if(app.store.current.messages.isEmpty())welcome();else for(PromptBuilder.Message message:app.store.current.messages)bubble(message);
        thinking=text(app.generating?app.status:"",12,accent,false);thinking.setPadding(d(20),d(6),d(20),d(6));thinking.setVisibility(app.generating?View.VISIBLE:View.GONE);body.addView(thinking);
        notice=text(app.notice,12,muted,false);notice.setPadding(d(20),d(8),d(20),d(8));notice.setVisibility(app.notice.isEmpty()?View.GONE:View.VISIBLE);body.addView(notice);
        if(!app.ready&&!app.busy){TextView importButton=button(BuildConfig.FLAVOR.equals("full")?"בדיקת מצב המודל":"ייבוא מודל מקומי",false,()->select(2));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,d(44));p.setMargins(d(20),0,d(20),d(8));body.addView(importButton,p);}
        LinearLayout input=row();input.setPadding(d(10),d(8),d(10),d(8));input.setGravity(Gravity.CENTER_VERTICAL);input.setBackground(round(surface,20));
        composer=new EditText(this);composer.setTextColor(ink);composer.setHintTextColor(muted);composer.setHint("מה תרצה לשאול?");composer.setTextSize(15);composer.setBackgroundColor(Color.TRANSPARENT);composer.setPadding(d(10),d(8),d(10),d(8));composer.setMaxLines(4);composer.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);composer.setFilters(new InputFilter[]{new InputFilter.LengthFilter(1200)});composer.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_LTR);composer.setText(draft);composer.setSelection(draft.length());input.addView(composer,new LinearLayout.LayoutParams(0,-2,1));
        send=iconButton(app.generating?"stop":"send",app.generating?"עצירת תשובה":"שליחת הודעה",()->{if(app.generating){app.stop();return;}submit();});send.setBackground(round(Color.parseColor("#12354F"),14));if(send instanceof IconView)((IconView)send).tint=Color.WHITE;send.setEnabled(!app.busy||app.generating);input.addView(send,new LinearLayout.LayoutParams(d(44),d(44)));
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.setMargins(d(16),d(6),d(16),d(6));body.addView(input,ip);
        TextView foot=text("AI מקומי · סינון לפני הצגת תשובה",10,muted,false);foot.setGravity(Gravity.CENTER);foot.setPadding(0,d(2),0,d(8));body.addView(foot);
        lastCount=app.store.current.messages.size();lastId=app.store.current.id;lastBusy=app.busy;lastReady=app.ready;
        if(lastCount>0)chatScroll.post(()->chatScroll.fullScroll(View.FOCUS_DOWN));
    }
    private void welcome(){
        LinearLayout hero=column();hero.setPadding(d(24),d(26),d(24),d(26));hero.setBackground(new GradientDrawable(GradientDrawable.Orientation.TR_BL,new int[]{Color.parseColor("#173E58"),Color.parseColor("#10263F")}));((GradientDrawable)hero.getBackground()).setCornerRadius(d(24));
        TextView badge=text("פרטי. מקומי. מסונן.",12,Color.parseColor("#8BE8D2"),true);hero.addView(badge);TextView title=text("שלום, במה\nאפשר לעזור?",30,Color.WHITE,true);title.setPadding(0,d(12),0,d(12));hero.addView(title);TextView desc=text("לשאול, להבין, לכתוב ולבצע פעולות —\nישירות במכשיר שלך.",14,Color.parseColor("#C8D9E7"),false);desc.setLineSpacing(d(4),1);hero.addView(desc);chatList.addView(hero);
        TextView title2=text("אפשר להתחיל מכאן",14,ink,true);title2.setPadding(0,d(24),0,d(12));chatList.addView(title2);
        suggestion("chat","תסביר לי בפשטות","הסבר לי בפשטות איך פועל מחשב");
        suggestion("file","עזרה בניסוח הודעה","נסח הודעת תודה קצרה ומכובדת");
        suggestion("timer","להפעיל טיימר","הפעל טיימר ל10 דקות");
        suggestion("sun","לשנות את הבהירות","שנה בהירות המסך ל50%");
        TextView privacy=text("ללא חשבון וללא חיבור לרשת. התשובות נוצרות במודל קטן ועלולות להיות שגויות.",12,muted,false);privacy.setPadding(d(4),d(16),d(4),d(8));chatList.addView(privacy);
    }
    private void suggestion(String icon,String label,String prompt){LinearLayout card=row();card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(d(16),d(15),d(16),d(15));card.setBackground(outline(surface,16));card.addView(new IconView(this,icon,accent),new LinearLayout.LayoutParams(d(22),d(22)));TextView t=text(label,14,ink,false);t.setPadding(d(12),0,0,0);card.addView(t,new LinearLayout.LayoutParams(0,-2,1));card.setOnClickListener(v->{if(composer!=null){composer.setText(prompt);composer.setSelection(prompt.length());composer.requestFocus();}});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=d(10);chatList.addView(card,p);}
    private void bubble(PromptBuilder.Message m){
        boolean user=m.role.equals("user");LinearLayout wrap=column();wrap.setPadding(d(16),d(14),d(16),d(12));wrap.setBackground(outline(user?(dark?Color.parseColor("#163F3A"):Color.parseColor("#E3F3EB")):surface,18));TextView who=text(user?"אתה":"צ׳אט כשר",11,user?accent:muted,true);wrap.addView(who);TextView message=text(displayNumbers(m.text),16,ink,false);message.setPadding(0,d(7),0,d(5));message.setLineSpacing(d(4),1);message.setTextIsSelectable(true);wrap.addView(message);
        TextView copy=text("העתק",11,muted,false);copy.setGravity(Gravity.END);copy.setPadding(0,d(6),0,d(4));copy.setOnClickListener(v->{((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("צ׳אט כשר",m.text));toast("הטקסט הועתק");});wrap.addView(copy);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(user?d(18):0,d(5),user?0:d(18),d(10));chatList.addView(wrap,lp);
    }
    private void submit(){if(app.busy||composer==null)return;String input=composer.getText().toString().trim();if(input.isEmpty())return;if(app.guard.blocked(input)){app.notice=app.guard.refusal(input);changed();return;}composer.setText("");((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(composer.getWindowToken(),0);ActionParser.Action action=ActionParser.parse(input);if(action!=null){confirm(action);return;}app.send(input);}
    private ScrollView scrolling(){ScrollView s=new ScrollView(this);s.setFillViewport(true);body.addView(s,new LinearLayout.LayoutParams(-1,-1));return s;}
    private LinearLayout content(ScrollView s){LinearLayout c=column();c.setPadding(d(20),d(6),d(20),d(24));s.addView(c);return c;}
    private void renderDevice(){LinearLayout c=content(scrolling());sectionTitle(c,"פעולות במכשיר","בחר פעולה, בדוק את הפרטים ואשר ביצוע.");
        tile(c,"sun","בהירות המסך","שינוי בהירות המערכת באישור שלך",()->percentDialog("brightness"));
        tile(c,"sound","עוצמת מדיה","שינוי העוצמה של מוזיקה ויישומי מדיה",()->percentDialog("volume"));
        tile(c,"timer","טיימר","פתיחת טיימר באפליקציית השעון",()->timerDialog());
        tile(c,"history","שעון מעורר","בחירת שעה ופתיחה באפליקציית השעון",()->new TimePickerDialog(this,(view,h,m)->confirm(new ActionParser.Action("alarm",h,m,"")),7,0,true).show());
        tile(c,"file","פתק חדש","שמירת טקסט בתוך צ׳אט כשר",()->noteDialog());
        tile(c,"settings","הגדרות המכשיר","פתיחת מסך ההגדרות של Android",()->confirm(new ActionParser.Action("settings",0,0,"")));
        tile(c,"file","הפתקים שלי","צפייה בפתקים שנשמרו מקומית",()->showNotes());
        TextView hint=text("אפשר לבקש גם בצ׳אט: „שנה בהירות המסך ל50%” או „הפעל טיימר ל10 דקות”.",12,muted,false);hint.setPadding(d(4),d(12),d(4),d(12));c.addView(hint);
    }
    private void renderSettings(){LinearLayout c=content(scrolling());sectionTitle(c,"ההגדרות שלך","שליטה במודל, בביצועים ובעדכונים.");
        LinearLayout model=column();model.setPadding(d(18),d(18),d(18),d(18));model.setBackground(outline(surface,20));model.addView(text(app.modelLabel(),16,ink,true));TextView detail=text(app.ready?"המודל נטען ופועל במכשיר":"המודל אינו טעון כרגע",13,app.ready?accent:muted,false);detail.setPadding(0,d(8),0,d(12));model.addView(detail);if(BuildConfig.FLAVOR.equals("full")){model.addView(text("המודל כלול בקובץ ההתקנה. להחלפתו בלי עותק נוסף באחסון, מתקינים APK מלא חדש.",12,muted,false));model.addView(button("טעינה מחדש",true,()->app.initialize()));}else model.addView(button("ייבוא model.gguf מהמכשיר",true,()->pick(PICK_MODEL)));c.addView(model);
        subheading(c,"ביצועים ותצוגה");
        toggle(c,"מצב חסכוני","הקשר קצר ותשובות קצרות יותר", "eco",()->{app.notice="המודל נטען מחדש לפי הגדרת הביצועים.";app.initialize();});
        tile(c,"settings","עוצמת חישוב","בחירת 1, 2 או 4 תהליכי חישוב",()->{
            if(app.busy){toast("אפשר לשנות אחרי סיום הפעולה.");return;}
            int[] counts={1,2,4};String[] labels={"1 — חיסכון", "2 — מאוזן", "4 — יותר מקביליות"};
            int chosen=app.prefs.getInt("threads",app.prefs.getBoolean("eco",true)?2:4);int index=chosen==1?0:chosen==4?2:1;
            new AlertDialog.Builder(this).setTitle("עוצמת חישוב").setSingleChoiceItems(labels,index,(dialog,which)->{
                if(app.busy){toast("אפשר לשנות אחרי סיום הפעולה.");return;}
                app.prefs.edit().putInt("threads",counts[which]).apply();dialog.dismiss();app.initialize();
            }).setNegativeButton("ביטול",null).show();
        });
        toggle(c,"תצוגה כהה","גוונים כהים לקריאה נוחה", "dark",()->build());
        toggle(c,"פעולות במכשיר","כל פעולה עדיין דורשת אישור", "actions",()->{});
        subheading(c,"עדכונים מקומיים");
        tile(c,"update","ייבוא חבילת עדכון","קובץ kchat חתום לידע, לסינון או למודל",()->pick(PICK_PACK));
        TextView updateInfo=text("גרסת אפליקציה: "+BuildConfig.VERSION_NAME+"\nגרסת עדכון: "+app.prefs.getInt("update_version",0)+"\nתאריך חבילת הידע: "+(app.knowledge==null?"—":app.knowledge.date)+"\nאין עדכון אוטומטי ללא העברת קובץ למכשיר.",12,muted,false);updateInfo.setLineSpacing(d(4),1);updateInfo.setPadding(d(4),d(8),d(4),d(12));c.addView(updateInfo);
        subheading(c,"נתונים מקומיים");
        tile(c,"file","ייצוא השיחה הנוכחית","שמירה כקובץ טקסט במיקום שתבחר",()->export());
        tile(c,"history","מחיקת היסטוריית השיחות","מחיקת כל השיחות שנשמרו באפליקציה",()->{if(app.busy){toast("יש להמתין לסיום הפעולה.");return;}new AlertDialog.Builder(this).setTitle("למחוק את כל השיחות?").setMessage("השיחות יימחקו מהמכשיר ולא ניתן יהיה לשחזר אותן.").setNegativeButton("ביטול",null).setPositiveButton("מחק",(a,b)->{app.store.clear();app.notice="היסטוריית השיחות נמחקה.";select(0);}).show();});
        subheading(c,"אודות צ׳אט כשר");
        TextView about=text("פותח עבור מוקד המערכות · מתמחים טופ\n\nהסינון הוא שכבת תוכנה ניסיונית, ואינו אישור כשרות או הבטחה לחסימה מלאה. המודל הקטן עלול לטעות, במיוחד בעברית ובשאלות מורכבות.",13,muted,false);about.setLineSpacing(d(4),1);c.addView(about);
        tile(c,"chat","מוקד המערכות במתמחים טופ","פתיחת הפרופיל באמצעות דפדפן חיצוני",()->external("https://mitmachim.top/user/%D7%9E%D7%95%D7%A7%D7%93-%D7%94%D7%9E%D7%A2%D7%A8%D7%9B%D7%95%D7%AA"));
        tile(c,"info","MH0774020798@GMAIL.COM","פתיחת כתובת המייל ביישום חיצוני",()->external("mailto:MH0774020798@GMAIL.COM"));
        tile(c,"file","תנאי שימוש ורישיונות","Gemma, מדיניות שימוש ורכיבי קוד פתוח",()->showLicenses(false));
        ActivityManager.MemoryInfo memory=new ActivityManager.MemoryInfo();((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(memory);TextView device=text("Android "+Build.VERSION.RELEASE+" · "+Build.MODEL+"\nזיכרון מכשיר: "+String.format(Locale.ROOT,"%.1f",memory.totalMem/1073741824.0)+" GB\nאין לאפליקציה הרשאת אינטרנט.",11,muted,false);device.setPadding(0,d(16),0,0);c.addView(device);
    }
    private void toggle(LinearLayout c,String title,String description,String key,Runnable after){LinearLayout line=row();line.setGravity(Gravity.CENTER_VERTICAL);line.setPadding(d(14),d(14),d(14),d(14));line.setBackground(outline(surface,16));LinearLayout texts=column();texts.addView(text(title,14,ink,true));texts.addView(text(description,11,muted,false));line.addView(texts,new LinearLayout.LayoutParams(0,-2,1));Switch sw=new Switch(this);sw.setChecked(app.prefs.getBoolean(key,key.equals("actions")));sw.setContentDescription(title);final boolean[] reverting={false};sw.setOnCheckedChangeListener((v,value)->{if(reverting[0])return;if(app.busy&&key.equals("eco")){reverting[0]=true;sw.setChecked(!value);reverting[0]=false;toast("אפשר לשנות מצב אחרי סיום הפעולה.");return;}app.prefs.edit().putBoolean(key,value).apply();after.run();});line.addView(sw);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=d(8);c.addView(line,p);}
    private void sectionTitle(LinearLayout c,String title,String description){c.addView(text(title,26,ink,true));TextView subtitle=text(description,13,muted,false);subtitle.setPadding(0,d(8),0,d(20));c.addView(subtitle);}
    private void subheading(LinearLayout c,String text){TextView t=text(text,14,ink,true);t.setPadding(0,d(24),0,d(12));c.addView(t);}
    private void tile(LinearLayout c,String icon,String title,String description,Runnable run){LinearLayout tile=row();tile.setGravity(Gravity.CENTER_VERTICAL);tile.setPadding(d(16),d(18),d(16),d(18));tile.setBackground(outline(surface,18));tile.addView(new IconView(this,icon,accent),new LinearLayout.LayoutParams(d(26),d(26)));LinearLayout labels=column();labels.setPadding(d(14),0,0,0);labels.addView(text(title,15,ink,true));TextView detail=text(description,12,muted,false);detail.setPadding(0,d(5),0,0);labels.addView(detail);tile.addView(labels,new LinearLayout.LayoutParams(0,-2,1));tile.setOnClickListener(v->run.run());LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=d(10);c.addView(tile,lp);}
    private void pick(int request){if(app.busy){toast("יש להמתין לסיום הפעולה.");return;}Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");try{startActivityForResult(i,request);}catch(ActivityNotFoundException e){toast("לא נמצא בורר קבצים במכשיר.");}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();if(request==PICK_MODEL||request==PICK_PACK){app.importFile(uri,request==PICK_PACK);changed();}else if(request==EXPORT){String value=exportText;app.worker.execute(()->{try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){out.write(value.getBytes(StandardCharsets.UTF_8));app.notice="השיחה יוצאה לקובץ.";}catch(Exception e){app.notice="לא ניתן לשמור את הקובץ שנבחר.";}app.changed();});}}
    private void history(){if(app.busy){toast("אפשר להחליף שיחה אחרי סיום הפעולה.");return;}String[] names=new String[app.store.conversations.size()];for(int i=0;i<names.length;i++)names[i]=app.store.conversations.get(i).title;new AlertDialog.Builder(this).setTitle("השיחות שלך").setItems(names,(dialog,index)->{app.store.current=app.store.conversations.get(index);app.notice="";select(0);}).setNegativeButton("סגור",null).show();}
    private void export(){StringBuilder b=new StringBuilder("צ׳אט כשר — מוקד המערכות\n\n");for(PromptBuilder.Message m:app.store.current.messages)b.append(m.role.equals("user")?"אתה":"צ׳אט כשר").append(":\n").append(m.text).append("\n\n");exportText=b.toString();try{startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("text/plain").putExtra(Intent.EXTRA_TITLE,"kosher-chat.txt"),EXPORT);}catch(ActivityNotFoundException e){toast("לא נמצא בורר קבצים במכשיר.");}}
    private void percentDialog(String type){LinearLayout c=column();c.setPadding(d(24),d(12),d(24),0);TextView value=text(getString(R.string.percent_value,50),22,ink,true);value.setGravity(Gravity.CENTER);SeekBar seek=new SeekBar(this);seek.setMax(99);seek.setProgress(49);seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar bar,int n,boolean user){value.setText(getString(R.string.percent_value,n+1));}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});c.addView(value);c.addView(seek);new AlertDialog.Builder(this).setTitle(type.equals("brightness")?"בהירות המסך":"עוצמת מדיה").setView(c).setNegativeButton("ביטול",null).setPositiveButton("המשך",(a,b)->confirm(new ActionParser.Action(type,seek.getProgress()+1,0,""))).show();}
    private void timerDialog(){EditText e=dialogInput("מספר דקות (1–180)","10",true);new AlertDialog.Builder(this).setTitle("טיימר").setView(e).setNegativeButton("ביטול",null).setPositiveButton("המשך",(a,b)->{try{int n=Integer.parseInt(e.getText().toString());if(n<1||n>180)throw new IllegalArgumentException();confirm(new ActionParser.Action("timer",n,0,""));}catch(Exception x){toast("בחר מספר דקות בין 1 ל־180.");}}).show();}
    private void noteDialog(){EditText e=dialogInput("תוכן הפתק","",false);e.setMinLines(3);e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(1500)});new AlertDialog.Builder(this).setTitle("פתק חדש").setView(e).setNegativeButton("ביטול",null).setPositiveButton("המשך",(a,b)->{String s=e.getText().toString().trim();if(!s.isEmpty())confirm(new ActionParser.Action("note",0,0,s));}).show();}
    private EditText dialogInput(String hint,String value,boolean number){EditText e=new EditText(this);e.setTextDirection(View.TEXT_DIRECTION_RTL);e.setPadding(d(24),d(14),d(24),d(14));e.setHint(hint);e.setText(value);e.setInputType(number?android.text.InputType.TYPE_CLASS_NUMBER:android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);return e;}
    private void confirm(ActionParser.Action a){if(!app.integrityReady){toast("בדיקת שלמות האפליקציה טרם הושלמה.");return;}if(!app.prefs.getBoolean("actions",true)){toast("פעולות במכשיר כבויות. ניתן להפעיל אותן בהגדרות.");return;}if(app.guard.blocked(a.text)){app.notice=ContentGuard.REFUSAL;app.changed();return;}String detail=a.kind.equals("note")?a.text:(a.kind.equals("brightness")?"השינוי חל על בהירות המערכת. בפעם הראשונה Android יבקש הרשאת שינוי הגדרות.":a.kind.equals("timer")||a.kind.equals("alarm")?"אפליקציית השעון תיפתח עם הפרטים שנבחרו. ניתן לבדוק אותם לפני שמירה.":"הפעולה תתבצע במכשיר לאחר האישור.");new AlertDialog.Builder(this).setTitle(a.title()).setMessage(detail).setNegativeButton("ביטול",null).setPositiveButton("אישור ביצוע",(dialog,which)->perform(a)).show();}
    private void perform(ActionParser.Action a){
        if(!app.integrityReady){toast("בדיקת שלמות האפליקציה טרם הושלמה.");return;}
        try{switch(a.kind){
            case "brightness":if(!Settings.System.canWrite(this)){pendingBrightness=a;startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,Uri.parse("package:"+getPackageName())));return;}Settings.System.putInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS_MODE,Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);if(!Settings.System.putInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS,Math.max(3,255*a.value/100)))throw new SecurityException();break;
            case "volume":AudioManager audio=(AudioManager)getSystemService(AUDIO_SERVICE);audio.setStreamVolume(AudioManager.STREAM_MUSIC,Math.round(audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)*a.value/100f),AudioManager.FLAG_SHOW_UI);break;
            case "timer":startActivity(new Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH,a.value*60).putExtra(AlarmClock.EXTRA_MESSAGE,"צ׳אט כשר").putExtra(AlarmClock.EXTRA_SKIP_UI,false));app.notice="נפתחה אפליקציית השעון לבדיקת הטיימר.";app.changed();return;
            case "alarm":startActivity(new Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR,a.value).putExtra(AlarmClock.EXTRA_MINUTES,a.second).putExtra(AlarmClock.EXTRA_MESSAGE,"צ׳אט כשר").putExtra(AlarmClock.EXTRA_SKIP_UI,false));app.notice="נפתחה אפליקציית השעון לבדיקת ההתראה.";app.changed();return;
            case "note":JSONArray notes=new JSONArray(app.prefs.getString("notes","[]"));if(notes.length()>=100){toast("ניתן לשמור עד 100 פתקים.");return;}notes.put(new JSONObject().put("text",a.text).put("at",System.currentTimeMillis()));app.prefs.edit().putString("notes",notes.toString()).apply();break;
            default:startActivity(new Intent(Settings.ACTION_SETTINGS));break;
        }app.notice="בוצע: "+a.title();app.changed();toast(app.notice);}catch(ActivityNotFoundException e){toast("היישום הנדרש לפעולה אינו מותקן במכשיר.");}catch(Exception e){toast("הפעולה לא בוצעה. בדוק הרשאות וזמינות במכשיר.");}
    }
    private void showNotes(){try{JSONArray a=new JSONArray(app.prefs.getString("notes","[]"));if(a.length()==0){toast("עדיין לא נשמרו פתקים.");return;}String[] labels=new String[a.length()];for(int i=0;i<a.length();i++){String s=a.getJSONObject(i).getString("text");labels[i]=s.substring(0,Math.min(45,s.length()));}new AlertDialog.Builder(this).setTitle("הפתקים שלי").setItems(labels,(dia,index)->{try{String s=a.getJSONObject(index).getString("text");new AlertDialog.Builder(this).setTitle("פתק מקומי").setMessage(s).setPositiveButton("סגור",null).setNeutralButton("העתק",(di,w)->{((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("פתק",s));toast("הפתק הועתק");}).setNegativeButton("מחק",(di,w)->{a.remove(index);app.prefs.edit().putString("notes",a.toString()).apply();}).show();}catch(Exception ignored){}}).setNegativeButton("סגור",null).show();}catch(Exception e){toast("לא ניתן לקרוא את הפתקים.");}}
    private void external(String url){try{startActivity(new Intent(url.startsWith("mailto:")?Intent.ACTION_SENDTO:Intent.ACTION_VIEW,Uri.parse(url)));}catch(ActivityNotFoundException e){toast("לא נמצא יישום מתאים לפתיחת הקישור.");}}
    private void terms(){new AlertDialog.Builder(this).setTitle("ברוכים הבאים לצ׳אט כשר").setMessage("הצ׳אט פועל במכשיר באמצעות מודל מקומי. גרסת הבטא כוללת נגזרת DictaLM 3.0 1.7B לעברית ואנגלית ברישיון Apache 2.0. זו גרסת בדיקה, והמודל עלול לטעות. Gemma 4 נתמך בייבוא ומופץ ברישיון Apache 2.0. בייבוא Gemma 3 חלים גם תנאי Gemma ומדיניות השימוש שלו. ניתן לקרוא את הרישיונות המלאים באפליקציה. אין לאפליקציה הרשאת אינטרנט.\n\nהסינון ניסיוני והתשובות עלולות להיות שגויות.").setCancelable(false).setPositiveButton("אני מסכים ומתחיל",(a,b)->app.prefs.edit().putBoolean("terms_accepted",true).apply()).setNeutralButton("קריאת התנאים",(a,b)->showLicenses(true)).setNegativeButton("יציאה",(a,b)->finish()).show();}
    private void showLicenses(boolean returnToTerms){try{String value=new String(FilesLocal.read(getAssets().open("licenses.txt"),100000),StandardCharsets.UTF_8);ScrollView scroll=new ScrollView(this);TextView t=text(value,12,ink,false);t.setPadding(d(20),d(16),d(20),d(16));t.setTextIsSelectable(true);scroll.addView(t);AlertDialog dialog=new AlertDialog.Builder(this).setTitle("תנאי שימוש ורישיונות").setView(scroll).setPositiveButton("סגור",null).create();if(returnToTerms)dialog.setOnDismissListener(d->terms());dialog.show();}catch(Exception e){toast("לא ניתן לקרוא את תנאי השימוש.");if(returnToTerms)terms();}}
    @Override public void changed(){if(state==null)return;state.setText(app.busy?app.status:app.ready?"מודל מקומי מוכן · ללא אינטרנט":"ללא אינטרנט · ממתין לטעינת מודל");if(page==0){if(lastCount!=app.store.current.messages.size()||!lastId.equals(app.store.current.id)||lastBusy!=app.busy||lastReady!=app.ready)renderChat();if(notice!=null){notice.setText(app.notice);notice.setVisibility(app.notice.isEmpty()?View.GONE:View.VISIBLE);}if(thinking!=null){thinking.setText(app.status);thinking.setVisibility(app.generating?View.VISIBLE:View.GONE);}}else if(page==2&&(lastBusy!=app.busy||lastReady!=app.ready)){body.removeAllViews();renderSettings();lastBusy=app.busy;lastReady=app.ready;if(!app.notice.isEmpty())toast(app.notice);}}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private String displayNumbers(String value){java.util.regex.Matcher match=NUMBERS.matcher(value);StringBuffer out=new StringBuffer();while(match.find())match.appendReplacement(out,java.util.regex.Matcher.quoteReplacement("\u2066"+match.group()+"\u2069"));match.appendTail(out);return out.toString();}
    private TextView text(String value,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(sp);t.setTextColor(color);t.setGravity(Gravity.START);t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_LTR);if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;}
    private View iconButton(String icon,String label,Runnable run){IconView v=new IconView(this,icon,ink);v.setPadding(d(10),d(10),d(10),d(10));v.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);v.setContentDescription(label);v.setOnClickListener(w->run.run());return v;}
    private TextView button(String label,boolean primary,Runnable run){TextView b=text(label,14,primary?Color.WHITE:accent,true);b.setGravity(Gravity.CENTER);b.setPadding(d(12),d(12),d(12),d(12));b.setBackground(round(primary?Color.parseColor("#153A53"):(dark?Color.parseColor("#213B38"):Color.parseColor("#E7F5EF")),12));b.setOnClickListener(v->run.run());return b;}
    private GradientDrawable round(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(d(radius));return g;}
    private GradientDrawable outline(int color,int radius){GradientDrawable g=round(color,radius);g.setStroke(d(1),stroke);return g;}
    private void toast(String text){Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
}
