package com.moked.kosherchat;

final class NativeEngine {
    static { System.loadLibrary("kosherchat"); }
    interface Progress { void onProgress(int tokens); }
    static native void load(byte[] path, int context, int threads);
    static native void loadAsset(int fd, long offset, int context, int threads);
    static native void close();
    static native void cancel();
    static native void reset();
    static native int countTokens(byte[] text);
    static byte[] generate(byte[] prompt, int maxTokens, Progress progress) {
        return generateBounded(prompt, maxTokens,
            GenerationBudget.reasoningTokens(modelFamily(), maxTokens), progress);
    }
    private static native byte[] generateBounded(byte[] prompt, int maxTokens, int reasoningTokens, Progress progress);
    static native long[] cacheStats();
    static native int modelFamily();
    static native boolean generationTruncated();
}
